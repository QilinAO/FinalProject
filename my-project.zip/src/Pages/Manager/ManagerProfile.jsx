// src/Pages/Manager/ManagerProfile.jsx
import React, { useState, useEffect } from "react";
import { FiSearch, FiFilter, FiEye, FiXCircle } from "react-icons/fi";
import { ToastContainer, toast } from "react-toastify";
import ManagerMenu from "../../Component/ManagerMenu";
import Modal from "react-modal";
import "react-toastify/dist/ReactToastify.css";
import {
  subscribeToGeneralNews,
  subscribeToPromotionalNews,
  subscribeToContests,
  deleteGeneralNews,
  deletePromotionalNews,
  deleteContest
} from "../../backend/services_manager/ManagerProfile";

const ManagerProfile = () => {
  // State สำหรับจัดเก็บข้อมูล
  const [contests, setContests] = useState([]);
  const [generalNews, setGeneralNews] = useState([]);
  const [promotionalNews, setPromotionalNews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // State สำหรับการค้นหาและกรองข่าวสาร
  const [searchQuery, setSearchQuery] = useState("");
  const [filterType, setFilterType] = useState("ทั้งหมด"); // ทั้งหมด, ข่าวสารทั่วไป, ข่าวสารประชาสัมพันธ์

  // State สำหรับการค้นหาการประกวด
  const [contestSearchQuery, setContestSearchQuery] = useState("");

  // State สำหรับโมดัลรายละเอียด
  const [selectedItem, setSelectedItem] = useState(null);
  const [modalType, setModalType] = useState(""); // 'contest', 'generalNews', 'promotionalNews'
  const [isModalOpen, setIsModalOpen] = useState(false);

  // ตั้งค่า Modal
  useEffect(() => {
    Modal.setAppElement("#root");
  }, []);

  // ฟังก์ชันดึงข้อมูลจาก Firestore (ผ่าน service ต่าง ๆ)
  useEffect(() => {
    const unsubscribeGeneralNews = subscribeToGeneralNews((data, err) => {
      if (err) {
        setError("เกิดข้อผิดพลาดในการดึงข้อมูลข่าวสารทั่วไป");
        setLoading(false);
      } else {
        setGeneralNews(data);
        setLoading(false);
      }
    });

    const unsubscribePromotionalNews = subscribeToPromotionalNews((data, err) => {
      if (err) {
        setError("เกิดข้อผิดพลาดในการดึงข้อมูลข่าวสารประชาสัมพันธ์");
        setLoading(false);
      } else {
        setPromotionalNews(data);
        setLoading(false);
      }
    });

    const unsubscribeContests = subscribeToContests((data, err) => {
      if (err) {
        setError("เกิดข้อผิดพลาดในการดึงข้อมูลการประกวด");
        setLoading(false);
      } else {
        setContests(data);
        setLoading(false);
      }
    });

    // คืนค่า unsubscribe เมื่อ component ถูก unmount
    return () => {
      unsubscribeGeneralNews();
      unsubscribePromotionalNews();
      unsubscribeContests();
    };
  }, []);

  // ฟังก์ชันการค้นหา
  const handleSearch = (e) => {
    setSearchQuery(e.target.value);
  };

  // ฟังก์ชันการกรอง
  const handleFilterChange = (e) => {
    setFilterType(e.target.value);
  };

  // ฟังก์ชันเปิดโมดัลรายละเอียด
  const handleShowDetails = (item, type) => {
    setSelectedItem(item);
    setModalType(type);
    setIsModalOpen(true);
  };

  // ฟังก์ชันปิดโมดัล
  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedItem(null);
    setModalType("");
  };

  // ฟังก์ชันกรองข่าวสาร
  const filterNews = () => {
    let filteredNews = [];

    if (filterType === "ทั้งหมด") {
      filteredNews = [...generalNews, ...promotionalNews];
    } else if (filterType === "ข่าวสารทั่วไป") {
      filteredNews = [...generalNews];
    } else if (filterType === "ข่าวสารประชาสัมพันธ์") {
      filteredNews = [...promotionalNews];
    }

    if (searchQuery.trim() !== "") {
      filteredNews = filteredNews.filter((news) =>
        news.title.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    return filteredNews;
  };

  // ฟังก์ชันกรองการประกวด
  const filterContests = () => {
    if (contestSearchQuery.trim() === "") {
      return contests;
    }
    return contests.filter((contest) =>
      contest.name.toLowerCase().includes(contestSearchQuery.toLowerCase())
    );
  };
  const filteredContests = filterContests();

  // ฟังก์ชันการลบข่าวสาร
  const handleDeleteNews = async (id, type) => {
    if (
      window.confirm(
        `คุณต้องการลบ ${
          type === "generalNews" ? "ข่าวสารทั่วไป" : "ข่าวสารประชาสัมพันธ์"
        } นี้ใช่หรือไม่?`
      )
    ) {
      try {
        if (type === "generalNews") {
          await deleteGeneralNews(id);
          toast.success("ลบข่าวสารทั่วไปสำเร็จ!");
        } else if (type === "promotionalNews") {
          await deletePromotionalNews(id);
          toast.success("ลบข่าวสารประชาสัมพันธ์สำเร็จ!");
        }
      } catch (err) {
        console.error("Error deleting news: ", err);
        toast.error("เกิดข้อผิดพลาดในการลบข่าวสาร");
      }
    }
  };

  // ฟังก์ชันการลบการประกวด
  const handleDeleteContest = async (id) => {
    if (window.confirm("คุณต้องการลบการประกวดนี้ใช่หรือไม่?")) {
      try {
        await deleteContest(id);
        toast.success("ลบการประกวดสำเร็จ!");
      } catch (err) {
        console.error("Error deleting contest: ", err);
        toast.error("เกิดข้อผิดพลาดในการลบการประกวด");
      }
    }
  };

  // ฟังก์ชันแปลง Firestore Timestamp เป็นสตริง
  const formatTimestamp = (timestamp) => {
    if (!timestamp) return "N/A";
    if (timestamp.toDate) {
      return timestamp.toDate().toLocaleString();
    }
    // กรณี timestamp เป็น object { seconds, nanoseconds }
    const date = new Date(
      timestamp.seconds * 1000 + timestamp.nanoseconds / 1000000
    );
    return date.toLocaleString();
  };

  // เช็คสถานะการโหลดข้อมูล
  if (loading) {
    return (
      <div className="bg-gray-100 min-h-screen">
        <ManagerMenu />
        <div className="pt-16 p-8 w-full flex items-center justify-center">
          <p className="text-gray-700">กำลังโหลดข้อมูล...</p>
        </div>
      </div>
    );
  }

  // เช็คข้อผิดพลาดในการดึงข้อมูล
  if (error) {
    return (
      <div className="bg-gray-100 min-h-screen">
        <ManagerMenu />
        <div className="pt-16 p-8 w-full flex items-center justify-center">
          <p className="text-red-500">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-100 min-h-screen">
      <ManagerMenu />

      {/* เว้นด้านบนกันไม่ให้เนื้อหาโดน Navbar บัง */}
      <div className="pt-16 w-full p-8">
        <ToastContainer />
        <h1 className="text-3xl font-bold text-gray-800 mb-6">
          ข้อมูลที่จัดการไว้
        </h1>

        {/* ส่วนแสดงสถิติ */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {/* การประกวด */}
          <div className="bg-white shadow-md rounded-lg p-6 flex items-center">
            <div className="p-3 bg-blue-500 text-white rounded-full mr-4">
              <FiEye size={24} />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-800">
                {contests.length}
              </h2>
              <p className="text-gray-600">การประกวด</p>
            </div>
          </div>
          {/* ข่าวสารทั่วไป */}
          <div className="bg-white shadow-md rounded-lg p-6 flex items-center">
            <div className="p-3 bg-green-500 text-white rounded-full mr-4">
              <FiSearch size={24} />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-800">
                {generalNews.length}
              </h2>
              <p className="text-gray-600">ข่าวสารทั่วไป</p>
            </div>
          </div>
          {/* ข่าวสารประชาสัมพันธ์ */}
          <div className="bg-white shadow-md rounded-lg p-6 flex items-center">
            <div className="p-3 bg-purple-500 text-white rounded-full mr-4">
              <FiFilter size={24} />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-800">
                {promotionalNews.length}
              </h2>
              <p className="text-gray-600">ข่าวสารประชาสัมพันธ์</p>
            </div>
          </div>
        </div>

        {/* ส่วนค้นหาและกรองข่าวสาร */}
        <div className="bg-white shadow-md rounded-lg p-6 mb-8">
          <h2 className="text-2xl font-semibold text-gray-800 mb-4">
            รายการข่าวสาร
          </h2>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
            {/* ค้นหา */}
            <div className="flex items-center mb-4 md:mb-0">
              <FiSearch className="text-gray-500 mr-2" />
              <input
                type="text"
                placeholder="ค้นหาข่าวสาร..."
                value={searchQuery}
                onChange={handleSearch}
                className="w-full md:w-64 p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            {/* กรอง */}
            <div className="flex items-center">
              <FiFilter className="text-gray-500 mr-2" />
              <select
                value={filterType}
                onChange={handleFilterChange}
                className="p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="ทั้งหมด">ทั้งหมด</option>
                <option value="ข่าวสารทั่วไป">ข่าวสารทั่วไป</option>
                <option value="ข่าวสารประชาสัมพันธ์">ข่าวสารประชาสัมพันธ์</option>
              </select>
            </div>
          </div>

          {/* รายการข่าวสาร */}
          <div className="grid grid-cols-1 gap-4">
            {filterNews().length > 0 ? (
              filterNews().map((news) => (
                <div
                  key={news.id}
                  className="bg-gray-50 rounded-lg p-4 flex justify-between items-center hover:bg-gray-100 transition-colors"
                >
                  <div>
                    <h3 className="text-lg font-semibold text-gray-800">{news.title}</h3>
                    <p className="text-sm text-gray-600">
                      วันที่สร้าง: {formatTimestamp(news.createdAt)}
                    </p>
                  </div>
                  <div className="flex space-x-2">
                    <button
                      className="text-blue-500 hover:text-blue-700 flex items-center"
                      onClick={() =>
                        handleShowDetails(
                          news,
                          filterType === "ข่าวสารทั่วไป"
                            ? "generalNews"
                            : "promotionalNews"
                        )
                      }
                    >
                      <FiEye className="mr-1" />
                      ดูรายละเอียด
                    </button>
                    <button
                      className="text-red-500 hover:text-red-700 flex items-center"
                      onClick={() =>
                        handleDeleteNews(
                          news.id,
                          filterType === "ข่าวสารทั่วไป"
                            ? "generalNews"
                            : "promotionalNews"
                        )
                      }
                    >
                      <FiXCircle className="mr-1" />
                      ลบ
                    </button>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-gray-600">ไม่พบข่าวสารที่ตรงกับการค้นหา</p>
            )}
          </div>
        </div>

        {/* ส่วนแสดงรายการการประกวด */}
        <div className="bg-white shadow-md rounded-lg p-6 mb-8">
          <h2 className="text-2xl font-semibold text-gray-800 mb-4">
            รายการการประกวด
          </h2>

          {/* อินพุตค้นหาการประกวด */}
          <div className="flex items-center mb-4">
            <FiSearch className="text-gray-500 mr-2" />
            <input
              type="text"
              placeholder="ค้นหาการประกวด..."
              value={contestSearchQuery}
              onChange={(e) => setContestSearchQuery(e.target.value)}
              className="w-full md:w-64 p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="grid grid-cols-1 gap-4">
            {filteredContests.length > 0 ? (
              filteredContests.map((contest) => (
                <div
                  key={contest.id}
                  className="bg-gray-50 rounded-lg p-4 flex justify-between items-center hover:bg-gray-100 transition-colors"
                >
                  <div>
                    <h3 className="text-lg font-semibold text-gray-800">
                      {contest.name}
                    </h3>
                    <p className="text-sm text-gray-600">
                      ผู้ชนะ: {contest.details?.winner || "N/A"}
                    </p>
                    <p className="text-sm text-gray-600">
                      จำนวนผู้เข้าร่วม: {contest.details?.participants || "N/A"}
                    </p>
                    <p className="text-sm text-gray-600">
                      วันที่สร้าง: {formatTimestamp(contest.createdAt)}
                    </p>
                  </div>
                  <div className="flex space-x-2">
                    <button
                      className="text-blue-500 hover:text-blue-700 flex items-center"
                      onClick={() => handleShowDetails(contest, "contest")}
                    >
                      <FiEye className="mr-1" />
                      ดูรายละเอียด
                    </button>
                    <button
                      className="text-red-500 hover:text-red-700 flex items-center"
                      onClick={() => handleDeleteContest(contest.id)}
                    >
                      <FiXCircle className="mr-1" />
                      ลบ
                    </button>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-gray-600">
                ไม่มีการประกวดที่ตรงกับการค้นหา
              </p>
            )}
          </div>
        </div>

        {/* โมดัลสำหรับแสดงรายละเอียด */}
        <Modal
          isOpen={isModalOpen}
          onRequestClose={handleCloseModal}
          className="fixed inset-0 flex items-center justify-center z-50"
          overlayClassName="fixed inset-0 bg-black bg-opacity-50"
        >
          {selectedItem && (
            <div className="bg-white rounded-lg p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-gray-800">
                  {modalType === "contest"
                    ? selectedItem.name
                    : selectedItem.title}
                </h2>
                <button
                  onClick={handleCloseModal}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <FiXCircle size={24} />
                </button>
              </div>

              {/* รายละเอียดการประกวด */}
              {modalType === "contest" && (
                <div>
                  <p className="mb-2">
                    <span className="font-semibold">ผู้ชนะ:</span>{" "}
                    {selectedItem.details?.winner || "N/A"}
                  </p>
                  <p className="mb-2">
                    <span className="font-semibold">จำนวนผู้เข้าร่วม:</span>{" "}
                    {selectedItem.details?.participants || "N/A"}
                  </p>
                  <p className="mb-2">
                    <span className="font-semibold">วันที่สร้าง:</span>{" "}
                    {formatTimestamp(selectedItem.createdAt)}
                  </p>
                  {/* เพิ่มรายละเอียดอื่น ๆ ตามต้องการ */}
                </div>
              )}

              {/* รายละเอียดข่าวสารทั่วไปและประชาสัมพันธ์ */}
              {(modalType === "generalNews" ||
                modalType === "promotionalNews") && (
                <div>
                  <p className="mb-2">
                    <span className="font-semibold">วันที่สร้าง:</span>{" "}
                    {formatTimestamp(selectedItem.createdAt)}
                  </p>
                  <p className="mb-4">
                    <span className="font-semibold">เนื้อหา:</span>{" "}
                    {selectedItem.content}
                  </p>
                  {/* เพิ่มรายละเอียดอื่น ๆ ตามต้องการ */}
                </div>
              )}
            </div>
          )}
        </Modal>
      </div>
    </div>
  );
};

export default ManagerProfile;

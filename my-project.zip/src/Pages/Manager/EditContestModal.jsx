// src/Pages/Manager/EditContestModal.jsx
import React from "react";
import Modal from "react-modal";

// ตัวอย่างรายการ subcategories ปลากัด
const BETTA_SUBCATEGORIES = [
  { id: "shortFin_1_1", label: "ครีบสั้น 1.1.1" },
  { id: "shortFin_1_2", label: "ครีบสั้น 1.1.2" },
  { id: "longFin_1_1",  label: "ครีบยาว 1.2.1" },
  // ... ใส่ตามต้องการ ...
];

const EditContestModal = ({
  isOpen,
  onRequestClose,
  formData,
  setFormData,
  onSubmit
}) => {
  if (!isOpen) return null;

  // เปลี่ยนค่าทั่วไป (input, select)
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    if (type === "checkbox" && name === "voteOpen") {
      setFormData({ ...formData, voteOpen: checked });
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  // กรรมการ
  const handleJudgeChange = (idx, newVal) => {
    const newJudges = [...formData.judges];
    newJudges[idx] = newVal;
    setFormData({ ...formData, judges: newJudges });
  };

  // subcategories
  const handleSubcatChange = (subcatId, checked) => {
    let updated = [...formData.allowedSubcategories];
    if (checked) {
      if (!updated.includes(subcatId)) {
        updated.push(subcatId);
      }
    } else {
      updated = updated.filter((id) => id !== subcatId);
    }
    setFormData({ ...formData, allowedSubcategories: updated });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // ส่ง formData กลับไป ContestList
    onSubmit({
      ...formData
      // NOTE: ยังไม่แปลงเป็น Timestamp ตรงนี้ ให้ไปแปลงใน handleEditSubmit ก็ได้
    });
  };

  return (
    <Modal
      isOpen={isOpen}
      onRequestClose={onRequestClose}
      className="fixed inset-0 flex items-center justify-center z-50"
      overlayClassName="fixed inset-0 bg-black bg-opacity-50"
    >
      <div className="bg-white rounded-lg p-6 max-w-2xl w-full mx-4 overflow-y-auto max-h-full">
        <h2 className="text-2xl font-bold mb-4 text-center">
          แก้ไขการประกวด
        </h2>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* ประเภทข่าวสาร */}
          <div>
            <label className="block text-gray-700 font-semibold mb-2">
              ประเภทข่าวสาร:
            </label>
            <select
              name="category"
              value={formData.category}
              onChange={handleChange}
              className="w-full px-4 py-2 border rounded-md focus:outline-blue-500"
              required
            >
              <option value="การประกวด">การประกวด</option>
              <option value="ข่าวสารทั่วไป">ข่าวสารทั่วไป</option>
              <option value="ข่าวสารประชาสัมพันธ์">ข่าวสารประชาสัมพันธ์</option>
            </select>
          </div>

          {/* ชื่อการประกวด */}
          <div>
            <label className="block text-gray-700 font-semibold mb-2">
              ชื่อการประกวด:
            </label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              className="w-full px-4 py-2 border rounded-md focus:outline-blue-500"
              required
            />
          </div>

          {/* คำอธิบายย่อ */}
          <div>
            <label className="block text-gray-700 font-semibold mb-2">
              คำอธิบายโครงการโดยย่อ:
            </label>
            <textarea
              name="shortDescription"
              rows="3"
              value={formData.shortDescription}
              onChange={handleChange}
              className="w-full px-4 py-2 border rounded-md focus:outline-blue-500"
              required
            />
          </div>

          {/* คำอธิบายละเอียด */}
          <div>
            <label className="block text-gray-700 font-semibold mb-2">
              คำอธิบายโครงการโดยละเอียด:
            </label>
            <textarea
              name="fullDescription"
              rows="5"
              value={formData.fullDescription}
              onChange={handleChange}
              className="w-full px-4 py-2 border rounded-md focus:outline-blue-500"
              required
            />
          </div>

          {/* วันที่เริ่มต้น / สิ้นสุด */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-gray-700 font-semibold mb-2">
                วันที่เริ่มต้น:
              </label>
              <input
                type="date"
                name="startDate"
                value={formData.startDate}
                onChange={handleChange}
                className="w-full px-4 py-2 border rounded-md focus:outline-blue-500"
                required={formData.category === "การประกวด"}
              />
            </div>
            <div>
              <label className="block text-gray-700 font-semibold mb-2">
                วันที่สิ้นสุด:
              </label>
              <input
                type="date"
                name="endDate"
                value={formData.endDate}
                onChange={handleChange}
                className="w-full px-4 py-2 border rounded-md focus:outline-blue-500"
                required={formData.category === "การประกวด"}
              />
            </div>
          </div>

          {/* สถานะ */}
          <div>
            <label className="block text-gray-700 font-semibold mb-2">
              สถานะการจัดประกวด:
            </label>
            <select
              name="status"
              value={formData.status}
              onChange={handleChange}
              className="w-full px-4 py-2 border rounded-md focus:outline-blue-500"
            >
              <option value="draft">ร่าง</option>
              <option value="กำลังดำเนินการ">กำลังดำเนินการ</option>
              <option value="ปิดรับสมัคร">ปิดรับสมัคร</option>
              <option value="ประกาศผล">ประกาศผล</option>
            </select>
          </div>

          {/* เปิดโหวต */}
          {formData.category === "การประกวด" && (
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="voteOpen"
                name="voteOpen"
                checked={formData.voteOpen}
                onChange={handleChange}
              />
              <label htmlFor="voteOpen">เปิดโหวตผู้เข้าชม</label>
            </div>
          )}

          {/* กรรมการ */}
          {formData.category === "การประกวด" && (
            <div>
              <label className="block text-gray-700 font-semibold mb-2">
                กรรมการ:
              </label>
              <div className="space-y-4">
                {formData.judges.map((judge, index) => (
                  <input
                    key={index}
                    type="email"
                    value={judge}
                    onChange={(e) => handleJudgeChange(index, e.target.value)}
                    className="w-full px-4 py-2 border rounded-md focus:outline-blue-500"
                    placeholder={`กรอกอีเมลกรรมการคนที่ ${index + 1}`}
                  />
                ))}
              </div>
            </div>
          )}

          {/* subcategories */}
          {formData.category === "การประกวด" && (
            <div>
              <label className="block text-gray-700 font-semibold mb-2">
                ประเภทปลากัด (เลือกได้หลายประเภท):
              </label>
              <div className="grid grid-cols-2 gap-2">
                {BETTA_SUBCATEGORIES.map((sub) => {
                  const checked = formData.allowedSubcategories.includes(sub.id);
                  return (
                    <label key={sub.id} className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={checked}
                        onChange={(e) =>
                          handleSubcatChange(sub.id, e.target.checked)
                        }
                      />
                      <span>{sub.label}</span>
                    </label>
                  );
                })}
              </div>
            </div>
          )}

          {/* ปุ่ม */}
          <div className="flex justify-end space-x-4">
            <button
              type="button"
              className="bg-gray-300 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-400 transition"
              onClick={onRequestClose}
            >
              ยกเลิก
            </button>
            <button
              type="submit"
              className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition"
            >
              บันทึก
            </button>
          </div>
        </form>
      </div>
    </Modal>
  );
};

export default EditContestModal;

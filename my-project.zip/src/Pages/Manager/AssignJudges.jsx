// src/Pages/Manager/AssignJudges.jsx
import React, { useState } from "react";
import ManagerMenu from "../../Component/ManagerMenu"; // ManagerMenu แบบ Responsive
import { useUserProfile } from "../../context/UserProfileContext";

const AssignJudges = () => {
  const { profileData } = useUserProfile();

  // สมมติข้อมูลผู้เชี่ยวชาญ
  const experts = [
    { id: 1, name: "ผู้เชี่ยวชาญ A" },
    { id: 2, name: "ผู้เชี่ยวชาญ B" },
    { id: 3, name: "ผู้เชี่ยวชาญ C" },
  ];

  const handleAssign = (e) => {
    e.preventDefault();
    alert("กำหนดกรรมการสำเร็จ!");
  };

  return (
    <div className="min-h-screen flex bg-gradient-to-r from-purple-200 via-pink-200 to-red-200">
      {/* Sidebar (ManagerMenu) */}
      <ManagerMenu />

      {/* เนื้อหา */}
      <div className="flex-1 p-4 md:ml-64">
        <div className="max-w-xl mx-auto bg-white p-6 rounded shadow">
          <h1 className="text-2xl font-bold mb-4 text-purple-700 text-center">
            กำหนดกรรมการ
          </h1>
          <form onSubmit={handleAssign}>
            <div className="mb-4">
              <label className="block mb-2 text-gray-700 font-medium">
                เลือกการประกวด:
              </label>
              <select className="border p-2 w-full rounded focus:ring-2 focus:ring-purple-400 focus:outline-none">
                <option>การประกวดปลากัดครั้งที่ 1</option>
                <option>การประกวดปลากัดครั้งที่ 2</option>
                <option>การประกวดปลากัดครั้งที่ 3</option>
              </select>
            </div>
            <div className="mb-4">
              <label className="block mb-2 text-gray-700 font-medium">
                เลือกกรรมการ (ผู้เชี่ยวชาญ):
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-2">
                {experts.map((expert) => (
                  <div key={expert.id} className="flex items-center">
                    <input
                      type="checkbox"
                      id={`expert-${expert.id}`}
                      className="mr-2 h-4 w-4"
                    />
                    <label
                      htmlFor={`expert-${expert.id}`}
                      className="text-gray-800"
                    >
                      {expert.name}
                    </label>
                  </div>
                ))}
              </div>
            </div>
            <button
              type="submit"
              className="bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700 transition w-full"
            >
              บันทึก
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AssignJudges;

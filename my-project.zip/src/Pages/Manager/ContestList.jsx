// src/Pages/Manager/ContestList.jsx

import React, { useState, useEffect } from "react";
import {
  Search,
  Filter,
  Eye,
  Edit2,
  Trash2,
  CheckCircle,
  XCircle,
  Clock,
  CircleDot
} from "lucide-react";
import ManagerMenu from "../../Component/ManagerMenu";
import Modal from "react-modal";
import EditContestModal from "./EditContestModal";

// Firestore
import {
  collection,
  onSnapshot,
  query,
  where,
  doc,
  updateDoc,
  deleteDoc,
} from "firebase/firestore";
import { db } from "../../backend/config/FirebaseSDK";

const ContestList = () => {
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [selectedContest, setSelectedContest] = useState(null);
  const [activeTab, setActiveTab] = useState("participants");

  // สำหรับฟอร์มแก้ไข (เพิ่ม voteOpen, allowedSubcategories)
  const [editFormData, setEditFormData] = useState({
    name: "",
    shortDescription: "",
    fullDescription: "",
    category: "การประกวด",
    startDate: "",
    endDate: "",
    judges: ["", "", ""],
    status: "draft", // หรือ "กำลังดำเนินการ"
    voteOpen: false,
    allowedSubcategories: []
  });

  const [contests, setContests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    Modal.setAppElement("#root");
  }, []);

  // ----- (1) ดึงข้อมูล contests เฉพาะ category = "การประกวด"
  useEffect(() => {
    const colRef = collection(db, "contests");
    const qSnap = query(colRef, where("category", "==", "การประกวด"));

    const unsubscribe = onSnapshot(
      qSnap,
      (snapshot) => {
        const data = [];
        snapshot.forEach((docSnap) => {
          data.push({ id: docSnap.id, ...docSnap.data() });
        });
        setContests(data);
        setLoading(false);
      },
      (err) => {
        console.error("Error fetching contests:", err);
        setError("เกิดข้อผิดพลาดในการดึงข้อมูลการประกวด");
        setLoading(false);
      }
    );
    return () => unsubscribe();
  }, []);

  // ----- (2) ฟังก์ชันอัปเดตใน Firestore -----
  const updateContest = async (contestId, updatedData) => {
    try {
      const refDoc = doc(db, "contests", contestId);
      await updateDoc(refDoc, updatedData);
    } catch (error) {
      console.error("Error updating contest:", error);
      throw error;
    }
  };

  // ----- (3) ฟังก์ชันลบจาก Firestore -----
  const deleteContest = async (contestId) => {
    try {
      const refDoc = doc(db, "contests", contestId);
      await deleteDoc(refDoc);
    } catch (error) {
      console.error("Error deleting contest:", error);
      throw error;
    }
  };

  // ----- (4) แสดงไอคอนตามสถานะ -----
  // เพิ่ม draft, ปิดรับสมัคร, ประกาศผล ฯลฯ
  const getStatusIcon = (status) => {
    switch (status) {
      case "draft":
        return <CircleDot className="text-gray-400" />;
      case "กำลังดำเนินการ":
        return <Clock className="text-yellow-500" />;
      case "ปิดรับสมัคร":
        return <XCircle className="text-orange-500" />;
      case "ประกาศผล":
        return <CheckCircle className="text-green-500" />;
      default:
        return <CircleDot className="text-gray-400" />;
    }
  };

  // กรองตาม search + filterStatus
  const filteredContests = contests.filter((c) => {
    const matchSearch = c.name?.toLowerCase().includes(search.toLowerCase());
    const matchStatus = filterStatus === "" || c.status === filterStatus;
    return matchSearch && matchStatus;
  });

  // เปิด Modal รายละเอียด
  const handleShowDetails = (contest) => {
    setSelectedContest(contest);
    setIsModalOpen(true);
  };

  // เปิด Modal Edit
  const handleEditContest = (contest) => {
    // เตรียมค่าเข้า editFormData
    const {
      name,
      shortDescription,
      fullDescription,
      category,
      startDate,
      endDate,
      judges,
      status,
      voteOpen,
      allowedSubcategories
    } = contest;

    // แปลง Timestamp เป็น string (YYYY-MM-DD)
    let startStr = "";
    let endStr = "";
    if (startDate?.toDate) {
      startStr = startDate.toDate().toISOString().split("T")[0];
    }
    if (endDate?.toDate) {
      endStr = endDate.toDate().toISOString().split("T")[0];
    }

    setEditFormData({
      name: name || "",
      shortDescription: shortDescription || "",
      fullDescription: fullDescription || "",
      category: category || "การประกวด",
      startDate: startStr,
      endDate: endStr,
      judges: Array.isArray(judges) ? judges : ["", "", ""],
      status: status || "draft",
      voteOpen: voteOpen || false,
      allowedSubcategories: Array.isArray(allowedSubcategories)
        ? allowedSubcategories
        : []
    });

    setSelectedContest(contest);
    setIsEditModalOpen(true);
  };

  const handleDeleteContest = async (contestId, contestName) => {
    if (
      window.confirm(`คุณต้องการลบการประกวด "${contestName}" ใช่หรือไม่?`)
    ) {
      try {
        await deleteContest(contestId);
        alert("ลบข้อมูลสำเร็จ!");
      } catch (err) {
        console.error("Error deleting contest:", err);
        alert("เกิดข้อผิดพลาดในการลบข้อมูล");
      }
    }
  };

  // ----- (5) จัดการ Submit Edit Modal -----
  const handleEditSubmit = async (updatedData) => {
    // updatedData มาจาก EditContestModal (รวม date, voteOpen, etc.)
    try {
      if (!selectedContest) return;
      // อัปเดต
      await updateContest(selectedContest.id, updatedData);
      alert("แก้ไขข้อมูลสำเร็จ!");
      setIsEditModalOpen(false);
    } catch (err) {
      console.error("Error updating contest:", err);
      alert("เกิดข้อผิดพลาดในการแก้ไขข้อมูล");
    }
  };

  if (loading) {
    return (
      <div className="bg-gray-100 min-h-screen">
        <ManagerMenu />
        <div className="pt-16 p-8 w-full flex items-center justify-center">
          <p className="text-gray-700">กำลังโหลดข้อมูล...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-gray-100 min-h-screen">
        <ManagerMenu />
        <div className="pt-16 p-8 w-full flex items-center justify-center">
          <p className="text-red-500">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-100 min-h-screen">
      <ManagerMenu />

      <div className="pt-16 p-8 w-full">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-800">รายการการประกวด</h1>
        </div>

        <div className="bg-white shadow-md rounded-lg p-6">
          {/* ค้นหา / กรองสถานะ */}
          <div className="flex flex-col md:flex-row md:space-x-4 mb-6">
            <div className="relative flex-grow mb-4 md:mb-0">
              <input
                type="text"
                placeholder="ค้นหาชื่อการประกวด"
                className="w-full pl-10 pr-4 py-2 border rounded-md focus:outline-blue-500"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
              <Search
                className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"
                size={20}
              />
            </div>

            <div className="relative">
              <select
                className="w-full pl-10 pr-4 py-2 border rounded-md focus:outline-blue-500 appearance-none"
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
              >
                <option value="">-- แสดงทั้งหมด --</option>
                <option value="draft">ร่าง</option>
                <option value="กำลังดำเนินการ">กำลังดำเนินการ</option>
                <option value="ปิดรับสมัคร">ปิดรับสมัคร</option>
                <option value="ประกาศผล">ประกาศผล</option>
              </select>
              <Filter
                className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"
                size={20}
              />
            </div>
          </div>

          {/* แสดงรายการ */}
          <div className="grid gap-4">
            {filteredContests.length > 0 ? (
              filteredContests.map((contest) => (
                <div
                  key={contest.id}
                  className="bg-white border rounded-lg p-4 flex flex-col md:flex-row md:items-center justify-between hover:shadow-md transition"
                >
                  <div className="flex items-center space-x-4 mb-4 md:mb-0">
                    {getStatusIcon(contest.status)}
                    <div>
                      <h3 className="font-semibold text-gray-800">
                        {contest.name}
                      </h3>
                      <span className="text-sm text-gray-500">
                        {contest.status}
                      </span>
                      {contest.voteOpen && (
                        <span className="ml-2 text-xs text-blue-600">
                          (เปิดโหวต)
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <button
                      className="text-blue-500 hover:bg-blue-100 p-2 rounded"
                      onClick={() => handleShowDetails(contest)}
                    >
                      <Eye size={20} />
                    </button>
                    <button
                      className="text-yellow-500 hover:bg-yellow-100 p-2 rounded"
                      onClick={() => handleEditContest(contest)}
                    >
                      <Edit2 size={20} />
                    </button>
                    <button
                      className="text-red-500 hover:bg-red-100 p-2 rounded"
                      onClick={() =>
                        handleDeleteContest(contest.id, contest.name)
                      }
                    >
                      <Trash2 size={20} />
                    </button>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-gray-600">ไม่พบการประกวดที่ตรงกับการค้นหา</p>
            )}
          </div>
          <p className="mt-4 text-gray-600 text-center">
            มีการประกวดทั้งหมด {filteredContests.length} รายการ
          </p>
        </div>
      </div>

      {/* Modal แสดงรายละเอียด */}
      <Modal
        isOpen={isModalOpen}
        onRequestClose={() => setIsModalOpen(false)}
        className="fixed inset-0 flex items-center justify-center z-50"
        overlayClassName="fixed inset-0 bg-black bg-opacity-50"
      >
        {selectedContest && (
          <div className="bg-white rounded-lg p-6 max-w-2xl w-full mx-4 overflow-y-auto max-h-full">
            <h2 className="text-2xl font-bold mb-4 text-center">
              {selectedContest.name}
            </h2>
            <p className="text-sm text-gray-500 mb-4">
              สถานะ: {selectedContest.status}{" "}
              {selectedContest.voteOpen && "(เปิดโหวต)"}
            </p>

            <p className="mb-2 font-semibold">คำอธิบายย่อ:</p>
            <p className="mb-4">{selectedContest.shortDescription}</p>
            <p className="mb-2 font-semibold">รายละเอียด:</p>
            <p className="mb-4">{selectedContest.fullDescription}</p>

            {/* แสดง subcategories ถ้ามี */}
            {selectedContest.allowedSubcategories?.length > 0 && (
              <div className="mb-4">
                <p className="font-bold text-gray-800 mb-1">ประเภทปลากัด:</p>
                <ul className="list-disc list-inside">
                  {selectedContest.allowedSubcategories.map((sub) => (
                    <li key={sub}>{sub}</li>
                  ))}
                </ul>
              </div>
            )}

            {/* ตัวอย่างแท็บผู้เข้าร่วม/กรรมการ/คะแนน/ผล (เดิม) */}
            <div className="flex justify-center mb-4">
              <button
                onClick={() => setActiveTab("participants")}
                className={`px-4 py-2 rounded-l-md border-t border-b ${
                  activeTab === "participants"
                    ? "bg-blue-500 text-white"
                    : "bg-gray-200 text-gray-700"
                }`}
              >
                ผู้เข้าร่วม
              </button>
              <button
                onClick={() => setActiveTab("judges")}
                className={`px-4 py-2 border-t border-b ${
                  activeTab === "judges"
                    ? "bg-blue-500 text-white"
                    : "bg-gray-200 text-gray-700"
                }`}
              >
                กรรมการ
              </button>
              <button
                onClick={() => setActiveTab("scores")}
                className={`px-4 py-2 border-t border-b ${
                  activeTab === "scores"
                    ? "bg-blue-500 text-white"
                    : "bg-gray-200 text-gray-700"
                }`}
              >
                คะแนน
              </button>
              <button
                onClick={() => setActiveTab("results")}
                className={`px-4 py-2 rounded-r-md border-t border-b ${
                  activeTab === "results"
                    ? "bg-blue-500 text-white"
                    : "bg-gray-200 text-gray-700"
                }`}
              >
                ผลการแข่งขัน
              </button>
            </div>
            <div>
              {activeTab === "participants" && (
                <div>
                  <h3 className="font-bold mb-2">ผู้เข้าร่วม</h3>
                  <ul className="list-disc list-inside">
                    {(selectedContest.participants || []).map((p) => (
                      <li key={p.id}>
                        {p.name} - {p.fishType}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              {activeTab === "judges" && (
                <div>
                  <h3 className="font-bold mb-2">กรรมการ</h3>
                  <ul className="list-disc list-inside">
                    {(selectedContest.judges || []).map((judge, i) => (
                      <li key={i}>{judge}</li>
                    ))}
                  </ul>
                </div>
              )}
              {activeTab === "scores" && (
                <div>
                  <h3 className="font-bold mb-2">คะแนน</h3>
                  <ul className="list-disc list-inside">
                    {(selectedContest.scores || []).map((s, i) => (
                      <li key={i}>
                        {s.participantId} - กรรมการ {s.judgeId}: {s.score}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              {activeTab === "results" && (
                <div>
                  <h3 className="font-bold mb-2">ผลการแข่งขัน</h3>
                  <ul className="list-disc list-inside">
                    {(selectedContest.finalResults || []).map((r, i) => (
                      <li key={i}>
                        อันดับ {r.rank}: {r.name}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            <div className="mt-6 flex justify-end">
              <button
                className="bg-gray-300 px-4 py-2 rounded-md hover:bg-gray-400 transition"
                onClick={() => setIsModalOpen(false)}
              >
                ปิด
              </button>
            </div>
          </div>
        )}
      </Modal>

      {/* Edit Modal */}
      <EditContestModal
        isOpen={isEditModalOpen}
        onRequestClose={() => setIsEditModalOpen(false)}
        formData={editFormData}
        setFormData={setEditFormData}
        onSubmit={handleEditSubmit}
      />
    </div>
  );
};

export default ContestList;

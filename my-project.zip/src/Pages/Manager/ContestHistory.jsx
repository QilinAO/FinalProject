// src/Pages/Manager/ContestHistory.jsx
import React, { useState } from "react";
import { Award, Eye, Calendar, User, XCircle } from "lucide-react";
import ManagerMenu from "../../Component/ManagerMenu";
import Modal from "react-modal";

// Function to calculate average score
const calculateAverageScore = (scores) => {
  const flatScores = Object.values(scores).flat();
  const avgScore = flatScores.reduce((a, b) => a + b, 0) / flatScores.length;
  return avgScore.toFixed(2);
};

const ContestHistory = () => {
  const history = [
    {
      id: 1,
      name: "การประกวดปลากัดครั้งที่ 1",
      winner: "John Doe",
      details: {
        top3: [
          {
            rank: 1,
            user: "JohnDoe123",
            name: "ปลากัดแดงสวยงาม",
            age: "6 เดือน",
            size: "4 นิ้ว",
            type: "ปลากัดสวยงาม",
            breed: "ฮาฟมูน",
            image: "https://picsum.photos/200/200?random=1",
            video: "https://example.com/sample-video.mp4",
            scores: {
              headTail: [9, 9, 10],
              bodyScales: [8, 8, 9],
              dorsalFin: [10, 10, 9],
              caudalFin: [9, 9, 9],
              analFin: [8, 9, 8],
              otherFins: [8, 9, 8],
              pectoralFins: [9, 8, 9],
              operculum: [7, 8, 9],
              colorPattern: [10, 9, 10],
              stabilitySwimming: [9, 9, 9],
              flare: [9, 8, 9],
              overall: [9, 9, 10],
            },
          },
          {
            rank: 2,
            user: "JohnDoe123",
            name: "ปลากัดน้ำเงินสดใส",
            age: "5 เดือน",
            size: "3.5 นิ้ว",
            type: "ปลากัดสวยงาม",
            breed: "คราวน์เทล",
            image: "https://picsum.photos/200/200?random=2",
            video: "https://example.com/sample-video.mp4",
            scores: {
              headTail: [8, 9, 9],
              bodyScales: [8, 9, 9],
              dorsalFin: [9, 9, 8],
              caudalFin: [9, 9, 9],
              analFin: [9, 8, 9],
              otherFins: [9, 9, 9],
              pectoralFins: [9, 8, 9],
              operculum: [8, 9, 9],
              colorPattern: [10, 10, 9],
              stabilitySwimming: [9, 9, 9],
              flare: [8, 8, 9],
              overall: [9, 9, 9],
            },
          },
          {
            rank: 3,
            user: "JohnDoe123",
            name: "ปลากัดขาวประกาย",
            age: "4 เดือน",
            size: "3 นิ้ว",
            type: "ปลากัดสวยงาม",
            breed: "คราวน์เทล",
            image: "https://picsum.photos/200/200?random=3",
            video: "https://example.com/sample-video.mp4",
            scores: {
              headTail: [8, 8, 8],
              bodyScales: [8, 8, 8],
              dorsalFin: [8, 9, 8],
              caudalFin: [8, 8, 8],
              analFin: [8, 8, 8],
              otherFins: [8, 8, 8],
              pectoralFins: [8, 8, 8],
              operculum: [8, 8, 8],
              colorPattern: [8, 8, 8],
              stabilitySwimming: [8, 8, 8],
              flare: [8, 8, 8],
              overall: [8, 8, 8],
            },
          },
        ],
      },
    },
    {
      id: 2,
      name: "การประกวดปลากัดครั้งที่ 1",
      winner: "John Doe",
      details: {
        top3: [
          {
            rank: 1,
            user: "JohnDoe123",
            name: "ปลากัดแดงสวยงาม",
            age: "6 เดือน",
            size: "4 นิ้ว",
            type: "ปลากัดสวยงาม",
            breed: "ฮาฟมูน",
            image: "https://picsum.photos/200/200?random=1",
            video: "https://example.com/sample-video.mp4",
            scores: {
              headTail: [9, 9, 10],
              bodyScales: [8, 8, 9],
              dorsalFin: [10, 10, 9],
              caudalFin: [9, 9, 9],
              analFin: [8, 9, 8],
              otherFins: [8, 9, 8],
              pectoralFins: [9, 8, 9],
              operculum: [7, 8, 9],
              colorPattern: [10, 9, 10],
              stabilitySwimming: [9, 9, 9],
              flare: [9, 8, 9],
              overall: [9, 9, 10],
            },
          },
          {
            rank: 2,
            user: "JohnDoe123",
            name: "ปลากัดน้ำเงินสดใส",
            age: "5 เดือน",
            size: "3.5 นิ้ว",
            type: "ปลากัดสวยงาม",
            breed: "คราวน์เทล",
            image: "https://picsum.photos/200/200?random=2",
            video: "https://example.com/sample-video.mp4",
            scores: {
              headTail: [8, 9, 9],
              bodyScales: [8, 9, 9],
              dorsalFin: [9, 9, 8],
              caudalFin: [9, 9, 9],
              analFin: [9, 8, 9],
              otherFins: [9, 9, 9],
              pectoralFins: [9, 8, 9],
              operculum: [8, 9, 9],
              colorPattern: [10, 10, 9],
              stabilitySwimming: [9, 9, 9],
              flare: [8, 8, 9],
              overall: [9, 9, 9],
            },
          },
          {
            rank: 3,
            user: "JohnDoe123",
            name: "ปลากัดขาวประกาย",
            age: "4 เดือน",
            size: "3 นิ้ว",
            type: "ปลากัดสวยงาม",
            breed: "คราวน์เทล",
            image: "https://picsum.photos/200/200?random=3",
            video: "https://example.com/sample-video.mp4",
            scores: {
              headTail: [8, 8, 8],
              bodyScales: [8, 8, 8],
              dorsalFin: [8, 9, 8],
              caudalFin: [8, 8, 8],
              analFin: [8, 8, 8],
              otherFins: [8, 8, 8],
              pectoralFins: [8, 8, 8],
              operculum: [8, 8, 8],
              colorPattern: [8, 8, 8],
              stabilitySwimming: [8, 8, 8],
              flare: [8, 8, 8],
              overall: [8, 8, 8],
            },
          },
        ],
      },
    },
  ];

  const [selectedDetails, setSelectedDetails] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleShowDetails = (details) => {
    setSelectedDetails(details);
    setIsModalOpen(true);
  };

  return (
    <div className="bg-gray-100 min-h-screen">
      {/* (A) Navbar ด้านบน */}
      <ManagerMenu />

      {/* (B) เว้นระยะด้านบน (pt-16) แทน margin-left */}
      <div className="pt-16 p-8 w-full">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-800">ประวัติการประกวด</h1>
        </div>

        <div className="bg-white shadow-md rounded-lg p-6">
          <div className="grid gap-4">
            {history.map((item) => (
              <div
                key={item.id}
                className="bg-white border rounded-lg p-4 flex items-center justify-between hover:shadow-md transition"
              >
                <div className="flex items-center space-x-4">
                  <Award className="text-yellow-500" size={30} />
                  <div>
                    <h3 className="font-semibold text-gray-800">{item.name}</h3>
                    <div className="flex items-center space-x-2 text-sm text-gray-500">
                      <User size={16} />
                      <span>ผู้ชนะ: {item.winner}</span>
                    </div>
                  </div>
                </div>
                {item.details && (
                  <button
                    className="text-blue-500 hover:bg-blue-100 p-2 rounded flex items-center"
                    onClick={() => handleShowDetails(item.details)}
                  >
                    <Eye size={20} className="mr-2" />
                    ดูรายละเอียด
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>

        <Modal
          isOpen={isModalOpen}
          onRequestClose={() => setIsModalOpen(false)}
          className="fixed inset-0 flex items-center justify-center z-50"
          overlayClassName="fixed inset-0 bg-black bg-opacity-50"
        >
          {selectedDetails && (
            <div className="bg-white rounded-lg p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-gray-800">
                  รายละเอียดการประกวด
                </h2>
                <button
                  onClick={() => setIsModalOpen(false)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <XCircle size={24} />
                </button>
              </div>

              {selectedDetails.top3.map((fish) => (
                <div
                  key={fish.rank}
                  className="bg-gray-50 rounded-lg p-6 mb-6 border"
                >
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-xl font-bold text-gray-800">
                      อันดับ {fish.rank}: {fish.name}
                    </h3>
                    <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm">
                      คะแนนเฉลี่ย {calculateAverageScore(fish.scores)}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="flex items-center space-x-2 mb-2">
                        <User size={16} className="text-gray-500" />
                        <span>ชื่อผู้ใช้: {fish.user}</span>
                      </div>
                      <div className="flex items-center space-x-2 mb-2">
                        <Calendar size={16} className="text-gray-500" />
                        <span>อายุ: {fish.age}</span>
                      </div>
                      <div className="flex items-center space-x-2 mb-2">
                        <Award size={16} className="text-gray-500" />
                        <span>ขนาด: {fish.size}</span>
                      </div>
                      <div className="flex items-center space-x-2 mb-2">
                        <User size={16} className="text-gray-500" />
                        <span>ประเภท: {fish.type}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <User size={16} className="text-gray-500" />
                        <span>ชนิด: {fish.breed}</span>
                      </div>
                    </div>

                    <div className="flex space-x-4">
                      <img
                        src={fish.image}
                        alt={fish.name}
                        className="w-32 h-32 object-cover rounded-lg"
                      />
                      <video
                        src={fish.video}
                        className="w-32 h-32 object-cover rounded-lg"
                        controls
                      />
                    </div>
                  </div>

                  <div className="mt-6">
                    <h4 className="text-lg font-semibold mb-4 text-gray-800">
                      คะแนนที่ได้รับ
                    </h4>
                    <div className="grid grid-cols-3 gap-2">
                      {Object.entries(fish.scores).map(([key, values]) => (
                        <div
                          key={key}
                          className="bg-white border rounded p-3 text-center"
                        >
                          <div className="text-sm text-gray-600 capitalize">
                            {key}
                          </div>
                          <div className="font-bold text-blue-600">
                            {values.join(", ")}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Modal>
      </div>
    </div>
  );
};

export default ContestHistory;

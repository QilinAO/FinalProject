// src/Pages/Manager/ContestManagement.jsx
import React, { useState, useEffect } from "react";
import ManagerMenu from "../../Component/ManagerMenu";
import { ImagePlus, Trash2 } from "lucide-react";
import { db, storage } from "../../backend/config/FirebaseSDK"; 
import { collection, addDoc, Timestamp } from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";

// 1) ตัวอย่าง “ชนิดปลากัดย่อย” ที่จะให้ผู้จัดเลือก
const BETTA_SUBCATEGORIES = [
  {
    id: "shortFin_1_1",
    label: "ครีบสั้น 1.1.1 หางเดี่ยว สีเดียว กลุ่มสีสว่าง",
  },
  {
    id: "shortFin_1_2",
    label: "ครีบสั้น 1.1.2 หางเดี่ยว สีเดียว กลุ่มสีเข้ม",
  },
  {
    id: "shortFin_1_3",
    label: "ครีบสั้น 1.1.3 หางเดี่ยว กลุ่มหลากสี (แฟนซี)",
  },
  {
    id: "longFin_1_2",
    label: "ครีบยาว 1.2.2 หางคู่ รวมทุกประเภทสี",
  },
  {
    id: "special_1_3_6",
    label: "ปลากัดเพศเมีย (ชนิดพิเศษ)",
  },
  // ... ใส่อื่น ๆ ตามรายการที่มี
];

const ContestManagement = () => {
  // 2) formData เพิ่มฟิลด์ใหม่: status, voteOpen, allowedSubcategories
  const [formData, setFormData] = useState({
    name: "",
    shortDescription: "",
    fullDescription: "",
    category: "การประกวด",   // "การประกวด", "ข่าวสารทั่วไป", "ข่าวสารประชาสัมพันธ์"
    startDate: "",
    endDate: "",
    judges: ["", "", ""],
    poster: null,

    // ฟิลด์ใหม่
    status: "draft",             // ตัวอย่าง: "draft" / "open" / "closed" / "finished"
    voteOpen: false,             // เปิดโหวต?
    allowedSubcategories: [],    // Array เก็บ id ของ subcategory ที่เลือก
  });

  // รีเซ็ตฟิลด์วันที่และกรรมการ เมื่อเปลี่ยนเป็นข่าวสาร
  useEffect(() => {
    if (formData.category !== "การประกวด") {
      setFormData((prevData) => ({
        ...prevData,
        startDate: "",
        endDate: "",
        judges: ["", "", ""],
        status: "draft",            // ข่าวสารอาจไม่ต้องมีสถานะ
        voteOpen: false,            // ไม่ต้องโหวต
        allowedSubcategories: [],   // ล้างประเภทปลากัด
      }));
    }
  }, [formData.category]);

  // ----------------------------------------------------
  // ฟังก์ชัน
  // ----------------------------------------------------
  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    if (type === "checkbox" && name === "voteOpen") {
      // กรณีเป็น checkbox สำหรับ voteOpen
      setFormData({ ...formData, voteOpen: checked });
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  // เปลี่ยนค่ากรรมการ
  const handleJudgeEmailChange = (index, email) => {
    const newJudges = [...formData.judges];
    newJudges[index] = email;
    setFormData({ ...formData, judges: newJudges });
  };

  // การอัปโหลดโปสเตอร์
  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFormData({
        ...formData,
        poster: {
          file: file,
          preview: URL.createObjectURL(file),
        },
      });
    }
  };

  const handleRemoveImage = () => {
    setFormData({ ...formData, poster: null });
  };

  // ----------------------------------------------------
  // การเลือก subcategories (ใช้ checkbox)
  // ----------------------------------------------------
  const handleSubcategoryChange = (subcategoryId, checked) => {
    let updated = [...formData.allowedSubcategories];
    if (checked) {
      // ถ้าติ๊ก checkbox => เพิ่มเข้า array
      if (!updated.includes(subcategoryId)) {
        updated.push(subcategoryId);
      }
    } else {
      // ถ้า untick => ลบออกจาก array
      updated = updated.filter((id) => id !== subcategoryId);
    }
    setFormData({ ...formData, allowedSubcategories: updated });
  };

  // ----------------------------------------------------
  // ฟังก์ชันบันทึก
  // ----------------------------------------------------
  const handleConfirmSave = async () => {
    // ตรวจสอบฟิลด์ที่จำเป็น
    if (!formData.poster) {
      alert("กรุณาอัปโหลดโปสเตอร์");
      return;
    }

    if (formData.category === "การประกวด") {
      if (!formData.startDate) {
        alert("กรุณาเลือกวันที่เริ่มต้น");
        return;
      }
      if (!formData.endDate) {
        alert("กรุณาเลือกวันที่สิ้นสุด");
        return;
      }
      // ตรวจสอบรูปแบบวันที่
      const start = new Date(formData.startDate);
      const end = new Date(formData.endDate);
      if (isNaN(start.getTime())) {
        alert("วันที่เริ่มต้นไม่ถูกต้อง");
        return;
      }
      if (isNaN(end.getTime())) {
        alert("วันที่สิ้นสุดไม่ถูกต้อง");
        return;
      }
      if (end < start) {
        alert("วันที่สิ้นสุดต้องหลังจากวันที่เริ่มต้น");
        return;
      }
    }

    try {
      // อัปโหลดภาพโปสเตอร์ไปที่ Firebase Storage
      const storageRef = ref(
        storage,
        `posters/${Date.now()}_${formData.poster.file.name}`
      );
      const uploadResult = await uploadBytes(storageRef, formData.poster.file);
      const posterURL = await getDownloadURL(uploadResult.ref);

      // เตรียมข้อมูลการประกวดหรือข่าวสาร
      const contestData = {
        name: formData.name,
        shortDescription: formData.shortDescription,
        fullDescription: formData.fullDescription,
        category: formData.category,
        posterURL: posterURL,
        createdAt: Timestamp.now(),
      };

      if (formData.category === "การประกวด") {
        // เพิ่มฟิลด์เพิ่มเติมสำหรับการประกวด
        contestData.startDate = Timestamp.fromDate(
          new Date(formData.startDate)
        );
        contestData.endDate = Timestamp.fromDate(new Date(formData.endDate));
        contestData.judges = formData.judges.filter((email) => email !== "");
        // ฟิลด์ที่เพิ่ม:
        contestData.status = formData.status;
        contestData.voteOpen = formData.voteOpen;
        contestData.allowedSubcategories = formData.allowedSubcategories; // array ของ subcat id

        // ตัวอย่างตั้งค่าเริ่มต้น
        if (!contestData.status) {
          contestData.status = "draft";
        }
      }

      const docRef = await addDoc(collection(db, "contests"), contestData);
      console.log("Document written with ID: ", docRef.id);
      alert("เพิ่มข้อมูลสำเร็จ!");

      // รีเซ็ตฟอร์ม
      setFormData({
        name: "",
        shortDescription: "",
        fullDescription: "",
        category: "การประกวด",
        startDate: "",
        endDate: "",
        judges: ["", "", ""],
        poster: null,
        status: "draft",
        voteOpen: false,
        allowedSubcategories: [],
      });
    } catch (error) {
      console.error("Error adding document: ", error);
      alert("เกิดข้อผิดพลาดในการบันทึกข้อมูล");
    }
  };

  // ----------------------------------------------------
  // Render
  // ----------------------------------------------------
  return (
    <div className="bg-gray-100 min-h-screen">
      <ManagerMenu />
      <div className="pt-16 p-8 w-full">
        <h1 className="text-3xl font-bold mb-8 text-gray-800">
          สร้างการประกวดหรือข่าวสาร
        </h1>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleConfirmSave();
          }}
          className="bg-white p-8 rounded-lg shadow-md"
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* ประเภทข่าวสาร */}
            <div>
              <label className="block text-gray-700 font-semibold mb-2">
                ประเภทข่าวสาร:
              </label>
              <select
                name="category"
                value={formData.category}
                onChange={handleInputChange}
                className="w-full px-4 py-2 border rounded-md focus:outline-blue-500"
                required
              >
                <option value="การประกวด">การประกวด</option>
                <option value="ข่าวสารทั่วไป">ข่าวสารทั่วไป</option>
                <option value="ข่าวสารประชาสัมพันธ์">
                  ข่าวสารประชาสัมพันธ์
                </option>
              </select>
            </div>

            {/* ชื่อโครงการหรือข่าวสาร */}
            <div>
              <label className="block text-gray-700 font-semibold mb-2">
                ชื่อโครงการหรือข่าวสาร:
              </label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                className="w-full px-4 py-2 border rounded-md focus:outline-blue-500"
                placeholder="กรอกชื่อโครงการหรือข่าวสาร"
                required
              />
            </div>
          </div>

          {/* คำอธิบายย่อ */}
          <div className="mt-6">
            <label className="block text-gray-700 font-semibold mb-2">
              คำอธิบายโครงการโดยย่อ:
            </label>
            <textarea
              name="shortDescription"
              value={formData.shortDescription}
              onChange={handleInputChange}
              className="w-full px-4 py-2 border rounded-md focus:outline-blue-500"
              placeholder="กรอกคำอธิบายโครงการโดยย่อ"
              rows="3"
              required
            />
          </div>

          {/* คำอธิบายละเอียด */}
          <div className="mt-6">
            <label className="block text-gray-700 font-semibold mb-2">
              คำอธิบายโครงการโดยละเอียด:
            </label>
            <textarea
              name="fullDescription"
              value={formData.fullDescription}
              onChange={handleInputChange}
              className="w-full px-4 py-2 border rounded-md focus:outline-blue-500"
              placeholder="กรอกคำอธิบายโครงการโดยละเอียด"
              rows="6"
              required
            />
          </div>

          {/* ส่วนเพิ่มเติมถ้าเป็น "การประกวด" */}
          {formData.category === "การประกวด" && (
            <>
              {/* สถานะการประกวด */}
              <div className="mt-6">
                <label className="block text-gray-700 font-semibold mb-2">
                  สถานะการประกวด:
                </label>
                <select
                  name="status"
                  value={formData.status}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2 border rounded-md focus:outline-blue-500"
                >
                  <option value="draft">ร่าง (ยังไม่เปิดรับ)</option>
                  <option value="กำลังดำเนินการ">กำลังดำเนินการ / เปิดรับสมัคร</option>
                  <option value="ปิดรับสมัคร">ปิดรับสมัคร</option>
                  <option value="ประกาศผล">ประกาศผล / จบงาน</option>
                </select>
              </div>

              {/* เปิด/ปิดโหวต */}
              <div className="mt-4 flex items-center space-x-3">
                <input
                  type="checkbox"
                  id="voteOpen"
                  name="voteOpen"
                  checked={formData.voteOpen}
                  onChange={handleInputChange}
                  className="h-5 w-5 text-blue-600"
                />
                <label htmlFor="voteOpen" className="text-gray-700 font-semibold">
                  เปิดโหวตผู้เข้าชม?
                </label>
              </div>

              {/* วันที่เริ่ม-สิ้นสุด */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                <div>
                  <label className="block text-gray-700 font-semibold mb-2">
                    วันที่เริ่มต้น:
                  </label>
                  <input
                    type="date"
                    name="startDate"
                    value={formData.startDate}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border rounded-md focus:outline-blue-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-gray-700 font-semibold mb-2">
                    วันที่สิ้นสุด:
                  </label>
                  <input
                    type="date"
                    name="endDate"
                    value={formData.endDate}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border rounded-md focus:outline-blue-500"
                    required
                  />
                </div>
              </div>

              {/* กรรมการ */}
              <div className="mt-6">
                <label className="block text-gray-700 font-semibold mb-2">
                  กรรมการ:
                </label>
                <div className="space-y-4">
                  {formData.judges.map((judge, index) => (
                    <input
                      key={index}
                      type="email"
                      value={judge}
                      onChange={(e) =>
                        handleJudgeEmailChange(index, e.target.value)
                      }
                      className="w-full px-4 py-2 border rounded-md focus:outline-blue-500"
                      placeholder={`กรอกอีเมลกรรมการคนที่ ${index + 1}`}
                      required={index < 1}
                    />
                  ))}
                </div>
              </div>

              {/* เลือก subcategory (ระบบประกวดปลากัด) */}
              <div className="mt-6">
                <label className="block text-gray-700 font-semibold mb-2">
                  ประเภทปลากัด (เลือกได้หลายประเภท):
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {BETTA_SUBCATEGORIES.map((subcat) => {
                    const checked = formData.allowedSubcategories.includes(
                      subcat.id
                    );
                    return (
                      <label
                        key={subcat.id}
                        className="flex items-center space-x-2"
                      >
                        <input
                          type="checkbox"
                          checked={checked}
                          onChange={(e) =>
                            handleSubcategoryChange(subcat.id, e.target.checked)
                          }
                        />
                        <span>{subcat.label}</span>
                      </label>
                    );
                  })}
                </div>
              </div>
            </>
          )}

          {/* อัปโหลดโปสเตอร์ */}
          <div className="mt-6">
            <label className="block text-gray-700 font-semibold mb-2">
              อัปโหลดโปสเตอร์:
            </label>
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center relative">
              <input
                type="file"
                id="poster-upload"
                onChange={handleImageChange}
                className="hidden"
                accept="image/*"
              />
              <label
                htmlFor="poster-upload"
                className="cursor-pointer flex flex-col items-center justify-center"
              >
                {formData.poster ? (
                  <div className="relative">
                    <img
                      src={formData.poster.preview}
                      alt="Poster preview"
                      className="max-h-48 rounded-md mb-4"
                    />
                    <button
                      type="button"
                      onClick={handleRemoveImage}
                      className="absolute top-2 right-2 bg-red-500 text-white p-1 rounded-full"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                ) : (
                  <div className="text-gray-500">
                    <ImagePlus size={48} className="mx-auto mb-2" />
                    <p>คลิกเพื่ออัปโหลดรูปภาพ</p>
                  </div>
                )}
              </label>
            </div>
          </div>

          {/* ปุ่มบันทึกข้อมูล */}
          <button
            type="submit"
            className="mt-8 w-full bg-blue-600 text-white py-3 rounded-md hover:bg-blue-700 transition-colors"
          >
            บันทึกข้อมูล
          </button>
        </form>
      </div>
    </div>
  );
};

export default ContestManagement;

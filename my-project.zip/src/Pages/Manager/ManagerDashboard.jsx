import React, { useState, useEffect } from "react";
import { Bar, Pie } from "react-chartjs-2";
import {
  Chart as ChartJS,
  BarElement,
  CategoryScale,
  LinearScale,
  ArcElement,
  Legend,
} from "chart.js";
import ManagerMenu from "../../Component/ManagerMenu";
import { useUserProfile } from "../../context/UserProfileContext";
import { ToastContainer, toast } from "react-toastify";
import { FiXCircle } from "react-icons/fi";
import "react-toastify/dist/ReactToastify.css";
import { db } from "../../backend/config/FirebaseSDK"; // นำเข้า Firestore instance
import { collection, getDocs } from "firebase/firestore";

// ลงทะเบียน ChartJS components
ChartJS.register(CategoryScale, LinearScale, BarElement, ArcElement, Legend);

const ManagerDashboard = () => {
  const { profileData, loading: profileLoading } = useUserProfile();
  const [dashboardStats, setDashboardStats] = useState({
    totalContests: 0,
    ongoingContests: 0,
    completedContests: 0,
    canceledContests: 0,
  });

  const [notifications, setNotifications] = useState([
    { id: 1, message: "มีการประกวดใหม่ถูกเพิ่ม: การประกวดปลากัดครั้งที่ 3" },
    { id: 2, message: "คุณได้กำหนดกรรมการใหม่สำเร็จใน การประกวดปลากัดครั้งที่ 2" },
    { id: 3, message: "ผลการแข่งขันครั้งที่ 2 ได้รับการอัปเดต" },
  ]);

  const [dataLoading, setDataLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        // ดึงข้อมูลจาก collection 'contests'
        const contestsCollection = collection(db, "contests");
        const contestsSnapshot = await getDocs(contestsCollection);
        const contests = contestsSnapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));

        // คำนวณสถิติจากข้อมูลที่ดึงมา
        const stats = {
          totalContests: contests.length,
          ongoingContests: contests.filter((c) => c.status === "กำลังดำเนินการ").length,
          completedContests: contests.filter((c) => c.status === "เสร็จสิ้น").length,
          canceledContests: contests.filter((c) => c.status === "ยกเลิก").length,
        
          // เพิ่มใหม่
          draftContests: contests.filter((c) => c.status === "draft").length,
          closedContests: contests.filter((c) => c.status === "ปิดรับสมัคร").length,
          finishedContests: contests.filter((c) => c.status === "ประกาศผล").length,
        };
        

        setDashboardStats(stats);
      } catch (error) {
        console.error("Error fetching data:", error);
        toast.error("เกิดข้อผิดพลาดในการดึงข้อมูลจากฐานข้อมูล");
      } finally {
        setDataLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleDeleteNotification = (id) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
    toast.info("การแจ้งเตือนถูกลบเรียบร้อยแล้ว");
  };

  const barData = {
    labels: ["กำลังดำเนินการ", "เสร็จสิ้น", "ยกเลิก"],
    datasets: [
      {
        label: "จำนวนการประกวด",
        data: [
          dashboardStats.ongoingContests,
          dashboardStats.completedContests,
          dashboardStats.canceledContests
        ],
        backgroundColor: ["#4CAF50", "#FF5733", "#9E9E9E"]
      }
    ]
  };
  
  const pieData = {
    labels: ["กำลังดำเนินการ", "เสร็จสิ้น", "ยกเลิก"],
    datasets: [
      {
        data: [
          dashboardStats.ongoingContests,
          dashboardStats.completedContests,
          dashboardStats.canceledContests
        ],
        backgroundColor: ["#4CAF50", "#FF5733", "#9E9E9E"]
      }
    ]
  };  

  if (profileLoading || dataLoading) {
    return (
      <div className="bg-gray-100 min-h-screen">
        {/* หาก ManagerMenu เป็น Navbar Top */}
        <ManagerMenu />
        <div className="pt-16 p-8 w-full flex items-center justify-center">
          <p className="text-gray-700">กำลังโหลดข้อมูล...</p>
        </div>
      </div>
    );
  }

  if (!profileData) {
    return (
      <div className="bg-gray-100 min-h-screen">
        <ManagerMenu />
        <div className="pt-16 p-8 w-full flex items-center justify-center">
          <p className="text-center text-gray-700">
            กรุณาเข้าสู่ระบบเพื่อใช้งานหน้านี้
          </p>
        </div>
      </div>
    );
  }

  if (profileData.role !== "manager") {
    return (
      <div className="bg-gray-100 min-h-screen">
        <ManagerMenu />
        <div className="pt-16 p-8 w-full flex items-center justify-center">
          <p className="text-center text-gray-700">คุณไม่มีสิทธิ์เข้าถึงหน้านี้</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-100 min-h-screen">
      {/* แสดง Navbar ด้านบน */}
      <ManagerMenu />

      {/* pt-16 เพื่อเว้นระยะด้านบนไม่ให้ถูก Navbar บัง */}
      <div className="pt-16 p-6">
        <ToastContainer />
        <h1 className="text-3xl font-bold mb-6 text-gray-800">แดชบอร์ดผู้จัดการ</h1>

        <div className="grid grid-cols-1 md:grid-cols-6 gap-6 mb-6">
          {[
            {
              label: "โครงการทั้งหมด",
              value: dashboardStats.totalContests,
              color: "bg-green-50",
              border: "border-green-400",
            },
            {
              label: "กำลังจัดการแข่งขัน",
              value: dashboardStats.ongoingContests,
              color: "bg-cyan-50",
              border: "border-cyan-400",
            },
            {
              label: "เสร็จสิ้นแล้ว",
              value: dashboardStats.completedContests,
              color: "bg-lime-50",
              border: "border-lime-400",
            },
            {
              label: "ยกเลิก",
              value: dashboardStats.canceledContests,
              color: "bg-red-50",
              border: "border-red-400",
            },
          ].map((stat, index) => (
            <div
              key={index}
              className={`p-4 rounded-lg shadow-md ${stat.color} border-l-4 ${stat.border}`}
            >
              <h3 className="text-lg font-semibold text-gray-600 mb-2">
                {stat.label}
              </h3>
              <p className="text-2xl font-bold text-gray-800">{stat.value}</p>
            </div>
          ))}
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md mb-6">
          <h2 className="text-xl font-bold mb-4 text-gray-800">การแจ้งเตือน</h2>
          <ul className="space-y-2">
            {notifications.map((n) => (
              <li
                key={n.id}
                className="bg-gray-100 p-3 rounded-md border-l-4 border-blue-500 flex justify-between items-center"
              >
                {n.message}
                <button
                  className="text-red-500 hover:text-red-700 ml-4"
                  onClick={() => handleDeleteNotification(n.id)}
                >
                  <FiXCircle size={20} />
                </button>
              </li>
            ))}
          </ul>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-bold mb-4 text-gray-800">สถิติการประกวด</h2>
            <Bar data={barData} />
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-bold mb-4 text-gray-800">สัดส่วนการประกวด</h2>
            <Pie data={pieData} />
          </div>
        </div>
      </div>
      <ToastContainer />
    </div>
  );
};

export default ManagerDashboard;

// src/Pages/Manager/CompetitionResults.jsx

import React, { useState } from "react";
import { jsPDF } from "jspdf";
import * as XLSX from "xlsx";
import {
  FiSearch,
  FiFilter,
  FiDownload,
  FiFileText,
  FiTable,
} from "react-icons/fi";
import ManagerMenu from "../../Component/ManagerMenu";

const CompetitionResults = () => {
  const [search, setSearch] = useState("");
  const [minScore, setMinScore] = useState("");
  const [maxScore, setMaxScore] = useState("");
  const [sortConfig, setSortConfig] = useState({ key: "id", direction: "asc" });

  // ข้อมูลจำลอง
  const results = [
    { id: 1, contestName: "การประกวดปลากัดสวยงาม", name: "John Doe", score: 85 },
    { id: 2, contestName: "การประกวดปลากัดยักษ์", name: "Jane Smith", score: 78 },
    { id: 3, contestName: "การประกวดปลากัดยอดเยี่ยม", name: "Bob Brown", score: 92 },
    { id: 4, contestName: "การประกวดปลากัดน้ำเงิน", name: "Alice Green", score: 67 },
  ];

  // ฟิลเตอร์และเรียงลำดับ
  const filteredResults = results
    .filter((result) => {
      const matchSearch = result.name
        .toLowerCase()
        .includes(search.toLowerCase());
      const matchMinScore = minScore === "" || result.score >= Number(minScore);
      const matchMaxScore = maxScore === "" || result.score <= Number(maxScore);
      return matchSearch && matchMinScore && matchMaxScore;
    })
    .sort((a, b) => {
      if (a[sortConfig.key] < b[sortConfig.key]) {
        return sortConfig.direction === "asc" ? -1 : 1;
      }
      if (a[sortConfig.key] > b[sortConfig.key]) {
        return sortConfig.direction === "asc" ? 1 : -1;
      }
      return 0;
    });

  // จัดการ Export PDF
  const handleExportPDF = () => {
    const doc = new jsPDF();
    doc.setFont("helvetica");
    doc.setFontSize(16);
    doc.text("ผลคะแนนการแข่งขัน", 10, 10);

    doc.setFontSize(12);
    filteredResults.forEach((result, index) => {
      doc.text(
        `${index + 1}. ${result.contestName} - ${result.name} - คะแนน: ${result.score}`,
        10,
        20 + index * 10
      );
    });

    doc.save("Competition_Results.pdf");
  };

  // จัดการ Export Excel
  const handleExportExcel = () => {
    const worksheet = XLSX.utils.json_to_sheet(filteredResults);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Results");
    XLSX.writeFile(workbook, "Competition_Results.xlsx");
  };

  // ฟังก์ชันสลับทิศทางเรียงลำดับ
  const handleSort = (key) => {
    setSortConfig((prev) => ({
      key,
      direction: prev.key === key && prev.direction === "asc" ? "desc" : "asc",
    }));
  };

  return (
    <div className="bg-gray-100 min-h-screen">
      {/* Navbar (ManagerMenu) ด้านบน */}
      <ManagerMenu />

      {/* เว้นระยะด้านบน (pt-16) เพื่อไม่ให้คอนเทนต์ทับเมนู */}
      <div className="pt-16 p-4 w-full">
        <div className="bg-white shadow-md rounded-lg p-6">
          <h1 className="text-3xl font-bold text-gray-800 mb-6 flex items-center">
            <FiTable className="mr-3 text-blue-600" />
            ผลคะแนนการแข่งขัน
          </h1>

          {/* แถวกรอง (ค้นหา + คะแนน) */}
          <div className="mb-6 grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* ช่องค้นหา */}
            <div className="relative">
              <FiSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="ค้นหาชื่อผู้เลี้ยง"
                className="w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
            {/* คะแนนขั้นต่ำ */}
            <div className="relative">
              <FiFilter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="number"
                placeholder="คะแนนขั้นต่ำ"
                className="w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={minScore}
                onChange={(e) => setMinScore(e.target.value)}
              />
            </div>
            {/* คะแนนสูงสุด */}
            <div className="relative">
              <FiFilter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="number"
                placeholder="คะแนนสูงสุด"
                className="w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={maxScore}
                onChange={(e) => setMaxScore(e.target.value)}
              />
            </div>
          </div>

          {/* ปุ่ม Export */}
          <div className="mb-4 flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-4">
            <button
              onClick={handleExportPDF}
              className="flex items-center justify-center bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition"
            >
              <FiFileText className="mr-2" />
              Export PDF
            </button>
            <button
              onClick={handleExportExcel}
              className="flex items-center justify-center bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 transition"
            >
              <FiDownload className="mr-2" />
              Export Excel
            </button>
          </div>

          {/* ตารางผลคะแนน */}
          <div className="overflow-x-auto">
            <table className="w-full bg-white shadow-md rounded-lg overflow-hidden">
              <thead className="bg-blue-50">
                <tr>
                  {["id", "contestName", "name", "score"].map((key) => (
                    <th
                      key={key}
                      onClick={() => handleSort(key)}
                      className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-blue-100"
                    >
                      {key === "id" && "ID"}
                      {key === "contestName" && "ชื่อรายการประกวด"}
                      {key === "name" && "ชื่อผู้เลี้ยง"}
                      {key === "score" && "คะแนน"}
                      {sortConfig.key === key && (
                        <span className="ml-2">
                          {sortConfig.direction === "asc" ? "▲" : "▼"}
                        </span>
                      )}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filteredResults.map((result) => (
                  <tr
                    key={result.id}
                    className="border-b hover:bg-gray-50 transition"
                  >
                    <td className="px-4 py-3">{result.id}</td>
                    <td className="px-4 py-3">{result.contestName}</td>
                    <td className="px-4 py-3">{result.name}</td>
                    <td className="px-4 py-3">{result.score}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* จำนวนรายการที่แสดง */}
          <p className="mt-4 text-gray-600 text-right">
            แสดง {filteredResults.length} รายการ
          </p>
        </div>
      </div>
    </div>
  );
};

export default CompetitionResults;

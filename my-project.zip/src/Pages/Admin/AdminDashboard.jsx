import React, { useEffect, useState } from "react";
import { useUserProfile } from "../../context/UserProfileContext";
import { PieChart, Pie, Cell, Legend, Tooltip } from "recharts";
import { Users, UserPlus, Newspaper } from "lucide-react";

const AdminDashboard = () => {
  const { profileData, loading } = useUserProfile();
  const [allUsers, setAllUsers] = useState([]);
  const [newUsersThisMonth, setNewUsersThisMonth] = useState(0);
  const [roleCounts, setRoleCounts] = useState({ admin: 0, user: 0, guest: 0 });
  const [recentUsers, setRecentUsers] = useState([]);
  const [news, setNews] = useState([
    {
      id: 1,
      title: "การอัพเดตระบบครั้งใหญ่",
      date: "2025-01-20",
      content: "เราได้อัพเดตฟีเจอร์ใหม่หลายอย่างเพื่อเพิ่มประสิทธิภาพการใช้งาน",
    },
    {
      id: 2,
      title: "แนะนำฟีเจอร์ใหม่",
      date: "2025-01-18",
      content: "ระบบการจัดการผู้ใช้แบบใหม่พร้อมใช้งานแล้ว",
    },
  ]);

  // ดึงข้อมูลจากเซิร์ฟเวอร์
  useEffect(() => {
    const fetchUsersFromServer = async () => {
      try {
        const response = await fetch("http://localhost:3000/users");
        if (!response.ok) throw new Error("Failed to fetch users");
        const usersData = await response.json();
        setAllUsers(usersData);

        const currentMonth = new Date().getMonth();
        const newUsers = usersData.filter(
          (user) => new Date(user.createdAt).getMonth() === currentMonth
        );
        setNewUsersThisMonth(newUsers.length);

        const counts = usersData.reduce(
          (acc, user) => {
            acc[user.role] = (acc[user.role] || 0) + 1;
            return acc;
          },
          { admin: 0, user: 0, guest: 0 }
        );
        setRoleCounts(counts);

        setRecentUsers(usersData.slice(0, 10)); // แสดงผู้ใช้ล่าสุด 10 คน
      } catch (error) {
        console.error("Error fetching users:", error);
      }
    };

    fetchUsersFromServer();
  }, []);

  if (loading)
    return (
      <div className="flex justify-center items-center h-screen">
        กำลังโหลดข้อมูล...
      </div>
    );
  if (!profileData)
    return (
      <div className="flex justify-center items-center h-screen">
        กรุณาเข้าสู่ระบบเพื่อใช้งานหน้านี้
      </div>
    );
  if (profileData.role !== "admin")
    return (
      <div className="flex justify-center items-center h-screen">
        คุณไม่มีสิทธิ์เข้าถึงหน้านี้
      </div>
    );

  // ข้อมูลสำหรับกราฟวงกลม
  const pieData = [
    { name: "แอดมิน", value: roleCounts.admin },
    { name: "ผู้ใช้", value: roleCounts.user },
    { name: "ผู้เยี่ยมชม", value: roleCounts.guest },
  ];

  const COLORS = ["#FF6B6B", "#4ECDC4", "#45B7D1"];

  return (
    <div className="bg-gray-50 min-h-screen">
      {/* (A) AdminMenu (Navbar) จะอยู่ใน App.jsx หรือส่วน Layout ก็ได้ */}
      {/* สมมติว่าคุณ import AdminMenu ไว้ที่ App.jsx ข้างบนแล้ว จึงไม่ต้องใส่ซ้ำที่นี่ */}
      
      {/* (B) เว้นด้านบนป้องกันเมนูทับ (pt-20) */}
      <div className="pt-20 p-8">
        <h1 className="text-3xl font-bold mb-6 text-gray-800">
          แดชบอร์ดผู้ดูแลระบบ
        </h1>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow-lg p-6">
            <div className="flex items-center">
              <Users className="h-8 w-8 text-blue-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">
                  จำนวนผู้ใช้ทั้งหมด
                </p>
                <h3 className="text-2xl font-bold text-gray-700">
                  {allUsers.length}
                </h3>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-lg p-6">
            <div className="flex items-center">
              <UserPlus className="h-8 w-8 text-green-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">
                  ผู้ใช้ใหม่เดือนนี้
                </p>
                <h3 className="text-2xl font-bold text-gray-700">
                  {newUsersThisMonth}
                </h3>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-lg p-6">
            <div className="flex items-center">
              <Newspaper className="h-8 w-8 text-purple-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">
                  ข่าวสารล่าสุด
                </p>
                <h3 className="text-2xl font-bold text-gray-700">
                  {news.length}
                </h3>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* User Role Chart */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">
              สัดส่วนประเภทผู้ใช้
            </h2>
            <div className="h-64 flex justify-center">
              <PieChart width={300} height={250}>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                  label
                >
                  {pieData.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={COLORS[index % COLORS.length]}
                    />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </div>
          </div>

          {/* Latest News */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">
              ข่าวสารล่าสุด
            </h2>
            <div className="space-y-4">
              {news.map((item) => (
                <div key={item.id} className="border-b border-gray-200 pb-4">
                  <h3 className="text-lg font-medium text-gray-800">
                    {item.title}
                  </h3>
                  <p className="text-sm text-gray-500 mb-2">
                    {new Date(item.date).toLocaleDateString("th-TH")}
                  </p>
                  <p className="text-gray-600">{item.content}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Recent Users Table */}
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h2 className="text-xl font-semibold text-gray-800 mb-4">
            ผู้ใช้ล่าสุด
          </h2>
          <div className="overflow-x-auto">
            <table className="min-w-full">
              <thead>
                <tr className="bg-gray-50">
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    ลำดับ
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    ชื่อผู้ใช้
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    อีเมล
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    บทบาทผู้ใช้
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {recentUsers.map((user, index) => (
                  <tr key={index} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {index + 1}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">
                        {user.username || "ไม่ระบุ"}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-500">
                        {user.email || "ไม่ระบุ"}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {user.role || "ไม่ระบุ"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;

import React, { useState, useEffect } from "react";
import { useUserProfile } from "../../context/UserProfileContext";
import { toast } from "react-toastify";
import { Search, Edit, Key, Trash } from "lucide-react";
import "react-toastify/dist/ReactToastify.css";

const ManageUser = () => {
  const [users, setUsers] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [searchType, setSearchType] = useState("email");
  const [editingUser, setEditingUser] = useState(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showResetModal, setShowResetModal] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  const { profileData, loading } = useUserProfile();
  const [newUser, setNewUser] = useState({ username: "", email: "", role: "user" });
  const [showCreateModal, setShowCreateModal] = useState(false);

  const handleCreateUser = async () => {
    try {
      const token = localStorage.getItem("token");
      const response = await fetch("http://localhost:3000/users", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(newUser),
      });

      if (!response.ok) {
        const errorResponse = await response.json();
        toast.error(
          `การสร้างผู้ใช้ล้มเหลว: ${errorResponse.message || "Unknown error"}`
        );
        return;
      }

      await fetchUsers(); // ดึงข้อมูลผู้ใช้ใหม่
      setShowCreateModal(false);
      toast.success("สร้างผู้ใช้สำเร็จ");
    } catch (error) {
      console.error("Error creating user:", error);
      toast.error("เกิดข้อผิดพลาดในการสร้างผู้ใช้");
    }
  };

  // ดึงข้อมูลผู้ใช้เมื่อโหลดหน้า
  const fetchUsers = async () => {
    try {
      const token = localStorage.getItem("token");
      const response = await fetch("http://localhost:3000/users", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      if (!response.ok) throw new Error("Failed to fetch users");
      const data = await response.json();
      setUsers(data);
      setFilteredUsers(data);
    } catch (error) {
      console.error("Error fetching users:", error);
      toast.error("เกิดข้อผิดพลาดในการดึงข้อมูลผู้ใช้");
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  // ฟังก์ชันค้นหาผู้ใช้
  const handleSearch = () => {
    const filtered = users.filter((user) =>
      user[searchType]?.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredUsers(filtered);
  };

  // ฟังก์ชันอัปเดตข้อมูลผู้ใช้
  const handleUpdateUser = async () => {
    if (!editingUser?.id) {
      toast.error("ไม่มีผู้ใช้ที่กำลังแก้ไข");
      return;
    }

    try {
      const token = localStorage.getItem("token");
      const response = await fetch(
        `http://localhost:3000/users/${editingUser.id}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            username: editingUser.username,
            email: editingUser.email,
            role: editingUser.role,
          }),
        }
      );

      if (!response.ok) {
        const errorResponse = await response.json();
        toast.error(
          `การอัปเดตล้มเหลว: ${errorResponse.message || "Unknown error"}`
        );
        return;
      }

      await fetchUsers();
      setShowEditModal(false);
      setEditingUser(null);
      toast.success("อัปเดตข้อมูลผู้ใช้สำเร็จ");
    } catch (error) {
      console.error("Error updating user:", error);
      toast.error("เกิดข้อผิดพลาดในการอัปเดตข้อมูล");
    }
  };

  // ฟังก์ชันลบผู้ใช้
  const handleDeleteUser = async (userId) => {
    try {
      const token = localStorage.getItem("token");
      const response = await fetch(`http://localhost:3000/users/${userId}`, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        toast.error("การลบผู้ใช้งานล้มเหลว");
        return;
      }

      toast.success("ลบผู้ใช้สำเร็จ");
      await fetchUsers();
    } catch (error) {
      console.error("Error deleting user:", error);
      toast.error("เกิดข้อผิดพลาดในการลบผู้ใช้");
    }
  };

  // ฟังก์ชันรีเซ็ตรหัสผ่าน
  const handleResetPassword = async () => {
    if (!selectedUser?.id) {
      toast.error("ไม่มีผู้ใช้ที่ถูกเลือก");
      return;
    }

    try {
      const token = localStorage.getItem("token");
      const response = await fetch(
        `http://localhost:3000/users/${selectedUser.id}/reset-password`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      if (!response.ok) throw new Error("Failed to reset password");

      await fetchUsers();
      setShowResetModal(false);
      setSelectedUser(null);
      toast.success("รีเซ็ตรหัสผ่านสำเร็จ");
    } catch (error) {
      console.error("Error resetting password:", error);
      toast.error("เกิดข้อผิดพลาดในการรีเซ็ตรหัสผ่าน");
    }
  };

  if (loading)
    return (
      <div className="flex justify-center items-center h-screen">
        กำลังโหลดข้อมูล...
      </div>
    );
  if (!profileData)
    return (
      <div className="flex justify-center items-center h-screen">
        กรุณาล็อคอินเพื่อเข้าถึงหน้านี้
      </div>
    );
  if (profileData.role !== "admin")
    return (
      <div className="flex justify-center items-center h-screen">
        คุณไม่มีสิทธิ์เข้าถึงหน้านี้
      </div>
    );

  return (
    <div className="bg-gray-50 min-h-screen">
      {/* AdminMenu (Navbar) อาจอยู่ใน App.jsx แทน */}
      <div className="pt-20 p-8 w-full">
        <h1 className="text-3xl font-bold mb-6 text-gray-800">จัดการผู้ใช้</h1>

        <div className="flex mb-4">
          <button
            onClick={() => setShowCreateModal(true)}
            className="bg-green-500 text-white px-4 py-2 rounded-lg"
          >
            สร้างผู้ใช้ใหม่
          </button>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
          <div className="flex gap-4 items-center">
            <select
              value={searchType}
              onChange={(e) => setSearchType(e.target.value)}
              className="border rounded-lg py-2 px-4"
            >
              <option value="email">ค้นหาด้วยอีเมล</option>
              <option value="username">ค้นหาด้วยชื่อผู้ใช้</option>
            </select>
            <div className="flex-1 relative">
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder={`ค้นหาด้วย${
                  searchType === "email" ? "อีเมล" : "ชื่อผู้ใช้"
                }...`}
                className="w-full border rounded-lg py-2 px-4 pr-10"
              />
              <Search
                className="absolute right-3 top-2.5 text-gray-400"
                size={20}
              />
            </div>
            <button
              onClick={handleSearch}
              className="bg-blue-500 hover:bg-blue-600 text-white py-2 px-6 rounded-lg transition duration-200"
            >
              ค้นหา
            </button>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <table className="min-w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  #
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  ชื่อผู้ใช้
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  อีเมล
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  บทบาท
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  จัดการ
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredUsers.map((user, index) => (
                <tr key={user.id || index} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {index + 1}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {user.username || "ไม่ระบุ"}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {user.email || "ไม่ระบุ"}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {user.role || "ไม่ระบุ"}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <button
                      onClick={() => {
                        setEditingUser(user);
                        setShowEditModal(true);
                      }}
                      className="text-blue-600 hover:text-blue-900 mr-4"
                    >
                      <Edit size={18} className="inline mr-1" /> แก้ไข
                    </button>
                    <button
                      onClick={() => {
                        setSelectedUser(user);
                        setShowResetModal(true);
                      }}
                      className="text-orange-600 hover:text-orange-900 mr-4"
                    >
                      <Key size={18} className="inline mr-1" /> รีเซ็ตรหัสผ่าน
                    </button>
                    <button
                      onClick={() => handleDeleteUser(user.id)}
                      className="text-red-600 hover:text-red-900"
                    >
                      <Trash size={18} className="inline mr-1" /> ลบ
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Modal แก้ไขผู้ใช้ */}
        {showEditModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
            <div className="bg-white rounded-lg p-8 max-w-md w-full">
              <h2 className="text-2xl font-bold mb-6">แก้ไขข้อมูลผู้ใช้</h2>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleUpdateUser();
                }}
              >
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      ชื่อผู้ใช้
                    </label>
                    <input
                      type="text"
                      value={editingUser?.username || ""}
                      onChange={(e) =>
                        setEditingUser({
                          ...editingUser,
                          username: e.target.value,
                        })
                      }
                      className="w-full border rounded-lg py-2 px-4"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      อีเมล
                    </label>
                    <input
                      type="email"
                      value={editingUser?.email || ""}
                      onChange={(e) =>
                        setEditingUser({
                          ...editingUser,
                          email: e.target.value,
                        })
                      }
                      className="w-full border rounded-lg py-2 px-4"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      บทบาท
                    </label>
                    <select
                      value={editingUser?.role || ""}
                      onChange={(e) =>
                        setEditingUser({ ...editingUser, role: e.target.value })
                      }
                      className="w-full border rounded-lg py-2 px-4"
                    >
                      <option value="admin">Admin</option>
                      <option value="user">User</option>
                      <option value="manager">Manager</option>
                      <option value="expert">Expert</option>
                    </select>
                  </div>
                </div>
                <div className="mt-6 flex justify-end gap-4">
                  <button
                    type="button"
                    onClick={() => setShowEditModal(false)}
                    className="px-4 py-2 text-gray-600 hover:text-gray-800"
                  >
                    ยกเลิก
                  </button>
                  <button
                    type="submit"
                    className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg"
                  >
                    บันทึก
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>

      {/* Modal สร้างผู้ใช้ใหม่ */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-white rounded-lg p-8 max-w-md w-full">
            <h2 className="text-2xl font-bold mb-6">สร้างผู้ใช้ใหม่</h2>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleCreateUser();
              }}
            >
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    ชื่อผู้ใช้
                  </label>
                  <input
                    type="text"
                    value={newUser.username}
                    onChange={(e) =>
                      setNewUser({ ...newUser, username: e.target.value })
                    }
                    className="w-full border rounded-lg py-2 px-4"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    อีเมล
                  </label>
                  <input
                    type="email"
                    value={newUser.email}
                    onChange={(e) =>
                      setNewUser({ ...newUser, email: e.target.value })
                    }
                    className="w-full border rounded-lg py-2 px-4"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    บทบาท
                  </label>
                  <select
                    value={newUser.role}
                    onChange={(e) =>
                      setNewUser({ ...newUser, role: e.target.value })
                    }
                    className="w-full border rounded-lg py-2 px-4"
                  >
                    <option value="admin">Admin</option>
                    <option value="user">User</option>
                    <option value="manager">Manager</option>
                    <option value="expert">Expert</option>
                  </select>
                </div>
              </div>
              <div className="mt-6 flex justify-end gap-4">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 text-gray-600 hover:text-gray-800"
                >
                  ยกเลิก
                </button>
                <button
                  type="submit"
                  className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg"
                >
                  บันทึก
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal รีเซ็ตรหัสผ่าน */}
      {showResetModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-white rounded-lg p-8 max-w-md w-full">
            <h2 className="text-2xl font-bold mb-6">รีเซ็ตรหัสผ่าน</h2>
            <p>คุณต้องการรีเซ็ตรหัสผ่านของผู้ใช้งานนี้หรือไม่?</p>
            <div className="mt-6 flex justify-end gap-4">
              <button
                type="button"
                onClick={() => setShowResetModal(false)}
                className="px-4 py-2 text-gray-600 hover:text-gray-800"
              >
                ยกเลิก
              </button>
              <button
                onClick={() => {
                  handleResetPassword();
                }}
                className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg"
              >
                รีเซ็ตรหัสผ่าน
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ManageUser;

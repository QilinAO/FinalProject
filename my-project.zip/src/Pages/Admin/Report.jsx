// src/Pages/Admin/Report.jsx
import React, { useState, useEffect } from "react";
import { useUserProfile } from "../../context/UserProfileContext";

function Report() {
  const { profileData, loading } = useUserProfile();
  const [reportData, setReportData] = useState({
    totalUsers: 0,
    totalAdmins: 0,
    totalManagers: 0,
    totalExperts: 0,
    totalRegularUsers: 0,
    totalContests: 0,
    totalNews: 0,
    completedContests: 0,
    ongoingContests: 0,
    upcomingContests: 0,
    pendingEvaluations: 0,
  });

  const [searchQuery, setSearchQuery] = useState("");
  const [allContests, setAllContests] = useState([]); // เก็บรายการการประกวดทั้งหมด
  const [filteredContests, setFilteredContests] = useState([]); // สำหรับโชว์หลังค้นหา

  // ดึงข้อมูลจากเซิร์ฟเวอร์
  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await fetch("http://localhost:3000/users");
        if (!response.ok) throw new Error("Failed to fetch user data");
        const usersData = await response.json();

        const admins = usersData.filter((user) => user.role === "admin").length;
        const managers = usersData.filter((user) => user.role === "manager").length;
        const experts = usersData.filter((user) => user.role === "expert").length;
        const regularUsers = usersData.filter((user) => user.role === "user").length;

        setReportData((prevData) => ({
          ...prevData,
          totalUsers: usersData.length,
          totalAdmins: admins,
          totalManagers: managers,
          totalExperts: experts,
          totalRegularUsers: regularUsers,
        }));
      } catch (error) {
        console.error("Error fetching user data:", error);
      }
    };

    const fetchContestsData = async () => {
      try {
        const contestsResponse = await fetch("http://localhost:3000/contests");
        if (!contestsResponse.ok) throw new Error("Failed to fetch contests");
        const contestsData = await contestsResponse.json();

        // เก็บการประกวดทั้งหมดลง state
        setAllContests(contestsData);
        setFilteredContests(contestsData);

        // คำนวณข้อมูลการประกวด
        const completed = contestsData.filter((c) => c.status === "เสร็จสิ้น").length;
        const ongoing = contestsData.filter((c) => c.status === "กำลังจัด").length;
        const upcoming = contestsData.filter((c) => c.status === "ยังไม่เริ่ม").length;

        setReportData((prevData) => ({
          ...prevData,
          completedContests: completed,
          ongoingContests: ongoing,
          upcomingContests: upcoming,
          // ถ้ามีข้อมูล totalContests ใน contestsData กำหนดต่อได้เช่นกัน
          totalContests: contestsData.length,
        }));
      } catch (error) {
        console.error("Error fetching contests:", error);
      }
    };

    fetchUserData();
    fetchContestsData();
  }, []);

  // ฟังก์ชันค้นหาการประกวด
  const handleSearch = () => {
    if (searchQuery.trim() === "") {
      setFilteredContests(allContests);
    } else {
      const result = allContests.filter((contest) =>
        contest.name.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setFilteredContests(result);
    }
  };

  if (loading) return <div>กำลังโหลด...</div>;
  if (!profileData || profileData.role !== "admin")
    return <div>คุณไม่มีสิทธิ์เข้าถึงหน้านี้</div>;

  return (
    <div className="bg-gray-100 min-h-screen">
      {/* AdminMenu (Navbar) อยู่ใน App.jsx หรือ Layout */}
      <div className="pt-20 p-8 w-full">
        <h1 className="text-4xl font-semibold text-gray-900 mb-6">รายงานระบบ</h1>

        <div className="bg-white shadow-md rounded-lg p-6">
          <h2 className="text-2xl font-semibold text-blue-600 mb-4">ข้อมูลภาพรวม</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <StatCard title="ผู้ใช้งานทั้งหมด" value={reportData.totalUsers} color="blue" />
            <StatCard title="ผู้ดูแลระบบ (Admin)" value={reportData.totalAdmins} color="green" />
            <StatCard title="ผู้จัดการประกวด" value={reportData.totalManagers} color="yellow" />
            <StatCard title="ผู้เชี่ยวชาญ" value={reportData.totalExperts} color="purple" />
            <StatCard title="ผู้ใช้งานทั่วไป" value={reportData.totalRegularUsers} color="red" />
            <StatCard title="การประกวดทั้งหมด" value={reportData.totalContests} color="blue" />
            <StatCard title="ข่าวสารทั้งหมด" value={reportData.totalNews} color="teal" />
            <StatCard title="การประกวดที่เสร็จสิ้น" value={reportData.completedContests} color="green" />
            <StatCard title="การประกวดที่กำลังจัด" value={reportData.ongoingContests} color="orange" />
            <StatCard title="การประกวดที่ยังไม่เริ่ม" value={reportData.upcomingContests} color="yellow" />
            <StatCard
              title="การประเมินคุณภาพที่รอดำเนินการ"
              value={reportData.pendingEvaluations}
              color="red"
            />
          </div>
        </div>

        <div className="my-6">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ค้นหาการประกวด"
            className="border py-2 px-4 w-full md:w-1/3 mb-4"
          />
          <button onClick={handleSearch} className="bg-blue-500 text-white py-2 px-4">
            ค้นหา
          </button>
        </div>

        <div className="my-6">
          <h2 className="text-2xl font-semibold text-blue-600 mb-4">รายการการประกวด</h2>
          {filteredContests.map((contest) => (
            <div
              key={contest.id}
              className="bg-white p-4 shadow-md rounded-lg flex justify-between items-center mb-4"
            >
              <div>
                <h3 className="text-xl font-semibold text-gray-800">{contest.name}</h3>
                <p className="text-gray-600">
                  {contest.status} - {contest.date}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

const StatCard = ({ title, value, color }) => (
  <div className={`bg-${color}-100 rounded-lg p-4 text-center`}>
    <h3 className="text-xl text-gray-700 font-medium">{title}</h3>
    <p className={`text-2xl text-${color}-700 font-semibold`}>{value}</p>
  </div>
);

export default Report;

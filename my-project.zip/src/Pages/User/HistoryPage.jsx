// HistoryPage.jsx
import React, { useState } from "react";
import QualityEvaluationHistory from "./QualityEvaluationHistory";
import CompetitionHistory from "./CompetitionHistory";

const HistoryPage = () => {
  const [activeTab, setActiveTab] = useState("quality");

  return (
    <div className="min-h-screen bg-gradient-to-r from-purple-200 via-pink-200 to-red-200 p-4">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold text-center mb-8 text-purple-700">
          ประวัติการใช้งาน
        </h1>

        {/* ปุ่มสลับแท็บ: จอเล็กจะเรียงลง จอใหญ่จะเรียงข้างกัน */}
        <div className="flex flex-col sm:flex-row justify-center items-center gap-4 mb-8">
          <button
            onClick={() => setActiveTab("quality")}
            className={`px-4 py-2 rounded-lg font-semibold transition-colors duration-300 
              ${activeTab === "quality" 
                ? "bg-purple-600 text-white hover:bg-purple-700" 
                : "bg-white text-purple-600 border border-purple-600 hover:bg-purple-100"
              }`}
          >
            ประวัติการประเมินคุณภาพ
          </button>

          <button
            onClick={() => setActiveTab("competition")}
            className={`px-4 py-2 rounded-lg font-semibold transition-colors duration-300
              ${activeTab === "competition"
                ? "bg-purple-600 text-white hover:bg-purple-700"
                : "bg-white text-purple-600 border border-purple-600 hover:bg-purple-100"
              }`}
          >
            ประวัติการแข่งขัน
          </button>
        </div>

        {/* แสดงคอมโพเนนต์ตามแท็บที่เลือก */}
        {activeTab === "quality" ? (
          <QualityEvaluationHistory />
        ) : (
          <CompetitionHistory />
        )}
      </div>
    </div>
  );
};

export default HistoryPage;

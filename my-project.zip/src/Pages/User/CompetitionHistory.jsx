import React, { useState, useEffect } from "react";
import DetailModal from "./DetailModal";

const CompetitionHistory = () => {
  const [competitions, setCompetitions] = useState([]);
  const [selectedCompetition, setSelectedCompetition] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // สมมุติข้อมูลการแข่งขัน
  const sampleCompetitions = [
    {
      id: 1,
      fishName: "ปลากัดเขียวสดใส",
      registrationDate: "2025-06-01",
      status: "รอการแข่งขัน",
      images: ["image7.jpg", "image8.jpg"],
      video: "video4.mp4",
      details: {
        size: "5.5 ซม.",
        age: "6 เดือน",
        type: "ครีบยาว",
        finType: "หางเดี่ยว",
        tailType: "หางพระอาทิตย์ครึ่งดวง",
        subTailType: "ซับประเภท 2",
      },
      scores: [null, null, null],
      rank: null,
    },
    {
      id: 2,
      fishName: "ปลากัดสีรุ้ง",
      registrationDate: "2025-05-20",
      status: "กำลังดำเนินการแข่งขันอยู่",
      images: ["image9.jpg", "image10.jpg"],
      video: "video5.mp4",
      details: {
        size: "6 ซม.",
        age: "7 เดือน",
        type: "ครีบสั้น",
        finType: "หางคู่",
        tailType: "หางพู่กัน",
        subTailType: "ซับประเภท 1",
      },
      scores: [8, 7, null], // หนึ่งคนยังไม่ประเมิน
      rank: null,
    },
    {
      id: 3,
      fishName: "ปลากัดฟ้าสดใส",
      registrationDate: "2025-04-15",
      status: "การแข่งขันสำเร็จแล้ว",
      images: ["image11.jpg", "image12.jpg"],
      video: "video6.mp4",
      details: {
        size: "4.5 ซม.",
        age: "5 เดือน",
        type: "ครีบยาว",
        finType: "หางเดี่ยว",
        tailType: "หางมงกุฎ",
        subTailType: "ซับประเภท 1",
      },
      scores: [9, 10, 8],
      rank: 2,
    },
    // เพิ่มเติมข้อมูลการแข่งขันตามต้องการ
  ];

  useEffect(() => {
    // ในกรณีที่ดึงข้อมูลจาก API จริง ให้ใช้ fetch หรือ axios ที่นี่
    setCompetitions(sampleCompetitions);
  }, []);

  const openModal = (competition) => {
    setSelectedCompetition(competition);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setSelectedCompetition(null);
    setIsModalOpen(false);
  };

  return (
    <div>
      <div className="overflow-x-auto">
        <table className="min-w-full bg-white bg-opacity-90 rounded-lg shadow-lg">
          <thead>
            <tr>
              <th className="py-3 px-6 bg-purple-600 text-white text-left text-sm uppercase font-semibold">
                ชื่อปลากัด
              </th>
              <th className="py-3 px-6 bg-purple-600 text-white text-left text-sm uppercase font-semibold">
                วันที่สมัครแข่งขัน
              </th>
              <th className="py-3 px-6 bg-purple-600 text-white text-left text-sm uppercase font-semibold">
                สถานะการแข่งขัน
              </th>
              <th className="py-3 px-6 bg-purple-600 text-white text-left text-sm uppercase font-semibold">
                รายละเอียด
              </th>
            </tr>
          </thead>
          <tbody>
            {competitions.map((comp) => (
              <tr key={comp.id} className="border-b">
                <td className="py-4 px-6 text-gray-700">{comp.fishName}</td>
                <td className="py-4 px-6 text-gray-700">
                  {new Date(comp.registrationDate).toLocaleDateString("th-TH")}
                </td>
                <td className="py-4 px-6">
                  {comp.status === "รอการแข่งขัน" && (
                    <span className="inline-block px-2 py-1 text-xs font-semibold text-yellow-700 bg-yellow-200 rounded-full">
                      รอการแข่งขัน
                    </span>
                  )}
                  {comp.status === "กำลังดำเนินการแข่งขันอยู่" && (
                    <span className="inline-block px-2 py-1 text-xs font-semibold text-blue-700 bg-blue-200 rounded-full">
                      กำลังดำเนินการแข่งขัน
                    </span>
                  )}
                  {comp.status === "การแข่งขันสำเร็จแล้ว" && (
                    <span className="inline-block px-2 py-1 text-xs font-semibold text-green-700 bg-green-200 rounded-full">
                      การแข่งขันสำเร็จแล้ว
                    </span>
                  )}
                </td>
                <td className="py-4 px-6">
                  {comp.status === "การแข่งขันสำเร็จแล้ว" ? (
                    <button
                      onClick={() => openModal(comp)}
                      className="bg-purple-600 text-white px-3 py-1 rounded hover:bg-purple-700 transition-colors"
                    >
                      ดูรายละเอียด
                    </button>
                  ) : (
                    "-"
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Modal สำหรับดูรายละเอียดการแข่งขัน */}
      {isModalOpen && selectedCompetition && (
        <DetailModal
          data={selectedCompetition}
          onClose={closeModal}
          type="competition"
        />
      )}
    </div>
  );
};

export default CompetitionHistory;

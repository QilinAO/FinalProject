// src/pages/ContestPage.jsx

import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import {
  collection,
  query,
  where,
  onSnapshot,
  orderBy,
} from "firebase/firestore";
import { db } from "../../backend/config/FirebaseSDK";

const ContestPage = () => {
  const [contests, setContests] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedContest, setSelectedContest] = useState(null);

  // ฟอร์มเก็บข้อมูลสมัคร
  const [applicationData, setApplicationData] = useState({
    name: "",
    email: "",
    message: "",
  });
  const [formErrors, setFormErrors] = useState({});
  const [toastMessage, setToastMessage] = useState("");

  // 1) ดึงข้อมูลจาก Firestore เฉพาะที่ category = "การประกวด"
  useEffect(() => {
    const colRef = collection(db, "contests");
    const q = query(
      colRef,
      where("category", "==", "การประกวด"),
      orderBy("createdAt", "desc")
    );

    let unsubscribe;
    try {
      unsubscribe = onSnapshot(
        q,
        (snapshot) => {
          const fetchedContests = [];
          snapshot.forEach((docSnap) => {
            fetchedContests.push({
              id: docSnap.id,
              ...docSnap.data(),
            });
          });
          setContests(fetchedContests);
        },
        (error) => {
          console.error("Error getting contests:", error);
        }
      );
    } catch (error) {
      console.error("Error in useEffect:", error);
    }

    // clean up
    return () => {
      if (unsubscribe) {
        unsubscribe();
      }
    };
  }, []);

  // ฟังก์ชันเปิด Modal
  const openModal = (contest) => {
    setSelectedContest(contest);
    setIsModalOpen(true);
  };

  // ฟังก์ชันปิด Modal
  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedContest(null);
    setApplicationData({ name: "", email: "", message: "" });
    setFormErrors({});
  };

  // ฟังก์ชันจัดการการเปลี่ยนแปลงในฟอร์ม
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setApplicationData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  // ฟังก์ชันตรวจสอบความถูกต้องของฟอร์ม
  const validateForm = () => {
    const errors = {};
    if (!applicationData.name.trim()) {
      errors.name = "กรุณากรอกชื่อของคุณ";
    }
    if (!applicationData.email.trim()) {
      errors.email = "กรุณากรอกอีเมลของคุณ";
    } else if (
      !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(applicationData.email)
    ) {
      errors.email = "รูปแบบอีเมลไม่ถูกต้อง";
    }
    if (!applicationData.message.trim()) {
      errors.message = "กรุณากรอกข้อความ";
    }
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  // ฟังก์ชันจัดการการส่งฟอร์ม
  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateForm()) {
      // โค้ดส่งข้อมูลไป Backend หรือ Firestore ตามต้องการได้
      console.log("Application Data:", applicationData);

      setToastMessage("สมัครเข้าร่วมการประกวดเรียบร้อยแล้ว!");
      closeModal();
    }
  };

  // ตั้ง timer ลบข้อความ Toast
  useEffect(() => {
    if (toastMessage) {
      const timer = setTimeout(() => setToastMessage(""), 3000);
      return () => clearTimeout(timer);
    }
  }, [toastMessage]);

  return (
    <div className="min-h-screen bg-gradient-to-r from-purple-200 via-pink-200 to-red-200 p-4">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold text-center mb-8 text-purple-700">
          หน้าการประกวด
        </h1>

        {/* ถ้าไม่มี Contest เลย แสดงข้อความบอก */}
        {contests.length === 0 ? (
          <p className="text-center text-gray-600">ไม่มีการประกวดที่จะแสดง</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {contests.map((contest) => (
              <div
                key={contest.id}
                className="bg-white bg-opacity-90 rounded-lg shadow-lg p-6 border border-purple-300 flex flex-col justify-between"
              >
                <div>
                  {/* ชื่อการประกวด */}
                  <h2 className="text-2xl font-semibold text-purple-700 mb-2">
                    <Link
                      to={`/contest/${contest.id}`}
                      className="text-purple-700 hover:underline"
                    >
                      {contest.name}
                    </Link>
                  </h2>

                  {/* shortDescription แสดงใต้ชื่อ */}
                  {contest.shortDescription && (
                    <p className="text-gray-600 mb-2">
                      {contest.shortDescription}
                    </p>
                  )}

                  {/* รายละเอียดเต็ม (description) */}
                  <p className="text-gray-700 mb-4">{contest.description}</p>

                  {/* ช่วงเวลาการเปิดรับสมัคร */}
                  {contest.registrationStartDate && contest.registrationEndDate && (
                    <div className="mb-2">
                      <span className="font-medium text-purple-600">
                        เปิดรับสมัคร:
                      </span>{" "}
                      {new Date(contest.registrationStartDate).toLocaleDateString("th-TH")}{" "}
                      ถึง{" "}
                      {new Date(contest.registrationEndDate).toLocaleDateString("th-TH")}
                    </div>
                  )}

                  {/* วันที่จัดการประกวด (Timestamp -> toDate()) */}
                  {contest.startDate && (
                    <div className="mb-2">
                      <span className="font-medium text-purple-600">
                        วันที่เริ่มต้นประกวด:
                      </span>{" "}
                      {contest.startDate.toDate().toLocaleDateString("th-TH")}
                    </div>
                  )}
                  {contest.endDate && (
                    <div className="mb-2">
                      <span className="font-medium text-purple-600">
                        วันที่สิ้นสุดประกวด:
                      </span>{" "}
                      {contest.endDate.toDate().toLocaleDateString("th-TH")}
                    </div>
                  )}

                  {/* กรรมการ */}
                  {contest.judges && (
                    <div className="mb-2">
                      <span className="font-medium text-purple-600">กรรมการ:</span>{" "}
                      {Array.isArray(contest.judges)
                        ? contest.judges.join(", ")
                        : contest.judges}
                    </div>
                  )}

                  {/* ผู้จัดการประกวด */}
                  {contest.organizer && (
                    <div>
                      <span className="font-medium text-purple-600">ผู้จัดการประกวด:</span>{" "}
                      {contest.organizer}
                    </div>
                  )}
                </div>

                {/* ปุ่มสมัครเข้าร่วม */}
                {contest.status === "กำลังดำเนินการ" && (
                <button
                  onClick={() => openModal(contest)}
                  className="mt-4 bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors font-semibold"
                >
                  สมัครเข้าร่วม
                </button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Modal สำหรับสมัครเข้าร่วมการประกวด */}
      {isModalOpen && selectedContest && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-lg w-full max-w-md p-6 relative">
            <button
              onClick={closeModal}
              className="absolute top-3 right-3 text-gray-500 hover:text-gray-700"
            >
              &times;
            </button>
            <h2 className="text-2xl font-semibold text-purple-700 mb-4">
              สมัครเข้าร่วม {selectedContest.name}
            </h2>
            <form onSubmit={handleSubmit}>
              {/* ชื่อ */}
              <div className="mb-4">
                <label className="block text-purple-600 font-medium mb-2">
                  ชื่อของคุณ
                </label>
                <input
                  type="text"
                  name="name"
                  value={applicationData.name}
                  onChange={handleInputChange}
                  className={`w-full px-3 py-2 border ${
                    formErrors.name ? "border-red-500" : "border-purple-300"
                  } rounded focus:outline-none focus:ring-2 focus:ring-purple-500`}
                  placeholder="กรุณากรอกชื่อของคุณ"
                />
                {formErrors.name && (
                  <p className="text-red-500 text-sm mt-1">{formErrors.name}</p>
                )}
              </div>

              {/* อีเมล */}
              <div className="mb-4">
                <label className="block text-purple-600 font-medium mb-2">
                  อีเมลของคุณ
                </label>
                <input
                  type="email"
                  name="email"
                  value={applicationData.email}
                  onChange={handleInputChange}
                  className={`w-full px-3 py-2 border ${
                    formErrors.email ? "border-red-500" : "border-purple-300"
                  } rounded focus:outline-none focus:ring-2 focus:ring-purple-500`}
                  placeholder="กรุณากรอกอีเมลของคุณ"
                />
                {formErrors.email && (
                  <p className="text-red-500 text-sm mt-1">{formErrors.email}</p>
                )}
              </div>

              {/* ข้อความเพิ่มเติม */}
              <div className="mb-4">
                <label className="block text-purple-600 font-medium mb-2">
                  ข้อความเพิ่มเติม
                </label>
                <textarea
                  name="message"
                  value={applicationData.message}
                  onChange={handleInputChange}
                  className={`w-full px-3 py-2 border ${
                    formErrors.message ? "border-red-500" : "border-purple-300"
                  } rounded focus:outline-none focus:ring-2 focus:ring-purple-500`}
                  placeholder="กรุณากรอกข้อความเพิ่มเติม"
                  rows="4"
                ></textarea>
                {formErrors.message && (
                  <p className="text-red-500 text-sm mt-1">{formErrors.message}</p>
                )}
              </div>

              {/* ปุ่มส่งฟอร์ม */}
              <div className="flex justify-end">
                <button
                  type="submit"
                  className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors font-semibold"
                >
                  ส่งสมัคร
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* แสดงข้อความแจ้งเตือน */}
      {toastMessage && (
        <div className="fixed bottom-4 right-4 bg-green-500 text-white px-4 py-2 rounded-lg shadow-lg animate-bounce">
          {toastMessage}
        </div>
      )}
    </div>
  );
};

export default ContestPage;

// src/Pages/DetailModal.jsx
import React from "react";

const DetailModal = ({ data, onClose, type }) => {
  // ตรวจสอบและคำนวณคะแนนเฉลี่ย
  const averageScore =
    data.status === "ประเมินสำเร็จแล้ว" && Array.isArray(data.scores)
      ? data.scores.reduce((acc, curr) => acc + (curr || 0), 0) /
        data.scores.filter((score) => score !== null).length
      : null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      {/* คอนเทนต์ของโมดัล: กำหนด max-w, เว้นระยะขอบ (m-4) เพื่อไม่ให้ชิดขอบจอบนมือถือ */}
      <div className="relative w-full max-w-3xl max-h-[90vh] m-4 bg-white rounded-lg shadow-lg overflow-y-auto">
        {/* ปุ่มปิดโมดัล (Close) */}
        <button
          onClick={onClose}
          className="absolute top-3 right-3 text-gray-500 hover:text-gray-700 text-2xl font-bold focus:outline-none"
        >
          &times;
        </button>

        {/* ส่วนหัวโมดัล */}
        <div className="p-6 pb-2">
          <h2 className="text-2xl font-semibold text-purple-700">
            รายละเอียด {type === "quality" ? "การประเมินคุณภาพ" : "การแข่งขัน"}
          </h2>
        </div>

        {/* แบ่งครึ่งหน้าจอ (md:flex) เมื่อจอ >= md */}
        <div className="p-6 pt-0 flex flex-col md:flex-row">
          {/* รูปภาพและวิดีโอ */}
          <div className="md:w-1/2 md:pr-6">
            {/* รูปภาพ */}
            <h3 className="text-xl font-medium text-purple-600 mb-2">รูปภาพปลากัด</h3>
            <div className="flex flex-wrap gap-2">
              {Array.isArray(data.images) && data.images.length > 0 ? (
                data.images.map((img, idx) => (
                  <img
                    key={idx}
                    src={img}
                    alt={`fish-${idx}`}
                    className="w-24 h-24 object-cover rounded border border-purple-300"
                  />
                ))
              ) : (
                <p className="text-gray-500">ไม่มีรูปภาพ</p>
              )}
            </div>

            {/* วิดีโอ */}
            <h3 className="text-xl font-medium text-purple-600 mt-4 mb-2">วิดีโอ</h3>
            {data.video ? (
              <video
                width="100%"
                controls
                className="rounded border border-purple-300"
              >
                <source src={data.video} type="video/mp4" />
                Your browser does not support the video tag.
              </video>
            ) : (
              <p className="text-gray-500">ไม่มีวิดีโอ</p>
            )}
          </div>

          {/* รายละเอียดและคะแนน */}
          <div className="md:w-1/2 md:pl-6 mt-6 md:mt-0">
            <h3 className="text-xl font-medium text-purple-600 mb-2">
              รายละเอียดปลากัด
            </h3>
            <ul className="list-disc list-inside text-gray-700 space-y-1">
              <li>ขนาด: {data.betta_size || "ไม่มีข้อมูล"}</li>
              <li>อายุ: {data.betta_age || "ไม่มีข้อมูล"}</li>
              <li>ประเภทปลากัด: {data.betta_type || "ไม่มีข้อมูล"}</li>
              <li>ชนิดปลากัด: {data.betta_kind || "ไม่มีข้อมูล"}</li>
            </ul>

            <h3 className="text-xl font-medium text-purple-600 mt-4 mb-2">
              คะแนนเฉลี่ยจากผู้เชี่ยวชาญ
            </h3>
            {averageScore !== null ? (
              <p className="text-gray-700">คะแนนเฉลี่ย: {averageScore.toFixed(2)}</p>
            ) : (
              <p className="text-gray-500">ยังไม่มีคะแนน</p>
            )}

            {/* แสดงอันดับหรือข้อความกำลังใจเฉพาะการแข่ง */}
            {type === "competition" && data.rank ? (
              <div className="mt-4">
                <h3 className="text-xl font-medium text-purple-600 mb-2">อันดับ</h3>
                <p className="text-green-700">อันดับที่ {data.rank}</p>
              </div>
            ) : type === "competition" && data.status === "การแข่งขันสำเร็จแล้ว" ? (
              <div className="mt-4">
                <h3 className="text-xl font-medium text-purple-600 mb-2">
                  ข้อความกำลังใจ
                </h3>
                <p className="text-gray-700">
                  เราเห็นคุณค่าของปลากัดของคุณ! พัฒนาปลากัดให้ดียิ่งขึ้น
                  และกลับมาแข่งขันอีกครั้งนะครับ!
                </p>
              </div>
            ) : null}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DetailModal;

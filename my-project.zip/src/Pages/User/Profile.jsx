// src/Pages/User/Profile.jsx

import React, { useState, useEffect, useRef } from "react";
import { FiCamera } from "react-icons/fi";
import { useAuthState } from "react-firebase-hooks/auth";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { auth } from "../../backend/config/FirebaseSDK";
import {
  fetchProfile,
  updateProfile,
  uploadProfilePicture,
  deleteProfilePicture,
} from "../../backend/services_user/Profile";
import { sendPasswordResetEmail } from "firebase/auth"; // กรณีจะใช้ในการรีเซ็ตรหัสผ่าน

const defaultProfileImage = "https://dummyimage.com/800x400";

const Profile = () => {
  const [user, loadingAuth, errorAuth] = useAuthState(auth);
  const [profileData, setProfileData] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    username: "",
    firstName: "",
    lastName: "",
    email: "",
  });
  const [profilePicFile, setProfilePicFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef(null);

  useEffect(() => {
    const loadProfile = async () => {
      if (!user) return;

      try {
        const data = await fetchProfile(user.uid);
        setProfileData(data);
        setFormData({
          username: data.username || "",
          firstName: data.firstName || "",
          lastName: data.lastName || "",
          email: data.email || "",
        });
      } catch (error) {
        toast.error("เกิดข้อผิดพลาดในการดึงข้อมูลโปรไฟล์");
        console.error(error);
      }
    };

    loadProfile();
  }, [user]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSave = async () => {
    if (!user) {
      toast.error("ผู้ใช้ไม่ได้เข้าสู่ระบบ");
      return;
    }
    try {
      await updateProfile(user.uid, formData);
      setProfileData((prev) => ({ ...prev, ...formData }));
      setIsEditing(false);
      toast.success("บันทึกข้อมูลสำเร็จ");
    } catch (error) {
      console.error("Error updating profile:", error);
      toast.error("เกิดข้อผิดพลาดในการบันทึกข้อมูลโปรไฟล์");
    }
  };

  const handleProfilePicFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const validTypes = ["image/jpeg", "image/png", "image/jpg"];
      const maxSize = 5 * 1024 * 1024;

      if (!validTypes.includes(file.type)) {
        toast.error("กรุณาเลือกไฟล์รูปภาพเท่านั้น (JPEG, PNG)");
        return;
      }
      if (file.size > maxSize) {
        toast.error("ขนาดไฟล์เกิน 5MB");
        return;
      }
      setProfilePicFile(file);
    }
  };

  const handleClickEditProfilePic = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const handleUploadProfilePic = async () => {
    if (!profilePicFile) {
      toast.error("ไม่มีไฟล์รูปภาพที่ต้องการอัปโหลด");
      return;
    }
    if (!user) {
      toast.error("ผู้ใช้ไม่ได้เข้าสู่ระบบ");
      return;
    }

    try {
      setUploading(true);
      // ลบรูปโปรไฟล์เก่า (ถ้ามี)
      if (profileData?.profile && profileData.profile !== defaultProfileImage) {
        await deleteProfilePicture(profileData.profile);
      }
      // อัปโหลดรูปใหม่
      const downloadURL = await uploadProfilePicture(user.uid, profilePicFile);
      await updateProfile(user.uid, { profile: downloadURL });
      setProfileData((prev) => ({ ...prev, profile: downloadURL }));
      toast.success("อัปโหลดรูปโปรไฟล์สำเร็จ");
      setProfilePicFile(null);
    } catch (error) {
      console.error("Error uploading profile picture:", error);
      toast.error("เกิดข้อผิดพลาดในการอัปโหลดรูปโปรไฟล์");
    } finally {
      setUploading(false);
    }
  };

  const handleResetPassword = async () => {
    if (!user?.email) {
      toast.error("ไม่สามารถเปลี่ยนรหัสผ่านได้");
      return;
    }
    try {
      await sendPasswordResetEmail(auth, user.email);
      toast.success("ส่งลิงก์เปลี่ยนรหัสผ่านไปยังอีเมลแล้ว");
    } catch (error) {
      console.error("Error sending password reset email:", error);
      toast.error("เกิดข้อผิดพลาดในการส่งลิงก์เปลี่ยนรหัสผ่าน");
    }
  };

  // Loading...
  if (loadingAuth || uploading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <p className="text-gray-600">กำลังโหลดข้อมูล...</p>
      </div>
    );
  }
  // Error
  if (errorAuth) {
    return (
      <div className="flex justify-center items-center h-screen">
        <p className="text-red-500">เกิดข้อผิดพลาด: {errorAuth.message}</p>
      </div>
    );
  }
  // ยังไม่ได้ล็อกอิน
  if (!user) {
    return (
      <div className="flex justify-center items-center h-screen">
        <p className="text-gray-600">กรุณาเข้าสู่ระบบเพื่อดูข้อมูลโปรไฟล์</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-r from-purple-200 via-pink-200 to-red-200 py-8">
      <ToastContainer />
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-extrabold text-center mb-8 text-purple-700 drop-shadow-sm">
          ข้อมูลส่วนตัว
        </h1>

        <div className="bg-white p-6 md:p-8 rounded-md shadow-lg flex flex-col md:flex-row items-start md:items-center gap-6">
          {/* ส่วนรูปโปรไฟล์ทางซ้าย */}
          <div className="flex flex-col items-center w-full md:w-1/3">
            <div className="relative w-40 h-40 mb-4">
              <img
                src={profileData?.profile || defaultProfileImage}
                alt="Profile"
                className="w-40 h-40 object-cover rounded-full border-2 border-purple-300 shadow-sm"
                onError={(e) => {
                  e.target.onerror = null;
                  e.target.src = defaultProfileImage;
                }}
              />
              {/* ปุ่มแก้ไขรูป */}
              <button
                onClick={handleClickEditProfilePic}
                className="absolute bottom-0 right-0 bg-purple-600 text-white p-2 rounded-full hover:bg-purple-500 transition"
                title="แก้ไขรูปโปรไฟล์"
              >
                <FiCamera size={16} />
              </button>
              {/* input file ซ่อน */}
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleProfilePicFileChange}
                accept="image/*"
                className="hidden"
              />
            </div>

            {/* ถ้าเลือกไฟล์รูปแล้ว แสดงปุ่มอัปโหลด */}
            {profilePicFile && (
              <button
                onClick={handleUploadProfilePic}
                className="px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-600 transition w-full"
              >
                อัปโหลดรูปโปรไฟล์
              </button>
            )}

            {/* ปุ่มเปลี่ยนรหัสผ่าน */}
            <button
              onClick={handleResetPassword}
              className="mt-4 px-4 py-2 bg-yellow-500 text-white rounded-md hover:bg-yellow-600 transition w-full"
            >
              เปลี่ยนรหัสผ่าน
            </button>
          </div>

          {/* ส่วนข้อมูลโปรไฟล์ทางขวา */}
          <div className="flex-1 w-full">
            {isEditing ? (
              <div className="space-y-4">
                <div>
                  <label className="block text-gray-700 font-semibold mb-1">
                    ชื่อผู้ใช้งาน
                  </label>
                  <input
                    type="text"
                    name="username"
                    value={formData.username}
                    onChange={handleChange}
                    className="w-full p-2 border rounded-md border-gray-300 focus:ring-2 focus:ring-purple-500"
                  />
                </div>
                <div>
                  <label className="block text-gray-700 font-semibold mb-1">
                    ชื่อ
                  </label>
                  <input
                    type="text"
                    name="firstName"
                    value={formData.firstName}
                    onChange={handleChange}
                    className="w-full p-2 border rounded-md border-gray-300 focus:ring-2 focus:ring-purple-500"
                  />
                </div>
                <div>
                  <label className="block text-gray-700 font-semibold mb-1">
                    นามสกุล
                  </label>
                  <input
                    type="text"
                    name="lastName"
                    value={formData.lastName}
                    onChange={handleChange}
                    className="w-full p-2 border rounded-md border-gray-300 focus:ring-2 focus:ring-purple-500"
                  />
                </div>
                <div>
                  <label className="block text-gray-700 font-semibold mb-1">
                    อีเมล
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full p-2 border rounded-md border-gray-300 focus:ring-2 focus:ring-purple-500"
                  />
                </div>
                <div className="flex justify-end gap-3">
                  <button
                    onClick={handleSave}
                    className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 transition font-semibold"
                  >
                    บันทึก
                  </button>
                  <button
                    onClick={() => setIsEditing(false)}
                    className="px-4 py-2 bg-gray-400 text-white rounded-md hover:bg-gray-500 transition font-semibold"
                  >
                    ยกเลิก
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <p className="text-gray-700">
                  <span className="font-semibold">ชื่อผู้ใช้งาน:</span>{" "}
                  {profileData?.username}
                </p>
                <p className="text-gray-700">
                  <span className="font-semibold">ชื่อ:</span>{" "}
                  {profileData?.firstName}
                </p>
                <p className="text-gray-700">
                  <span className="font-semibold">นามสกุล:</span>{" "}
                  {profileData?.lastName}
                </p>
                <p className="text-gray-700">
                  <span className="font-semibold">อีเมล:</span>{" "}
                  {profileData?.email}
                </p>
                <button
                  onClick={() => setIsEditing(true)}
                  className="mt-4 px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 transition font-semibold"
                >
                  แก้ไขข้อมูลส่วนตัว
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;

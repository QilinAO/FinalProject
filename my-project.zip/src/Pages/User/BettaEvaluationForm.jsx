// src/components/BettaEvaluationForm.jsx
import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { useDropzone } from "react-dropzone";
import { FaTimes } from "react-icons/fa";
import {
  uploadFileToStorage,
  saveBettaDataToFirestore,
} from "../../backend/services_user/BettaEvaluationForm";

// โครงสร้างข้อมูล สำหรับกำหนดชนิดหางที่เป็นไปได้
const FIN_TAIL_DATA = {
  "ครีบสั้น": {
    "หางเดี่ยว": [
      "หางพัด",
      "หางโพธิ์",
      "หางมงกุฎ",
      "หางพระจันทร์ครึ่งดวง",
    ],
    "หางคู่": [
      "หางพัด",
      "หางโพธิ์",
      "หางมงกุฎ",
      "หางพระจันทร์ครึ่งดวง",
    ],
  },
  "ครีบยาว": {
    "หางเดี่ยว": [
      "หางพู่กัน",
      "หางมงกุฎ",
      "หางพระอาทิตย์ครึ่งดวง",
      "หางพระจันทร์ครึ่งดวง",
    ],
    "หางคู่": [
      "หางพู่กัน",
      "หางมงกุฎ",
      "หางพระอาทิตย์ครึ่งดวง",
      "หางพระจันทร์ครึ่งดวง",
    ],
  },
  "ปลากัดยักษ์": {
    "หางเดี่ยว": [
      "หางพัด",
      "หางโพธิ์",
      "หางมงกุฎ",
      "หางพระจันทร์ครึ่งดวง",
    ],
    "หางคู่": [
      "หางพัด",
      "หางโพธิ์",
      "หางมงกุฎ",
      "หางพระจันทร์ครึ่งดวง",
    ],
  },
  "ปลากัดหูช้าง": {
    "หางเดี่ยว": [
      "หางพู่กัน",
      "หางมงกุฎ",
      "หางพระอาทิตย์ครึ่งดวง",
      "หางพระจันทร์ครึ่งดวง",
    ],
    "หางคู่": [
      "หางพู่กัน",
      "หางมงกุฎ",
      "หางพระอาทิตย์ครึ่งดวง",
      "หางพระจันทร์ครึ่งดวง",
    ],
  },
};

const BettaEvaluationForm = () => {
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    watch,
  } = useForm();

  // ============== ส่วนอัปโหลดรูป/วิดีโอ เหมือนเดิม ==============
  const [images, setImages] = useState([]);
  const [video, setVideo] = useState(null);
  const [imageErrors, setImageErrors] = useState([]);
  const [videoError, setVideoError] = useState("");

  // ฟังก์ชัน drop รูปภาพ
  const onDropImages = (acceptedFiles, rejectedFiles) => {
    const newImageErrors = [];

    rejectedFiles.forEach((file) => {
      file.errors.forEach((err) => {
        if (err.code === "file-invalid-type") {
          newImageErrors.push(`ไฟล์ ${file.file.name} ไม่ใช่รูปภาพ`);
        }
        if (err.code === "file-too-large") {
          newImageErrors.push(`ไฟล์ ${file.file.name} มีขนาดใหญ่เกิน 5MB`);
        }
      });
    });

    if (acceptedFiles.length + images.length > 3) {
      newImageErrors.push("คุณสามารถอัพโหลดได้สูงสุด 3 รูปภาพเท่านั้น");
    }

    setImageErrors(newImageErrors);

    const validFiles = acceptedFiles.slice(0, 3 - images.length);
    setImages((prev) => [...prev, ...validFiles]);
  };

  // ฟังก์ชัน drop วิดีโอ
  const onDropVideo = (acceptedFiles, rejectedFiles) => {
    let error = "";

    if (rejectedFiles.length > 0) {
      rejectedFiles.forEach((file) => {
        file.errors.forEach((err) => {
          if (err.code === "file-invalid-type") {
            error += `ไฟล์ ${file.file.name} ไม่ใช่วิดีโอ\n`;
          }
          if (err.code === "file-too-large") {
            error += `ไฟล์ ${file.file.name} มีขนาดใหญ่เกิน 50MB\n`;
          }
        });
      });
    }

    if (acceptedFiles.length > 1) {
      error += "คุณสามารถอัพโหลดได้สูงสุด 1 วิดีโอเท่านั้น";
    }

    setVideoError(error);

    if (acceptedFiles.length > 0) {
      setVideo(acceptedFiles[0]);
    }
  };

  const {
    getRootProps: getRootPropsImages,
    getInputProps: getInputPropsImages,
    isDragActive: isDragActiveImages,
  } = useDropzone({
    onDrop: onDropImages,
    accept: { "image/*": [] },
    multiple: true,
    maxFiles: 3,
    maxSize: 5 * 1024 * 1024,
  });

  const {
    getRootProps: getRootPropsVideo,
    getInputProps: getInputPropsVideo,
    isDragActive: isDragActiveVideo,
  } = useDropzone({
    onDrop: onDropVideo,
    accept: { "video/*": [] },
    multiple: false,
    maxFiles: 1,
    maxSize: 50 * 1024 * 1024,
  });

  const removeImage = (index) => {
    setImages((prev) => prev.filter((_, i) => i !== index));
  };

  const removeVideo = () => {
    setVideo(null);
    setVideoError("");
  };

  // ============= ส่วนการเลือกประเภทครีบ → ประเภทหาง → ชนิดหาง =============
  // ดูค่าที่ผู้ใช้เลือก
  const selectedFinType = watch("betta_fin_type");     // "ครีบสั้น", "ครีบยาว", ...
  const selectedTailType = watch("betta_tail_type");   // "หางเดี่ยว", "หางคู่"

  // เพื่อไว้กรอง "ชนิดหาง" ตาม FIN_TAIL_DATA
  let tailKindOptions = [];
  if (selectedFinType && FIN_TAIL_DATA[selectedFinType]) {
    if (selectedTailType && FIN_TAIL_DATA[selectedFinType][selectedTailType]) {
      tailKindOptions = FIN_TAIL_DATA[selectedFinType][selectedTailType];
    }
  }

  // ============= เมื่อ Submit ฟอร์ม =============
  const onSubmit = async (formData) => {
    try {
      // อัปโหลดรูปภาพ
      const imageUrls = await Promise.all(
        images.map((image) => uploadFileToStorage("BettaFish/Image", image))
      );

      // อัปโหลดวิดีโอ (ถ้ามี)
      let videoUrl = null;
      if (video) {
        videoUrl = await uploadFileToStorage("BettaFish/Video", video);
      }

      // รวมข้อมูลจากฟอร์มกับ URL ของไฟล์
      const bettaData = {
        ...formData,
        images: imageUrls,
        video: videoUrl,
      };

      // บันทึกข้อมูลลง Firestore
      await saveBettaDataToFirestore(bettaData);

      // รีเซ็ตฟอร์ม
      reset();
      setImages([]);
      setVideo(null);
      setImageErrors([]);
      setVideoError("");

      alert("ส่งแบบฟอร์มสำเร็จ");
    } catch (error) {
      console.error("Error submitting form:", error);
      alert("เกิดข้อผิดพลาดในการส่งแบบฟอร์ม");
    }
  };

  return (
    <main className="bg-gradient-to-r from-purple-200 via-pink-200 to-red-200 py-12 min-h-screen flex items-center justify-center px-4">
      <div className="max-w-4xl w-full bg-white bg-opacity-90 p-8 rounded shadow-lg sm:p-10 lg:p-12">
        <h2 className="text-3xl font-bold text-center mb-8 text-purple-700">
          แบบฟอร์มประเมินคุณภาพปลากัด
        </h2>

        <form
          onSubmit={handleSubmit(onSubmit)}
          className="grid grid-cols-1 md:grid-cols-2 gap-6"
          aria-label="แบบฟอร์มประเมินคุณภาพปลากัด"
        >
          {/* อัพโหลดรูปภาพ */}
          <div className="md:col-span-2">
            <label className="block text-gray-700 mb-2" htmlFor="images">
              อัพโหลดรูปภาพ (3 รูปภาพ):
            </label>
            <div
              {...getRootPropsImages()}
              className={`border-2 border-dashed p-4 rounded cursor-pointer text-center ${
                isDragActiveImages
                  ? "border-purple-500 bg-purple-50"
                  : "border-gray-300 bg-gray-50"
              }`}
              aria-label="พื้นที่อัพโหลดรูปภาพ"
            >
              <input {...getInputPropsImages()} aria-describedby="imagesHelp" />
              {isDragActiveImages ? (
                <p>ลากไฟล์เข้ามา...</p>
              ) : (
                <p>ลากรูปภาพเข้ามาหรือคลิกเพื่อเลือกไฟล์</p>
              )}
            </div>
            {imageErrors.length > 0 && (
              <div className="mt-2">
                {imageErrors.map((error, index) => (
                  <p key={index} className="text-red-500 text-sm">
                    {error}
                  </p>
                ))}
              </div>
            )}
          </div>

          {/* แสดงรูปภาพที่อัปโหลด */}
          {images.length > 0 && (
            <div className="md:col-span-2">
              <p className="text-gray-700 mt-4 mb-2">ตัวอย่างรูปภาพที่อัพโหลด:</p>
              <div className="flex space-x-4 overflow-x-auto">
                {images.map((image, index) => (
                  <div key={index} className="relative">
                    <img
                      src={URL.createObjectURL(image)}
                      alt={`Upload ${index + 1}`}
                      className="w-24 h-24 object-cover rounded shadow"
                    />
                    <button
                      type="button"
                      onClick={() => removeImage(index)}
                      aria-label={`ลบรูปภาพ ${index + 1}`}
                      className="absolute top-0 right-0 bg-red-500 text-white rounded-full p-1 -mt-2 -mr-2 hover:bg-red-600 focus:outline-none"
                    >
                      <FaTimes size={12} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* อัพโหลดวิดีโอ */}
          <div className="md:col-span-2">
            <label className="block text-gray-700 mb-2" htmlFor="video">
              อัพโหลดวิดีโอ (1 วิดีโอ):
            </label>
            <div
              {...getRootPropsVideo()}
              className={`border-2 border-dashed p-4 rounded cursor-pointer text-center ${
                isDragActiveVideo
                  ? "border-purple-500 bg-purple-50"
                  : "border-gray-300 bg-gray-50"
              }`}
              aria-label="พื้นที่อัพโหลดวิดีโอ"
            >
              <input {...getInputPropsVideo()} aria-describedby="videoHelp" />
              {isDragActiveVideo ? (
                <p>ลากไฟล์เข้ามา...</p>
              ) : (
                <p>ลากวิดีโอเข้ามาหรือคลิกเพื่อเลือกไฟล์</p>
              )}
            </div>
            {videoError && (
              <div className="mt-2">
                {videoError.split("\n").map((error, index) => (
                  <p key={index} className="text-red-500 text-sm">
                    {error}
                  </p>
                ))}
              </div>
            )}
          </div>

          {/* แสดงวิดีโอที่อัปโหลด */}
          {video && (
            <div className="md:col-span-2">
              <p className="text-gray-700 mt-4 mb-2">ตัวอย่างวิดีโอที่อัพโหลด:</p>
              <div className="relative">
                <video
                  src={URL.createObjectURL(video)}
                  controls
                  className="w-full h-auto rounded shadow"
                />
                <button
                  type="button"
                  onClick={removeVideo}
                  aria-label="ลบวิดีโอที่อัพโหลด"
                  className="absolute top-0 right-0 bg-red-500 text-white rounded-full p-1 -mt-2 -mr-2 hover:bg-red-600 focus:outline-none"
                >
                  <FaTimes size={12} />
                </button>
              </div>
            </div>
          )}

          {/* ฟิลด์ต่าง ๆ ของฟอร์ม */}
          {/* ชื่อปลากัด */}
          <div>
            <label className="block text-gray-700" htmlFor="betta_name">
              ชื่อปลากัด:
            </label>
            <input
              type="text"
              id="betta_name"
              placeholder="กรอกชื่อปลากัดของคุณ"
              {...register("betta_name", { required: true })}
              className="mt-2 p-2 w-full bg-gray-100 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-purple-300"
            />
            {errors.betta_name && (
              <p className="text-red-500 text-sm mt-1">
                กรุณากรอกชื่อปลากัด
              </p>
            )}
          </div>

          {/* อายุ (เดือน) */}
          <div>
            <label className="block text-gray-700" htmlFor="betta_age_months">
              อายุ (เดือน):
            </label>
            <input
              type="number"
              id="betta_age_months"
              placeholder="เช่น 5, 8, 12 ..."
              {...register("betta_age_months", { required: true, min: 1 })}
              className="mt-2 p-2 w-full bg-gray-100 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-purple-300"
            />
            {errors.betta_age_months && (
              <p className="text-red-500 text-sm mt-1">
                กรุณากรอกอายุเป็นตัวเลขเดือน
              </p>
            )}
          </div>

          {/* ประเภทครีบ */}
          <div>
            <label className="block text-gray-700" htmlFor="betta_fin_type">
              ประเภทครีบ:
            </label>
            <select
              id="betta_fin_type"
              {...register("betta_fin_type", { required: true })}
              className="mt-2 p-2 w-full bg-gray-100 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-purple-300"
            >
              <option value="">-- เลือกประเภทครีบ --</option>
              <option value="ครีบสั้น">ครีบสั้น</option>
              <option value="ครีบยาว">ครีบยาว</option>
              <option value="ปลากัดยักษ์">ปลากัดยักษ์</option>
              <option value="ปลากัดหูช้าง">ปลากัดหูช้าง</option>
            </select>
            {errors.betta_fin_type && (
              <p className="text-red-500 text-sm mt-1">
                กรุณาเลือกประเภทครีบ
              </p>
            )}
          </div>

          {/* ประเภทหาง */}
          <div>
            <label className="block text-gray-700" htmlFor="betta_tail_type">
              ประเภทหาง:
            </label>
            <select
              id="betta_tail_type"
              {...register("betta_tail_type", { required: true })}
              className="mt-2 p-2 w-full bg-gray-100 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-purple-300"
            >
              <option value="">-- เลือกประเภทหาง --</option>
              <option value="หางเดี่ยว">หางเดี่ยว</option>
              <option value="หางคู่">หางคู่</option>
            </select>
            {errors.betta_tail_type && (
              <p className="text-red-500 text-sm mt-1">
                กรุณาเลือกประเภทหาง
              </p>
            )}
          </div>

          {/* ชนิดหาง (ขึ้นกับ FIN_TAIL_DATA) */}
          <div className="md:col-span-2">
            <label className="block text-gray-700" htmlFor="betta_tail_kind">
              ชนิดหาง:
            </label>
            <select
              id="betta_tail_kind"
              {...register("betta_tail_kind", { required: true })}
              className="mt-2 p-2 w-full bg-gray-100 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-purple-300"
              disabled={!tailKindOptions.length} // ถ้ายังไม่ได้เลือกข้างบน หรือไม่มีค่า
            >
              <option value="">
                {tailKindOptions.length > 0
                  ? "-- เลือกชนิดหาง --"
                  : "กรุณาเลือกประเภทครีบ และ ประเภทหางก่อน"}
              </option>
              {tailKindOptions.map((kind) => (
                <option key={kind} value={kind}>
                  {kind}
                </option>
              ))}
            </select>
            {errors.betta_tail_kind && (
              <p className="text-red-500 text-sm mt-1">
                กรุณาเลือกชนิดหาง
              </p>
            )}
          </div>

          {/* ปุ่มส่งฟอร์ม */}
          <div className="md:col-span-2">
            <button
              type="submit"
              className="w-full bg-purple-500 text-white py-2 px-4 rounded hover:bg-purple-600 transition-colors duration-300"
            >
              ส่งแบบฟอร์ม
            </button>
          </div>
        </form>
      </div>
    </main>
  );
};

export default BettaEvaluationForm;

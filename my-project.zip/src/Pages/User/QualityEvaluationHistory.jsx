import React, { useState, useEffect } from "react";
import DetailModal from "./DetailModal";
import { fetchEvaluationsForUser } from "../../backend/services_user/QualityEvaluationHistory";

const QualityEvaluationHistory = () => {
  const [evaluations, setEvaluations] = useState([]);
  const [selectedEvaluation, setSelectedEvaluation] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    const fetchEvaluations = async () => {
      try {
        const data = await fetchEvaluationsForUser(); // ไม่ต้องส่ง userId เพราะใช้ auth แล้ว
        console.log("Fetched Evaluations:", data); // ตรวจสอบข้อมูลที่ดึงมา
        setEvaluations(data);
      } catch (error) {
        console.error("Error fetching evaluations:", error);
      }
    };

    fetchEvaluations();
  }, []);  // ใช้ useEffect เพื่อดึงข้อมูลเมื่อ component โหลด

  const openModal = (evaluation) => {
    setSelectedEvaluation(evaluation);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setSelectedEvaluation(null);
    setIsModalOpen(false);
  };

  return (
    <div>
      <div className="overflow-x-auto">
        <table className="min-w-full bg-white bg-opacity-90 rounded-lg shadow-lg">
          <thead>
            <tr>
              <th className="py-3 px-6 bg-purple-600 text-white text-left text-sm uppercase font-semibold">
                ชื่อปลากัด
              </th>
              <th className="py-3 px-6 bg-purple-600 text-white text-left text-sm uppercase font-semibold">
                วันที่ทำการประเมิน
              </th>
              <th className="py-3 px-6 bg-purple-600 text-white text-left text-sm uppercase font-semibold">
                สถานะการประเมิน
              </th>
              <th className="py-3 px-6 bg-purple-600 text-white text-left text-sm uppercase font-semibold">
                รายละเอียด
              </th>
            </tr>
          </thead>
          <tbody>
            {evaluations.length === 0 ? (
              <tr>
                <td colSpan="4" className="text-center py-4">
                  ไม่มีข้อมูลการประเมิน
                </td>
              </tr>
            ) : (
              evaluations.map((evalItem) => (
                <tr key={evalItem.id} className="border-b">
                  <td className="py-4 px-6 text-gray-700">
                    {evalItem.betta_name}
                  </td>
                  <td className="py-4 px-6 text-gray-700">
                    {new Date(evalItem.evaluationDate).toLocaleDateString(
                      "th-TH"
                    )}
                  </td>
                  <td className="py-4 px-6">
                    {evalItem.status === "รอการประเมิน" && (
                      <span className="inline-block px-2 py-1 text-xs font-semibold text-yellow-700 bg-yellow-200 rounded-full">
                        รอการประเมิน
                      </span>
                    )}
                    {evalItem.status === "กำลังดำเนินการ" && (
                      <span className="inline-block px-2 py-1 text-xs font-semibold text-blue-700 bg-blue-200 rounded-full">
                        กำลังดำเนินการ
                      </span>
                    )}
                    {evalItem.status === "ประเมินสำเร็จแล้ว" && (
                      <span className="inline-block px-2 py-1 text-xs font-semibold text-green-700 bg-green-200 rounded-full">
                        ประเมินสำเร็จแล้ว
                      </span>
                    )}
                  </td>
                  <td className="py-4 px-6">
                    <button
                      onClick={() => openModal(evalItem)}
                      className="bg-purple-600 text-white px-3 py-1 rounded hover:bg-purple-700 transition-colors"
                    >
                      ดูรายละเอียด
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {isModalOpen && selectedEvaluation && (
        <DetailModal
          data={selectedEvaluation}
          onClose={closeModal}
          type="quality"
        />
      )}
    </div>
  );
};

export default QualityEvaluationHistory;

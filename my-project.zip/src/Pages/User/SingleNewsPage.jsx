// src/Pages/SingleNewsPage.jsx

import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";

// (A) import ฟังก์ชันจาก Firestore
import { db } from "../../backend/config/FirebaseSDK";
import { doc, getDoc } from "firebase/firestore";

const SingleNewsPage = () => {
  const { id } = useParams(); // ดึงพารามิเตอร์ id จาก URL

  // (B) State สำหรับเก็บข้อมูล "ข่าว"
  const [news, setNews] = useState(null);
  const [loading, setLoading] = useState(true);

  // State สำหรับ Modal "สมัครเข้าร่วม" และฟอร์ม
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [applicationData, setApplicationData] = useState({
    name: "",
    email: "",
    message: "",
  });
  const [formErrors, setFormErrors] = useState({});
  const [toastMessage, setToastMessage] = useState("");

  // (C) โหลดข้อมูลข่าวจาก Firestore ตาม id
  useEffect(() => {
    const fetchSingleNews = async () => {
      try {
        // สมมติว่าเก็บ "ข่าว" ไว้ใน collection 'contests'
        // ถ้าใช้ชื่อ collection อย่างอื่น ให้เปลี่ยนตามจริง
        const docRef = doc(db, "contests", id);
        const docSnap = await getDoc(docRef);

        if (docSnap.exists()) {
          const data = docSnap.data();
          // แปลงโครงสร้างฟิลด์เป็นรูปแบบเดียวกับที่โค้ดเดิมใช้
          const loadedNews = {
            id: docSnap.id,
            title: data.name || "Untitled",
            posterImage: data.posterURL || "https://dummyimage.com/800x400",
            description: data.shortDescription || "No short description",
            detailedDescription: data.fullDescription || "No detailed description",
            date: data.createdAt
              ? new Date(data.createdAt.seconds * 1000).toLocaleDateString()
              : "ไม่ระบุ",
            category: data.category || "other",
          };
          setNews(loadedNews);
        } else {
          // ไม่เจอเอกสาร
          setNews(null);
        }
      } catch (error) {
        console.error("Error fetching single news:", error);
        setNews(null);
      } finally {
        setLoading(false);
      }
    };

    fetchSingleNews();
  }, [id]);

  //---------------------------------------
  // (D) ฟังก์ชันเปิด/ปิด Modal + จัดการฟอร์ม
  //---------------------------------------
  const openModal = () => setIsModalOpen(true);

  const closeModal = () => {
    setIsModalOpen(false);
    setApplicationData({ name: "", email: "", message: "" });
    setFormErrors({});
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setApplicationData((prev) => ({ ...prev, [name]: value }));
  };

  const validateForm = () => {
    const errors = {};
    if (!applicationData.name.trim()) {
      errors.name = "กรุณากรอกชื่อของคุณ";
    }
    if (!applicationData.email.trim()) {
      errors.email = "กรุณากรอกอีเมลของคุณ";
    } else if (
      !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(applicationData.email)
    ) {
      errors.email = "รูปแบบอีเมลไม่ถูกต้อง";
    }
    if (!applicationData.message.trim()) {
      errors.message = "กรุณากรอกข้อความ";
    }
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateForm()) {
      // สมมุติว่าทำการส่งข้อมูล
      console.log("Application Data:", applicationData);
      setToastMessage("สมัครเข้าร่วมการประกวดเรียบร้อยแล้ว!");
      closeModal();
    }
  };

  //---------------------------------------
  // (E) ส่วน Render
  //---------------------------------------
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-r from-blue-100 via-white to-blue-100">
        <p className="text-center text-gray-600">กำลังโหลดข้อมูล...</p>
      </div>
    );
  }

  // ถ้าโหลดเสร็จแล้ว แต่ไม่เจอข่าว
  if (!news) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-r from-blue-100 via-white to-blue-100">
        <p className="text-center text-gray-600">ไม่พบข่าวสารที่คุณต้องการดู</p>
      </div>
    );
  }

  return (
    <main className="bg-gradient-to-r from-blue-100 via-white to-blue-100 min-h-screen py-8">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* ส่วนหัวข้อข่าว */}
        <h1 className="text-3xl font-bold text-center text-blue-800 mb-6">
          {news.title}
        </h1>

        {/* จัดรูปภาพและเนื้อหาเป็น 2 คอลัมน์เมื่อจอ >= md */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 bg-white rounded-lg shadow-lg p-6">
          {/* คอลัมน์รูปภาพ */}
          <div className="flex justify-center items-start">
            <img
              src={news.posterImage}
              alt={news.title}
              className="w-full h-auto max-w-md object-cover rounded-lg shadow-sm"
            />
          </div>

          {/* คอลัมน์เนื้อหา */}
          <div>
            <p className="text-gray-700 mb-4">{news.description}</p>
            <p className="text-gray-700 mb-4">{news.detailedDescription}</p>
            <p className="text-sm text-gray-500">
              <span className="font-semibold">วันที่เผยแพร่:</span> {news.date}
            </p>
            <p className="text-sm text-gray-500 mb-4">
              <span className="font-semibold">หมวดหมู่:</span> {news.category}
            </p>

            {/* ปุ่มสมัครเข้าร่วมถ้าเป็น "การประกวด" */}
            {news.category === "การประกวด" && (
              <div className="mt-4">
                <button
                  onClick={openModal}
                  className="bg-purple-600 text-white px-5 py-2 rounded-lg hover:bg-purple-700 transition-colors font-semibold"
                >
                  สมัครเข้าร่วม
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Modal สำหรับสมัครเข้าร่วม */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-lg w-full max-w-md p-6 relative">
            <button
              onClick={closeModal}
              className="absolute top-3 right-3 text-gray-500 hover:text-gray-700 text-2xl font-bold"
            >
              &times;
            </button>
            <h2 className="text-2xl font-semibold text-purple-700 mb-4">
              สมัครเข้าร่วม {news.title}
            </h2>
            <form onSubmit={handleSubmit}>
              <div className="mb-4">
                <label className="block text-purple-600 font-medium mb-2">
                  ชื่อของคุณ
                </label>
                <input
                  type="text"
                  name="name"
                  value={applicationData.name}
                  onChange={handleInputChange}
                  className={`w-full px-3 py-2 border ${
                    formErrors.name ? "border-red-500" : "border-purple-300"
                  } rounded focus:outline-none focus:ring-2 focus:ring-purple-500`}
                  placeholder="กรุณากรอกชื่อของคุณ"
                />
                {formErrors.name && (
                  <p className="text-red-500 text-sm mt-1">{formErrors.name}</p>
                )}
              </div>
              <div className="mb-4">
                <label className="block text-purple-600 font-medium mb-2">
                  อีเมลของคุณ
                </label>
                <input
                  type="email"
                  name="email"
                  value={applicationData.email}
                  onChange={handleInputChange}
                  className={`w-full px-3 py-2 border ${
                    formErrors.email ? "border-red-500" : "border-purple-300"
                  } rounded focus:outline-none focus:ring-2 focus:ring-purple-500`}
                  placeholder="กรุณากรอกอีเมลของคุณ"
                />
                {formErrors.email && (
                  <p className="text-red-500 text-sm mt-1">
                    {formErrors.email}
                  </p>
                )}
              </div>
              <div className="mb-4">
                <label className="block text-purple-600 font-medium mb-2">
                  ข้อความเพิ่มเติม
                </label>
                <textarea
                  name="message"
                  value={applicationData.message}
                  onChange={handleInputChange}
                  className={`w-full px-3 py-2 border ${
                    formErrors.message
                      ? "border-red-500"
                      : "border-purple-300"
                  } rounded focus:outline-none focus:ring-2 focus:ring-purple-500`}
                  placeholder="กรุณากรอกข้อความเพิ่มเติม"
                  rows="4"
                />
                {formErrors.message && (
                  <p className="text-red-500 text-sm mt-1">
                    {formErrors.message}
                  </p>
                )}
              </div>
              <div className="flex justify-end">
                <button
                  type="submit"
                  className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors font-semibold"
                >
                  ส่งสมัคร
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Toast Message */}
      {toastMessage && (
        <div className="fixed bottom-4 right-4 bg-green-500 text-white px-4 py-2 rounded-lg shadow-lg animate-fadeInOut">
          {toastMessage}
        </div>
      )}
    </main>
  );
};

export default SingleNewsPage;

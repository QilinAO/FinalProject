// src/Pages/User/HomePage.jsx

import React, { useState, useEffect, useRef } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";

// Firebase Firestore
import {
  collection,
  query,
  where,  // <--- ย้ายออก เพราะไม่ใช้ where()
  onSnapshot,
  orderBy,
  limit,
} from "firebase/firestore";
import { db } from "../../backend/config/FirebaseSDK";

// ความถี่ในการเลื่อนสไลด์อัตโนมัติ (มิลลิวินาที)
const SLIDE_INTERVAL = 5000;

const HomePage = () => {
  // --- (A) state โปสเตอร์ (ทุกประเภท)
  const [contestItems, setContestItems] = useState([]);
  const [loadingContest, setLoadingContest] = useState(true);
  const [errorContest, setErrorContest] = useState(null);

  // --- (B) state ข่าวสาร
  const [newsItems, setNewsItems] = useState([]);
  const [loadingNews, setLoadingNews] = useState(true);
  const [errorNews, setErrorNews] = useState(null);

  // --- Carousel control
  const [currentPosterIndex, setCurrentPosterIndex] = useState(0);
  const autoSlideRef = useRef(null);

  //------------------------------------------
  // 1) โหลดข้อมูล "โปสเตอร์" (ดึง 8 รายการล่าสุด ทุก category)
  //------------------------------------------
  useEffect(() => {
    const colRef = collection(db, "contests");
    // เอา where(...) ออก เหลือแค่ orderBy + limit
    const qContests = query(
      collection(db, "contests"),
      where("status", "==", "กำลังดำเนินการ"),
      orderBy("createdAt", "desc"),
      limit(8)
    );
    let unsubscribe;
    try {
      unsubscribe = onSnapshot(
        qContests,
        (snapshot) => {
          const arr = [];
          snapshot.forEach((docSnap) => {
            arr.push({ id: docSnap.id, ...docSnap.data() });
          });
          const mapped = arr.map((docObj) => ({
            id: docObj.id,
            image: docObj.posterURL || "",
            title: docObj.name || "Untitled",
            description: docObj.shortDescription || "",
          }));
          setContestItems(mapped);
          setLoadingContest(false);
        },
        (err) => {
          console.error("Error getting contests:", err);
          setErrorContest(err.message);
          setLoadingContest(false);
        }
      );
    } catch (err) {
      console.error("Error in contest useEffect:", err);
      setErrorContest(err.message);
      setLoadingContest(false);
    }

    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, []);

  //------------------------------------------
  // 2) โหลดข้อมูล “ข่าวสาร” (8 รายการล่าสุด)
  //------------------------------------------
  useEffect(() => {
    const colRef = collection(db, "contests");
    const qNews = query(
      colRef,
      where("category", "in", ["ข่าวสารทั่วไป", "ข่าวสารประชาสัมพันธ์", "การประกวด"]),
      orderBy("createdAt", "desc"),
      limit(8)
    );

    let unsubscribe;
    try {
      unsubscribe = onSnapshot(
        qNews,
        (snapshot) => {
          const arr = [];
          snapshot.forEach((docSnap) => {
            arr.push({ id: docSnap.id, ...docSnap.data() });
          });
          const mapped = arr.map((docObj) => ({
            id: docObj.id,
            image: docObj.posterURL || "",
            title: docObj.name || "Untitled",
            description: docObj.fullDescription || "",
            date: docObj.createdAt
              ? new Date(docObj.createdAt.seconds * 1000).toLocaleDateString()
              : "ไม่ระบุ",
          }));
          setNewsItems(mapped);
          setLoadingNews(false);
        },
        (err) => {
          console.error("Error getting news:", err);
          setErrorNews(err.message);
          setLoadingNews(false);
        }
      );
    } catch (err) {
      console.error("Error in news useEffect:", err);
      setErrorNews(err.message);
      setLoadingNews(false);
    }

    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, []);

  //------------------------------------------
  // Carousel auto slide
  //------------------------------------------
  useEffect(() => {
    // เริ่มสไลด์อัตโนมัติทันทีที่โหลดโปสเตอร์เสร็จ
    if (!loadingContest) {
      startAutoSlide();
    }
    return () => clearInterval(autoSlideRef.current);
  }, [loadingContest, contestItems]);

  const startAutoSlide = () => {
    if (contestItems.length > 0) {
      autoSlideRef.current = setInterval(() => {
        setCurrentPosterIndex((prev) => (prev + 1) % contestItems.length);
      }, SLIDE_INTERVAL);
    }
  };

  const handleUserInteraction = () => {
    clearInterval(autoSlideRef.current);
    startAutoSlide();
  };

  const nextPoster = () => {
    setCurrentPosterIndex((prev) =>
      contestItems.length === 0 ? 0 : (prev + 1) % contestItems.length
    );
    handleUserInteraction();
  };

  const prevPoster = () => {
    setCurrentPosterIndex((prev) =>
      contestItems.length === 0 ? 0 : (prev - 1 + contestItems.length) % contestItems.length
    );
    handleUserInteraction();
  };

  //------------------------------------------
  // Render
  //------------------------------------------
  return (
    <main className="bg-gradient-to-b from-pink-100 via-red-100 to-purple-200 py-12 md:py-14">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">

        {/* =========================================
            Section: โปสเตอร์ (8 รายการล่าสุด)
        ========================================= */}
        <section className="relative">
          {/* Loading / Error */}
          {loadingContest && (
            <p className="text-center text-gray-600">กำลังโหลดข้อมูล...</p>
          )}
          {errorContest && (
            <p className="text-center text-red-600">
              เกิดข้อผิดพลาด: {errorContest}
            </p>
          )}

          {/* แสดง Carousel เมื่อโหลดเสร็จ & ไม่มี Error */}
          {!loadingContest && !errorContest && (
            <div className="relative flex items-center justify-center mt-4">
              {/* ปุ่มเลื่อนก่อนหน้า */}
              <button
                onClick={prevPoster}
                className="absolute left-3 z-20 bg-white/70 hover:bg-white text-purple-600 shadow-md p-3 rounded-full transition-transform duration-300 transform hover:scale-110"
                aria-label="เลื่อนไปยังโปสเตอร์ก่อนหน้า"
              >
                <ChevronLeft />
              </button>

              {/* Carousel Container (สัดส่วน 16:9) */}
              <div className="w-full max-w-screen-xl relative overflow-hidden rounded-xl shadow-lg aspect-video">
                {contestItems.length > 0 ? (
                  <div
                    className="flex transition-transform duration-700 ease-in-out"
                    style={{
                      transform: `translateX(-${currentPosterIndex * 100}%)`,
                      width: `${contestItems.length * 100}%`,
                    }}
                  >
                    {contestItems.map((poster) => (
                      <div
                        key={poster.id}
                        className="w-full flex-shrink-0 relative group"
                      >
                        <Link to={`/contest/${poster.id}`}>
                          <img
                            src={poster.image}
                            alt={poster.title || "Poster"}
                            className="w-full h-full object-contain bg-gray-200"
                          />
                          {/* Overlay เมื่อ hover */}
                          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
                            <h3 className="text-white text-xl font-bold">
                              {poster.title}
                            </h3>
                          </div>
                        </Link>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="flex items-center justify-center bg-gray-300 text-gray-700 w-full h-full">
                    ไม่มีโปสเตอร์ (ไม่พบใน Firestore)
                  </div>
                )}
              </div>

              {/* ปุ่มเลื่อนถัดไป */}
              <button
                onClick={nextPoster}
                className="absolute right-3 z-20 bg-white/70 hover:bg-white text-purple-600 shadow-md p-3 rounded-full transition-transform duration-300 transform hover:scale-110"
                aria-label="เลื่อนไปยังโปสเตอร์ถัดไป"
              >
                <ChevronRight />
              </button>
            </div>
          )}

          {/* Dots แสดงตำแหน่งของ Carousel */}
          {contestItems.length > 0 && !loadingContest && !errorContest && (
            <div className="flex justify-center mt-6">
              {contestItems.map((_, index) => (
                <button
                  key={index}
                  onClick={() => {
                    setCurrentPosterIndex(index);
                    handleUserInteraction();
                  }}
                  className={`w-3 h-3 mx-1.5 rounded-full ${
                    index === currentPosterIndex
                      ? "bg-purple-600 w-6 transition-all duration-300"
                      : "bg-gray-300 hover:bg-gray-400 transition-all duration-300"
                  }`}
                  aria-label={`โปสเตอร์ที่ ${index + 1}`}
                />
              ))}
            </div>
          )}
        </section>

        {/* ==============================
            Section: ข่าวสารแนะนำ
        ============================== */}
        <section className="mt-12">
          <h2 className="text-2xl md:text-3xl font-bold text-center mb-8 text-purple-700">
            ข่าวสารแนะนำ
          </h2>

          {loadingNews && (
            <p className="text-center text-gray-600">กำลังโหลดข่าวสาร...</p>
          )}
          {errorNews && (
            <p className="text-center text-red-600">
              เกิดข้อผิดพลาด: {errorNews}
            </p>
          )}

          {!loadingNews && !errorNews && newsItems.length > 0 && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {newsItems.map((news) => (
                <article
                  key={news.id}
                  className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300 group"
                >
                  <Link to={`/news/${news.id}`}>
                    <div className="relative h-48 md:h-52">
                      <img
                        src={news.image}
                        alt={news.title || "News"}
                        className="w-full h-full object-contain bg-gray-200 group-hover:opacity-90 transition-opacity duration-300"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-3">
                        <h3 className="text-white text-sm font-bold drop-shadow-sm">
                          {news.title}
                        </h3>
                      </div>
                    </div>
                    <div className="p-4">
                      <h3 className="text-lg font-semibold text-gray-800 mb-2 line-clamp-2">
                        {news.title}
                      </h3>
                      <p className="line-clamp-3 text-gray-600 text-sm mb-2">
                        {news.description}
                      </p>
                      {news.date && (
                        <time className="text-gray-400 text-xs block">
                          {news.date}
                        </time>
                      )}
                    </div>
                  </Link>
                </article>
              ))}
            </div>
          )}

          {!loadingNews && !errorNews && newsItems.length === 0 && (
            <p className="text-center text-gray-600">
              ไม่มีข่าวสารแนะนำ (ไม่พบใน Firestore)
            </p>
          )}
        </section>
      </div>
    </main>
  );
};

export default HomePage;

// src/pages/SignUp.jsx
import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { signupUser } from "../../backend/Auth/firebase-auth";
// import ไอคอนจาก react-icons
import { FaEye, FaEyeSlash } from "react-icons/fa";

const SignUp = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    username: "",
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    confirmPassword: "",
  });
  const [message, setMessage] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [loading, setLoading] = useState(false);

  // state สำหรับควบคุมการแสดง/ซ่อนรหัสผ่าน
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => {
      const updatedFormData = {
        ...prevData,
        [name]: value,
      };

      // หากเป็น field password หรือ confirmPassword ให้ตรวจสอบความตรงกัน
      if (name === "password" || name === "confirmPassword") {
        if (
          updatedFormData.password === updatedFormData.confirmPassword
        ) {
          setPasswordError("");
        } else {
          setPasswordError("รหัสผ่านไม่ตรงกัน");
        }
      }

      return updatedFormData;
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage("");

    // ตรวจสอบรหัสผ่านซ้ำอีกครั้งก่อนส่งข้อมูล
    if (formData.password !== formData.confirmPassword) {
      setPasswordError("รหัสผ่านไม่ตรงกัน");
      return;
    }

    setLoading(true);
    try {
      // สมัครสมาชิกโดยใช้ฟังก์ชัน signupUser
      await signupUser(formData.email, formData.password, {
        username: formData.username,
        firstName: formData.firstName,
        lastName: formData.lastName,
      });

      // แสดงข้อความว่าสมัครสมาชิกสำเร็จ
      setMessage("สมัครสมาชิกสำเร็จ กรุณาเข้าสู่ระบบ");

      // หลังจากสมัครสมาชิกสำเร็จ เปลี่ยนไปที่หน้าล็อกอิน
      setTimeout(() => {
        navigate("/login");
      }, 2000);
    } catch (error) {
      setMessage("เกิดข้อผิดพลาดในการสมัครสมาชิก: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-200 to-red-200 p-4">
      <div className="w-full max-w-lg bg-white p-6 rounded-lg shadow-lg">
        <h2 className="text-2xl font-bold text-center mb-6 text-purple-700">
          สร้างบัญชีของคุณ
        </h2>

        {/* แสดงข้อความสำเร็จ/ผิดพลาด */}
        {message && (
          <div
            className={`mb-4 text-center ${
              message.includes("สำเร็จ")
                ? "text-green-500"
                : "text-red-500"
            }`}
          >
            {message}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Username */}
          <div>
            <label className="block mb-2 font-medium text-gray-700">
              ชื่อผู้ใช้
            </label>
            <input
              type="text"
              name="username"
              value={formData.username}
              onChange={handleChange}
              className="w-full p-3 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-purple-500"
              placeholder="กรอกชื่อผู้ใช้"
              required
            />
          </div>

          {/* แบ่งเป็น 2 คอลัมน์บน md เพื่อวาง ชื่อ - นามสกุล ข้างกัน */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* First Name */}
            <div>
              <label className="block mb-2 font-medium text-gray-700">
                ชื่อ
              </label>
              <input
                type="text"
                name="firstName"
                value={formData.firstName}
                onChange={handleChange}
                className="w-full p-3 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-purple-500"
                placeholder="กรอกชื่อของคุณ"
                required
              />
            </div>

            {/* Last Name */}
            <div>
              <label className="block mb-2 font-medium text-gray-700">
                นามสกุล
              </label>
              <input
                type="text"
                name="lastName"
                value={formData.lastName}
                onChange={handleChange}
                className="w-full p-3 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-purple-500"
                placeholder="กรอกนามสกุลของคุณ"
                required
              />
            </div>
          </div>

          {/* Email */}
          <div>
            <label className="block mb-2 font-medium text-gray-700">
              อีเมล
            </label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              className="w-full p-3 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-purple-500"
              placeholder="กรอกอีเมลของคุณ"
              required
            />
          </div>

          {/* Password + Confirm Password */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Password */}
            <div>
              <label className="block mb-2 font-medium text-gray-700">
                รหัสผ่าน
              </label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                  className="w-full p-3 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-purple-500"
                  placeholder="กรอกรหัสผ่าน"
                  required
                />
                {/* ปุ่ม toggle show/hide password */}
                <button
                  type="button"
                  className="absolute right-3 top-3 text-gray-500 hover:text-gray-700"
                  onClick={() => setShowPassword((prev) => !prev)}
                >
                  {showPassword ? (
                    <FaEyeSlash size={18} />
                  ) : (
                    <FaEye size={18} />
                  )}
                </button>
              </div>
            </div>

            {/* Confirm Password */}
            <div>
              <label className="block mb-2 font-medium text-gray-700">
                ยืนยันรหัสผ่าน
              </label>
              <div className="relative">
                <input
                  type={showConfirmPassword ? "text" : "password"}
                  name="confirmPassword"
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  className={`w-full p-3 rounded focus:outline-none focus:ring-2 focus:ring-purple-500 border ${
                    passwordError ? "border-red-500" : "border-gray-300"
                  }`}
                  placeholder="ยืนยันรหัสผ่าน"
                  required
                />
                {/* ปุ่ม toggle show/hide confirm password */}
                <button
                  type="button"
                  className="absolute right-3 top-3 text-gray-500 hover:text-gray-700"
                  onClick={() => setShowConfirmPassword((prev) => !prev)}
                >
                  {showConfirmPassword ? (
                    <FaEyeSlash size={18} />
                  ) : (
                    <FaEye size={18} />
                  )}
                </button>
              </div>
              {passwordError && (
                <p className="text-red-500 text-sm mt-1">
                  {passwordError}
                </p>
              )}
            </div>
          </div>

          {/* Submit button */}
          <button
            type="submit"
            className="w-full bg-purple-600 text-white py-2 px-4 rounded hover:bg-purple-700 transition flex items-center justify-center mt-2"
            disabled={loading}
          >
            {loading ? "กำลังสมัครสมาชิก..." : "สมัครสมาชิก"}
          </button>
        </form>

        {/* ปุ่ม/ลิงก์ไปหน้าเข้าสู่ระบบ */}
        <div className="text-center mt-6">
          <p>
            มีบัญชีแล้วใช่ไหม?{" "}
            <Link
              to="/login"
              className="text-purple-600 font-medium underline hover:text-purple-800"
            >
              เข้าสู่ระบบ
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default SignUp;

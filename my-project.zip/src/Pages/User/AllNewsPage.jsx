// src/Pages/AllNewsPage.jsx

import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet'; // ใช้ react-helmet เพื่อจัดการ SEO
import { FaSearch, FaFilter, FaTag } from 'react-icons/fa'; // ไอคอนจาก react-icons

// ------ (A) เพิ่ม import เพื่อใช้งาน Firestore ------
import { db } from '../../backend/config/FirebaseSDK';
import { collection, onSnapshot } from 'firebase/firestore';

const AllNewsPage = () => {
  // --------- (1) State สำหรับข่าวทั้งหมดที่โหลดจาก Firestore ---------
  const [newsItems, setNewsItems] = useState([]);

  // --------- (2) ตัวกรองการค้นหา, หมวดหมู่, และสถานะ pagination ---------
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 6;

  // --------- (3) ดึงข้อมูลจาก Firestore -------------
  useEffect(() => {
    // สมมติว่าเราจัดเก็บ "ข่าว" ต่าง ๆ ใน collection ชื่อ "contests"
    // (กรณีนี้ใช้ "contests" เป็นตัวอย่าง ถ้ามี collection "news" แยก ให้เปลี่ยนเป็น "news" แทน)
    const colRef = collection(db, 'contests');

    // ตั้งตัวฟัง onSnapshot เพื่อดึงข้อมูลเรียลไทม์
    const unsubscribe = onSnapshot(
      colRef,
      (snapshot) => {
        const loadedNews = [];
        snapshot.forEach((doc) => {
          const data = doc.data();

          // สมมติว่าฟิลด์ใน Firestore เก็บไว้ประมาณนี้:
          // name, posterURL, category, createdAt, fullDescription
          // สามารถปรับเปลี่ยนตามจริงได้เลย
          loadedNews.push({
            id: doc.id,
            // เปลี่ยนชื่อ field ให้สอดคล้องกับโค้ดของคุณ
            title: data.name || 'Untitled',
            image: data.posterURL || 'https://dummyimage.com/800x400',
            description: data.fullDescription || 'No description',
            // date เป็น string เพื่อแสดงวันที่
            // ถ้าคุณเก็บ createdAt เป็น Timestamp 
            date: data.createdAt
              ? new Date(data.createdAt.seconds * 1000).toLocaleDateString()
              : 'ไม่ระบุ',
            category: data.category || 'other',
          });
        });
        setNewsItems(loadedNews);
      },
      (error) => {
        console.error('Error fetching news:', error);
      }
    );

    // cleanup เมื่อ component unmount
    return () => unsubscribe();
  }, []);

  // --------- (4) ฟังก์ชันกรองข่าวสารตาม category, search ---------
  const filteredNews = newsItems.filter((news) => {
    const matchesCategory = selectedCategory === 'all' || news.category === selectedCategory;
    const matchesSearch =
      news.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      news.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // --------- (5) Pagination ---------
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentNews = filteredNews.slice(indexOfFirstItem, indexOfLastItem);
  const totalPages = Math.ceil(filteredNews.length / itemsPerPage);

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSearch = () => {
    // รีเซ็ตหน้าปัจจุบันเมื่อมีการค้นหา
    setCurrentPage(1);
  };

  // -----------------------------
  //  (6) Render หน้า AllNewsPage
  // -----------------------------
  return (
    <main className="bg-gradient-to-r from-purple-200 via-pink-200 to-red-200 min-h-screen py-6 md:py-12">
      {/* (6A) SEO ด้วย react-helmet */}
      <Helmet>
        <title>ข่าวสารทั้งหมด - BettaFish</title>
        <meta
          name="description"
          content="อ่านข่าวสารทั้งหมดเกี่ยวกับการประกวดและข้อมูลต่างๆ ของ BettaFish"
        />
        {/* Open Graph Meta Tags สำหรับ SEO */}
        <meta property="og:title" content="ข่าวสารทั้งหมด - BettaFish" />
        <meta
          property="og:description"
          content="อ่านข่าวสารทั้งหมดเกี่ยวกับการประกวดและข้อมูลต่างๆ ของ BettaFish"
        />
        <meta property="og:image" content="https://dummyimage.com/1200x630" />
        <meta property="og:url" content="https://yourwebsite.com/all-news" />
        <meta property="og:type" content="website" />
      </Helmet>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-center mb-8 text-purple-700">
          ข่าวสารทั้งหมด
        </h2>

        {/* (6B) ส่วนค้นหาและกรองหมวดหมู่ */}
        <div className="mb-6 w-full max-w-4xl mx-auto flex flex-col sm:flex-row items-center gap-4 sm:gap-6">
          {/* ช่องค้นหา */}
          <div className="relative w-full sm:w-2/3">
            <FaSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="ค้นหาข่าวสาร..."
              className="p-2 pl-10 pr-4 rounded-lg w-full border border-gray-300 focus:outline-none focus:ring-2 focus:ring-purple-500"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  handleSearch();
                }
              }}
            />
            {/* ปุ่มค้นหา */}
            <button
              onClick={handleSearch}
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-purple-600 hover:text-purple-800"
              aria-label="ค้นหา"
            >
              <FaSearch />
            </button>
          </div>

          {/* เลือกหมวดหมู่ */}
          <div className="relative w-full sm:w-1/3">
            <FaFilter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <select
              className="p-2 pl-10 pr-4 rounded-lg w-full border border-gray-300 focus:outline-none focus:ring-2 focus:ring-purple-500 appearance-none bg-white"
              value={selectedCategory}
              onChange={(e) => {
                setSelectedCategory(e.target.value);
                setCurrentPage(1); // รีเซ็ตหน้าเมื่อเปลี่ยนหมวด
              }}
            >
              <option value="all">ทั้งหมด</option>
              <option value="ข่าวสารทั่วไป">ข่าวสารทั่วไป</option>
              <option value="การประกวด">การประกวด</option>
              <option value="ข่าวสารประชาสัมพันธ์">ข่าวสารประชาสัมพันธ์</option>
              {/* คุณอาจเพิ่มหมวดอื่น ๆ ตามใน Firestore ได้ */}
            </select>
          </div>
        </div>

        {/* (6C) แสดงผลข่าวสาร + Pagination */}
        {filteredNews.length === 0 ? (
          <p className="text-center text-gray-700">
            ไม่พบข่าวสารที่ตรงกับการค้นหา
          </p>
        ) : (
          <>
            {/* Grid ข่าวสาร */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {currentNews.map((news) => (
                <article
                  key={news.id}
                  className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300 flex flex-col"
                >
                  <Link to={`/news/${news.id}`} className="block flex-1">
                    <img
                      src={news.image}
                      alt={news.title}
                      className="w-full h-32 object-cover"
                      loading="lazy"
                    />
                    <div className="p-4 flex flex-col flex-1">
                      <h3 className="text-lg font-semibold text-gray-800 mb-2 flex items-center space-x-2">
                        <FaTag className="w-5 h-5 text-purple-600" />
                        <span>{news.title}</span>
                      </h3>
                      <p className="line-clamp-3 text-gray-600 text-sm flex-1">
                        {news.description}
                      </p>
                      <div className="mt-4 flex justify-between items-center">
                        <span className="text-gray-400 text-xs">
                          {news.date}
                        </span>
                        <span className="text-xs bg-purple-100 text-purple-800 px-2 py-1 rounded-full">
                          {news.category}
                        </span>
                      </div>
                    </div>
                  </Link>
                </article>
              ))}
            </div>

            {/* Pagination */}
            <div className="mt-8 flex justify-center items-center space-x-2">
              <button
                onClick={() => handlePageChange(currentPage - 1)}
                disabled={currentPage === 1}
                className={`px-4 py-2 rounded-lg ${
                  currentPage === 1
                    ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                    : 'bg-purple-600 text-white hover:bg-purple-700'
                }`}
              >
                ก่อนหน้า
              </button>
              <span className="text-gray-700">
                หน้า {currentPage} จาก {totalPages}
              </span>
              <button
                onClick={() => handlePageChange(currentPage + 1)}
                disabled={currentPage === totalPages}
                className={`px-4 py-2 rounded-lg ${
                  currentPage === totalPages
                    ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                    : 'bg-purple-600 text-white hover:bg-purple-700'
                }`}
              >
                ถัดไป
              </button>
            </div>
          </>
        )}
      </div>
    </main>
  );
};

export default AllNewsPage;

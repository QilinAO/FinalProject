// src/pages/Login.jsx

import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { loginUser, getUserRole } from "../../backend/Auth/firebase-auth";

const Login = () => {
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });
  const [rememberMe, setRememberMe] = useState(false);
  const [message, setMessage] = useState("");
  const [loadingState, setLoadingState] = useState(false);

  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage("");

    if (!formData.email || !formData.password) {
      setMessage("กรุณากรอกข้อมูลให้ครบถ้วน!");
      return;
    }

    setLoadingState(true);

    try {
      const user = await loginUser(formData.email, formData.password);
      const role = await getUserRole(user.uid);

      if (role === "admin") {
        setMessage("เข้าสู่ระบบสำเร็จ! คุณเป็นผู้ดูแลระบบ.");
        navigate("/admin-dashboard");
      } else if (role === "manager") {
        setMessage("เข้าสู่ระบบสำเร็จ! คุณเป็นผู้จัดการ.");
      } else if (role === "expert") {
        setMessage("เข้าสู่ระบบสำเร็จ! คุณเป็นผู้เชี่ยวชาญ.");
      } else {
        setMessage("เข้าสู่ระบบสำเร็จ! คุณเป็นผู้ใช้ทั่วไป.");
      }

      // Remember me
      if (rememberMe) {
        localStorage.setItem("rememberMe", JSON.stringify(formData));
      } else {
        localStorage.removeItem("rememberMe");
      }

      setFormData({
        email: "",
        password: "",
      });

      // ถ้าไม่ใช่ admin ให้กลับไปหน้าแรก
      if (role !== "admin") {
        navigate("/");
      }
    } catch (error) {
      console.error("Error logging in: ", error);
      setMessage("เกิดข้อผิดพลาดในการเข้าสู่ระบบ: " + error.message);
    } finally {
      setLoadingState(false);
    }
  };

  return (
    // พื้นหลัง Gradient + ครอบด้วย Flex ให้วางกลางจอ
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-200 to-red-200 p-4">
      {/* กล่องใหญ่สุด จัดเป็น 2 คอลัมน์เมื่อ md ขึ้นไป */}
      <div className="flex flex-col md:flex-row w-full max-w-4xl bg-white rounded-lg shadow-lg overflow-hidden">
        {/* คอลัมน์ซ้าย: สามารถเปลี่ยนเป็นรูปภาพ / banner ได้ */}
        <div className="hidden md:block md:w-1/2 bg-purple-50">
          {/* ใส่รูปภาพแทนได้ เช่น
              <img
                src="/path/to/your-image.jpg"
                alt="Login Banner"
                className="w-full h-full object-cover"
              />
          */}
          <div className="h-full w-full flex items-center justify-center p-6">
            <h2 className="text-xl text-purple-600 font-semibold">
              ยินดีต้อนรับสู่ BettaFish
            </h2>
          </div>
        </div>

        {/* คอลัมน์ขวา: ส่วนฟอร์ม */}
        <div className="w-full md:w-1/2 p-8">
          <h2 className="text-3xl font-bold text-center mb-4 text-purple-700">
            เข้าสู่ระบบ
          </h2>
          {/* แสดงข้อความผิดพลาด/สำเร็จ */}
          {message && (
            <div
              className={`mb-4 text-center ${
                message.includes("สำเร็จ")
                  ? "text-green-500"
                  : "text-red-500"
              }`}
            >
              {message}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* อีเมล */}
            <div>
              <label className="block mb-2 font-medium text-gray-700">
                อีเมล
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                className="w-full p-3 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-purple-500"
                placeholder="กรอกอีเมลของคุณ"
                required
              />
            </div>
            {/* รหัสผ่าน */}
            <div>
              <label className="block mb-2 font-medium text-gray-700">
                รหัสผ่าน
              </label>
              <input
                type="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                className="w-full p-3 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-purple-500"
                placeholder="กรอกรหัสผ่านของคุณ"
                required
              />
            </div>
            {/* Checkbox Remember Me */}
            <div className="flex items-center mb-4">
              <input
                type="checkbox"
                id="rememberMe"
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
                className="mr-2"
              />
              <label htmlFor="rememberMe" className="text-gray-700 text-sm">
                จดจำรหัสผ่าน
              </label>
            </div>
            {/* ปุ่มเข้าสู่ระบบ */}
            <button
              type="submit"
              className="w-full bg-purple-600 text-white py-2 px-4 rounded hover:bg-purple-700 transition"
              disabled={loadingState}
            >
              {loadingState ? "กำลังเข้าสู่ระบบ..." : "เข้าสู่ระบบ"}
            </button>
          </form>

          <p className="mt-4 text-center text-sm text-gray-600">
            ลืมรหัสผ่าน?{" "}
            <Link to="/forgot-password" className="text-purple-500 hover:underline">
              กดที่นี่เพื่อรีเซ็ตรหัสผ่าน
            </Link>
          </p>
          <p className="mt-6 text-center text-sm text-gray-600">
            ยังไม่มีบัญชี?{" "}
            <Link to="/signup" className="text-purple-500 hover:underline">
              สมัครสมาชิก
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;

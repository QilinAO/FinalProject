// src/Pages/Expert/ExpertDashboard.jsx
import React, { useState, useEffect } from 'react';
import { PieChart, Pie, Cell, Tooltip, Legend } from 'recharts';
import { Bell, FileText, CheckCircle, XCircle } from 'lucide-react';
import { fetchBettaEvaluations } from '../../backend/server_expert/ExpertDashboard';

const ExpertDashboard = () => {
  const [notifications, setNotifications] = useState([]);
  const [summaryData, setSummaryData] = useState({
    totalBettas: 0,
    pendingEvaluations: 0,
    completedEvaluations: 0,
    rejectedBettas: 0
  });
  const [prevPendingEvaluations, setPrevPendingEvaluations] = useState(0);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await fetchBettaEvaluations();
        const pendingItems = data.filter(item => item.status === "รอการประเมิน");
        const completedItems = data.filter(item => item.status === "ประเมินแล้ว");
        const rejectedItems = data.filter(item => item.status === "ปฏิเสธ");

        if (pendingItems.length > prevPendingEvaluations) {
          const newNotification = {
            id: Math.random().toString(36).substr(2, 9),
            message: `มีปลากัดใหม่รอการประเมิน`,
            type: "assignment"
          };
          setNotifications(prev => [...prev, newNotification]);
        }

        setPrevPendingEvaluations(pendingItems.length);

        setSummaryData({
          totalBettas: data.length,
          pendingEvaluations: pendingItems.length,
          completedEvaluations: completedItems.length,
          rejectedBettas: rejectedItems.length
        });
      } catch (error) {
        console.error("Error fetching evaluations:", error);
      }
    };

    fetchData();
  }, [prevPendingEvaluations]);

  const chartData = [
    { name: 'รอประเมิน', value: summaryData.pendingEvaluations, color: '#FFB800' },
    { name: 'ประเมินแล้ว', value: summaryData.completedEvaluations, color: '#4CAF50' },
    { name: 'ปฏิเสธ', value: summaryData.rejectedBettas, color: '#FF5252' }
  ];

  return (
    <div className="bg-gray-50 min-h-screen">
      {/* เปลี่ยนจาก ml-64 เป็น pt-20 เพื่อเลื่อนลงจาก Navbar ด้านบน */}
      <div className="pt-20 p-6 w-full">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold text-gray-800">Dashboard</h1>
          <div className="relative">
            <Bell className="text-gray-600 hover:text-blue-500 cursor-pointer" />
            {notifications.length > 0 && (
              <span className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full px-2 py-1 text-xs">
                {notifications.length}
              </span>
            )}
          </div>
        </div>

        <div className="grid grid-cols-3 gap-6">
          <div className="col-span-2 bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-semibold mb-4">สรุปสถานะปลากัด</h2>
            <div className="flex justify-center items-center">
              <PieChart width={400} height={400}>
                <Pie
                  data={chartData}
                  dataKey="value"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  innerRadius={80}
                  outerRadius={100}
                  label={({ name, value }) => `${name}: ${value}`}
                >
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-semibold mb-4">การแจ้งเตือน</h2>
            {notifications.map((note) => (
              <div
                key={note.id}
                className={`p-3 mb-2 rounded flex items-center 
                  ${
                    note.type === 'assignment'
                      ? 'bg-blue-50 text-blue-700'
                      : 'bg-yellow-50 text-yellow-700'
                  }`}
              >
                {note.type === 'assignment' ? (
                  <FileText className="mr-2" />
                ) : (
                  <CheckCircle className="mr-2" />
                )}
                {note.message}
              </div>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-3 gap-6 mt-6">
          <div className="bg-white p-6 rounded-lg shadow-md flex items-center">
            <FileText className="mr-4 text-blue-500" size={48} />
            <div>
              <h3 className="text-lg font-semibold">งานที่รอดำเนินการ</h3>
              <p className="text-2xl font-bold">{summaryData.pendingEvaluations}</p>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md flex items-center">
            <CheckCircle className="mr-4 text-green-500" size={48} />
            <div>
              <h3 className="text-lg font-semibold">ประเมินแล้ว</h3>
              <p className="text-2xl font-bold">{summaryData.completedEvaluations}</p>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md flex items-center">
            <XCircle className="mr-4 text-red-500" size={48} />
            <div>
              <h3 className="text-lg font-semibold">ปลากัดที่ปฏิเสธ</h3>
              <p className="text-2xl font-bold">{summaryData.rejectedBettas}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ExpertDashboard;

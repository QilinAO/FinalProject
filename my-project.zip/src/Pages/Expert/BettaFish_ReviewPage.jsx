// src/Pages/Expert/BettaFish_ReviewPage.jsx
import React, { useState, useEffect } from "react";
import { Search, Eye, X } from "lucide-react";
import axios from "axios";
import { Tooltip } from "react-tooltip";
import "react-tooltip/dist/react-tooltip.css";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const BettaReviewPage = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [bettaType, setBettaType] = useState("");
  const [sortBy, setSortBy] = useState("newest");
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedBetta, setSelectedBetta] = useState(null);
  const [bettaData, setBettaData] = useState([]);
  const [scores, setScores] = useState({
    head_and_eyes: 0,
    body_and_scales: 0,
    dorsal_fin: 0,
    tail_fin: 0,
    pectoral_fin: 0,
    other_fins: 0,
    color_and_pattern: 0,
    swimming_and_posture: 0,
    fighting_ability: 0,
    overall_impression: 0,
  });

  // ดึงข้อมูลปลากัดทั้งหมดเมื่อ component โหลด
  useEffect(() => {
    const fetchBettaData = async () => {
      try {
        const response = await axios.get("http://localhost:3000/bettaReviews/all");
        console.log("API Response:", response); // Log ดูข้อมูล
        if (response.data.success) {
          setBettaData(response.data.data); // ตั้งค่า bettaData ด้วยข้อมูล
        } else {
          console.error("Failed to fetch betta data:", response.data.message);
        }
      } catch (error) {
        console.error("Failed to fetch betta data:", error);
      }
    };
    fetchBettaData();
  }, []);

  // แสดงสถานะ
  const renderBettaStatus = (status) => {
    const statusColors = {
      "รอการตรวจสอบ": "bg-yellow-100 text-yellow-800",
      "อนุมัติ": "bg-green-100 text-green-800",
      "ปฏิเสธ": "bg-red-100 text-red-800",
    };
    return (
      <span className={`px-2 py-1 rounded ${statusColors[status]}`}>
        {status}
      </span>
    );
  };

  // เปิด Modal
  const openModal = async (betta) => {
    setSelectedBetta(betta);
    // รีเซ็ตคะแนน
    setScores({
      head_and_eyes: 0,
      body_and_scales: 0,
      dorsal_fin: 0,
      tail_fin: 0,
      pectoral_fin: 0,
      other_fins: 0,
      color_and_pattern: 0,
      swimming_and_posture: 0,
      fighting_ability: 0,
      overall_impression: 0,
    });
    setModalOpen(true);

    // ดึง Evaluations สำหรับ Betta
    try {
      const response = await axios.get(
        `http://localhost:3000/evaluations/all?bettaId=${betta.id}`
      );
      if (response.data.success) {
        setSelectedBetta((prevBetta) => ({
          ...prevBetta,
          evaluations: response.data.data.filter(
            (evalItem) => evalItem.bettaId === betta.id
          ),
        }));
      } else {
        console.error("Failed to fetch evaluations:", response.data.message);
      }
    } catch (error) {
      console.error("Failed to fetch evaluations:", error);
    }
  };

  // ปิด Modal
  const closeModal = () => {
    setSelectedBetta(null);
    setModalOpen(false);
  };

  // เปลี่ยนคะแนน
  const handleScoreChange = (category, score) => {
    setScores((prev) => ({
      ...prev,
      [category]: score,
    }));
  };

  // รวมคะแนน
  const calculateTotalScore = () => {
    return Object.values(scores).reduce((a, b) => a + b, 0);
  };

  // ส่งผลการประเมิน
  const submitEvaluation = async () => {
    // ตรวจว่ากรอกครบ
    const allScoresSet = Object.values(scores).every((score) => score > 0);
    if (!allScoresSet) {
      toast.error("กรุณากรอกคะแนนให้ครบทุกหมวดหมู่");
      return;
    }

    try {
      const evaluationData = {
        bettaId: selectedBetta.id,
        scores: scores,
        totalScore: calculateTotalScore(),
        evaluatorId: "expert1", // ใส่ ID ของผู้ประเมินจริงถ้ามี
      };

      const response = await axios.post(
        "http://localhost:3000/evaluations",
        evaluationData
      );

      if (response.data.success) {
        toast.success("การประเมินสำเร็จ!");
        closeModal();
        // อัปเดตข้อมูล bettaData
        setBettaData((prevData) =>
          prevData.map((betta) =>
            betta.id === selectedBetta.id
              ? {
                  ...betta,
                  evaluationScores: scores,
                  totalScore: calculateTotalScore(),
                }
              : betta
          )
        );
      } else {
        console.error("Failed to submit evaluation:", response.data.message);
        toast.error("การประเมินล้มเหลว: " + response.data.message);
      }
    } catch (error) {
      console.error("Failed to submit evaluation:", error);
      toast.error("เกิดข้อผิดพลาดในการส่งผลประเมิน");
    }
  };

  // Component สำหรับรับคะแนน
  const ScoreInput = ({ category, label }) => (
    <div className="flex items-center space-x-2 mb-2">
      <label className="w-48 font-medium text-gray-700">{label}</label>
      <div className="flex space-x-1">
        {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((score) => (
          <button
            key={score}
            onClick={() => handleScoreChange(category, score)}
            className={`p-2 rounded-full 
              ${
                scores[category] === score
                  ? "bg-blue-500 text-white"
                  : "bg-gray-200 text-gray-700 hover:bg-gray-300"
              } transition-colors duration-200`}
            data-tooltip-id={`tooltip-${category}-${score}`}
            data-tooltip-content={`คะแนน ${score} สำหรับ ${label}`}
          >
            {score}
          </button>
        ))}
      </div>
    </div>
  );

  return (
    <div className="bg-gray-50 min-h-screen">
      {/* ใส่ pt-20 เพื่อเว้นจาก Navbar ด้านบน */}
      <div className="pt-20 p-6 w-full space-y-6">
        <header className="flex justify-between items-center">
          <h1 className="text-3xl font-bold text-gray-800">
            ตรวจสอบข้อมูลปลากัด
          </h1>
        </header>

        {/* ส่วนค้นหา / กรอง */}
        <section className="bg-white p-6 rounded-lg shadow-md">
          <div className="grid grid-cols-4 gap-4">
            {/* ค้นหา */}
            <div className="relative">
              <input
                type="text"
                placeholder="ค้นหา..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring focus:ring-blue-300"
              />
              <Search className="absolute left-3 top-3 text-gray-400" size={20} />
            </div>

            {/* ประเภทปลากัด */}
            <select
              value={bettaType}
              onChange={(e) => setBettaType(e.target.value)}
              className="w-full py-2 px-4 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring focus:ring-blue-300"
            >
              <option value="">ประเภทปลากัด</option>
              <option value="plakat">พลาคัด</option>
              <option value="halfmoon">ฮาฟมูน</option>
            </select>

            {/* ตัวเลือกการจัดเรียง */}
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="w-full py-2 px-4 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring focus:ring-blue-300"
            >
              <option value="newest">วันที่ใหม่สุด</option>
              <option value="oldest">วันที่เก่าสุด</option>
            </select>

            {/* ตัวเลือกวันที่ */}
            <input
              type="date"
              className="w-full py-2 px-4 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring focus:ring-blue-300"
            />
          </div>
        </section>

        {/* ตารางข้อมูลปลากัด */}
        <section className="bg-white rounded-lg shadow-md overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-gray-300">
                <th className="p-4 text-sm font-medium text-gray-700">ชื่อปลากัด</th>
                <th className="p-4 text-sm font-medium text-gray-700">ชื่อผู้เลี้ยง</th>
                <th className="p-4 text-sm font-medium text-gray-700">วันที่อัปโหลด</th>
                <th className="p-4 text-sm font-medium text-gray-700">สถานะ</th>
                <th className="p-4 text-sm font-medium text-gray-700">การกระทำ</th>
              </tr>
            </thead>
            <tbody>
              {bettaData.map((betta, index) => (
                <tr
                  key={betta.id}
                  className={`border-b ${index % 2 === 0 ? "bg-gray-50" : "bg-white"}`}
                >
                  <td className="p-4 text-gray-700">{betta.betta_name}</td>
                  <td className="p-4 text-gray-700">{betta.username}</td>
                  <td className="p-4 text-gray-700">
                    {new Date(betta.evaluationDate).toLocaleDateString()}
                  </td>
                  <td className="p-4">{renderBettaStatus(betta.status)}</td>
                  <td className="p-4">
                    <button
                      onClick={() => openModal(betta)}
                      className="text-blue-500 hover:text-blue-700"
                    >
                      <Eye />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>

        {/* Modal แสดง/แก้ไขการประเมิน */}
        {modalOpen && selectedBetta && (
          <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center p-4">
            <div className="bg-white rounded-lg w-full max-w-4xl h-full max-h-5xl overflow-auto p-6 relative shadow-lg">
              <button
                onClick={closeModal}
                className="absolute top-4 right-4 text-gray-600 hover:text-gray-900"
              >
                <X size={24} />
              </button>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* ส่วนแสดงรูป/วิดีโอปลากัด */}
                <div>
                  <h3 className="text-xl font-bold mb-4">สื่อปลากัด</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                    {selectedBetta.images && selectedBetta.images.length > 0 ? (
                      selectedBetta.images.slice(0, 3).map((imageUrl, imgIndex) => (
                        <img
                          key={imgIndex}
                          src={imageUrl}
                          alt={`ภาพปลากัดที่ ${imgIndex + 1}`}
                          className="w-full h-48 object-cover rounded shadow-md"
                        />
                      ))
                    ) : (
                      <p className="text-gray-500">ไม่มีรูปภาพ</p>
                    )}
                  </div>
                  {selectedBetta.video ? (
                    <video
                      controls
                      className="w-full rounded shadow-md"
                      src={selectedBetta.video}
                    >
                      วิดีโอปลากัด
                    </video>
                  ) : (
                    <p className="text-gray-500">ไม่มีวิดีโอ</p>
                  )}
                </div>

                {/* ส่วนประเมิน */}
                <div>
                  <h2 className="text-2xl font-bold mb-4">แบบประเมินปลากัด</h2>
                  <div className="space-y-4">
                    <div className="mb-4">
                      <p><strong>ชื่อปลากัด:</strong> {selectedBetta.betta_name}</p>
                      <p><strong>อายุปลากัด:</strong> {selectedBetta.betta_age}</p>
                      <p><strong>ขนาดปลากัด:</strong> {selectedBetta.betta_size}</p>
                      <p><strong>ประเภทปลากัด:</strong> {selectedBetta.betta_type}</p>
                      <p><strong>ชนิดปลากัด:</strong> {selectedBetta.betta_kind}</p>
                    </div>

                    {/* ช่องคะแนน */}
                    <ScoreInput category="head_and_eyes" label="หัวและตา" />
                    <ScoreInput category="body_and_scales" label="ลำตัวและเกล็ด" />
                    <ScoreInput category="dorsal_fin" label="ครีบหลัง" />
                    <ScoreInput category="tail_fin" label="ครีบหาง" />
                    <ScoreInput category="pectoral_fin" label="ครีบกระโดง" />
                    <ScoreInput category="other_fins" label="ครีบอื่นๆ" />
                    <ScoreInput category="color_and_pattern" label="สีสันและลวดลาย" />
                    <ScoreInput category="swimming_and_posture" label="การว่ายน้ำและการทรงตัว" />
                    <ScoreInput category="fighting_ability" label="การพองสู้" />
                    <ScoreInput category="overall_impression" label="ภาพรวม" />

                    {/* สรุปคะแนน + ปุ่มส่ง */}
                    <div className="mt-6 border-t pt-4">
                      <div className="flex justify-between items-center">
                        <strong>คะแนนรวม:</strong>
                        <span className="text-xl font-bold">
                          {calculateTotalScore()} / 100
                        </span>
                      </div>
                      <button
                        onClick={submitEvaluation}
                        className="w-full mt-4 bg-blue-500 text-white py-2 rounded-lg hover:bg-blue-600 transition-colors duration-200"
                      >
                        ส่งผลการประเมิน
                      </button>
                    </div>

                    {/* แสดง Evaluations เก่าถ้ามี */}
                    {selectedBetta.evaluations && selectedBetta.evaluations.length > 0 && (
                      <div className="mt-6">
                        <h3 className="text-xl font-bold mb-2">
                          การประเมินที่ผ่านมาของปลากัด
                        </h3>
                        <table className="w-full text-left border-collapse">
                          <thead>
                            <tr className="border-b border-gray-300">
                              <th className="p-2 text-sm font-medium text-gray-700">
                                คะแนนรวม
                              </th>
                              <th className="p-2 text-sm font-medium text-gray-700">
                                วันที่ประเมิน
                              </th>
                              <th className="p-2 text-sm font-medium text-gray-700">
                                ผู้ประเมิน
                              </th>
                            </tr>
                          </thead>
                          <tbody>
                            {selectedBetta.evaluations.map((evaluation, evalIndex) => (
                              <tr
                                key={evalIndex}
                                className={`border-b ${
                                  evalIndex % 2 === 0 ? "bg-gray-50" : "bg-white"
                                }`}
                              >
                                <td className="p-2 text-gray-700">
                                  {evaluation.totalScore} / 100
                                </td>
                                <td className="p-2 text-gray-700">
                                  {evaluation.evaluationDate &&
                                  evaluation.evaluationDate.seconds
                                    ? new Date(
                                        evaluation.evaluationDate.seconds * 1000
                                      ).toLocaleDateString()
                                    : "ไม่ระบุ"}
                                </td>
                                <td className="p-2 text-gray-700">
                                  {evaluation.evaluatorId || "ไม่ระบุ"}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tooltip และ ToastContainer */}
        <Tooltip />
        <ToastContainer />
      </div>
    </div>
  );
};

// Component ScoreInput แบบแยกออกมาหรืออยู่ในไฟล์เดียวก็ได้
// (ตามที่ใช้อยู่ข้างบน)

export default BettaReviewPage;

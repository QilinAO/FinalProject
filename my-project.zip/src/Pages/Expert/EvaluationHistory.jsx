// src/Pages/Expert/EvaluationHistory.jsx
import React, { useState } from "react";

const EvaluationHistory = () => {
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [scoreFilter, setScoreFilter] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [showDetails, setShowDetails] = useState(null);

  const evaluations = [
    {
      id: 1,
      date: "2024-01-15",
      fishName: "Betta Splendens",
      owner: "สมชาย นักรบ",
      totalScore: 100,
      status: "ประเมินแล้ว",
      scores: {
        headAndEyes: 10,
        bodyAndScales: 20,
        dorsalFin: 15,
        tailFin: 10,
        analFin: 10,
        otherFins: 5,
        colorAndPattern: 20,
        swimming: 10,
      },
    },
    {
      id: 2,
      date: "2024-01-14",
      fishName: "Betta Smaragdina",
      owner: "สมหญิง ใจดี",
      totalScore: 90,
      status: "ประเมินแล้ว",
      scores: {
        headAndEyes: 8,
        bodyAndScales: 18,
        dorsalFin: 15,
        tailFin: 10,
        analFin: 10,
        otherFins: 5,
        colorAndPattern: 20,
        swimming: 10,
      },
    },
    // More evaluation data...
  ];

  const statusColors = {
    "ประเมินแล้ว": "bg-green-100 text-green-800",
  };

  // ฟิลเตอร์ข้อมูลตามเงื่อนไขที่เลือก
  const filteredEvaluations = evaluations.filter((evaluation) => {
    const matchesKeyword = searchTerm
      ? evaluation.fishName.includes(searchTerm) ||
        evaluation.owner.includes(searchTerm)
      : true;

    const matchesScore = scoreFilter
      ? evaluation.totalScore >= parseInt(scoreFilter, 10)
      : true;

    const matchesDate =
      startDate && endDate
        ? new Date(evaluation.date) >= new Date(startDate) &&
          new Date(evaluation.date) <= new Date(endDate)
        : true;

    return matchesKeyword && matchesScore && matchesDate;
  });

  // รายละเอียด Modal
  const detailsModal = showDetails && (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center">
      <div className="bg-white rounded-lg p-8 max-w-lg shadow-lg relative">
        <button
          onClick={() => setShowDetails(null)}
          className="absolute top-2 right-2 text-gray-500 hover:text-gray-800"
        >
          &times;
        </button>
        <h2 className="text-xl font-bold mb-4">รายละเอียดปลากัด</h2>
        {/* หาปลากัดที่เรากดรายละเอียด */}
        <p>
          <strong>ชื่อปลากัด:</strong>{" "}
          {evaluations.find((e) => e.id === showDetails).fishName}
        </p>
        <p>
          <strong>ผู้เลี้ยง:</strong>{" "}
          {evaluations.find((e) => e.id === showDetails).owner}
        </p>

        {/* คะแนนการประเมิน */}
        <div className="mt-4">
          <h3 className="font-semibold">คะแนนการประเมิน:</h3>
          <ul>
            {Object.entries(
              evaluations.find((e) => e.id === showDetails).scores
            ).map(([key, value]) => (
              <li key={key} className="mt-2">
                <strong>{key}:</strong> {value}
              </li>
            ))}
          </ul>
          <p className="mt-4">
            <strong>คะแนนรวม:</strong>{" "}
            {evaluations.find((e) => e.id === showDetails).totalScore} / 100
          </p>
        </div>

        {/* รูปภาพ */}
        <div className="grid grid-cols-3 gap-4 mt-4">
          <img
            src="/path-to-image1.jpg"
            alt="Fish"
            className="w-full h-auto rounded-md"
          />
          <img
            src="/path-to-image2.jpg"
            alt="Fish"
            className="w-full h-auto rounded-md"
          />
          <img
            src="/path-to-image3.jpg"
            alt="Fish"
            className="w-full h-auto rounded-md"
          />
        </div>

        {/* วิดีโอ */}
        <div className="mt-4">
          <video controls className="w-full">
            <source src="/path-to-video.mp4" type="video/mp4" />
            Your browser does not support the video tag.
          </video>
        </div>
      </div>
    </div>
  );

  return (
    <div className="bg-gray-50 min-h-screen">
      {/* เว้นระยะบนแทน ml-64 */}
      <div className="pt-20 p-6 w-full">
        <div className="container mx-auto">
          <header className="mb-6">
            <h1 className="text-2xl font-bold">ประวัติการประเมิน</h1>
          </header>

          {/* Filters and search */}
          <div className="mb-6 bg-white p-4 rounded shadow-md">
            <div className="grid grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  เริ่มวันที่
                </label>
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring focus:ring-blue-300"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  ถึงวันที่
                </label>
                <input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring focus:ring-blue-300"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  คะแนนขั้นต่ำ
                </label>
                <input
                  type="number"
                  placeholder="8"
                  value={scoreFilter}
                  onChange={(e) => setScoreFilter(e.target.value)}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring focus:ring-blue-300"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  ค้นหา
                </label>
                <input
                  type="text"
                  placeholder="ชื่อปลากัดหรือชื่อผู้เลี้ยง"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring focus:ring-blue-300"
                />
              </div>
            </div>
          </div>

          {/* ตารางแสดงประวัติการประเมิน */}
          <div className="bg-white rounded-lg shadow-md">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-300">
                  <th className="p-4 text-left">วันที่ประเมิน</th>
                  <th className="p-4 text-left">ชื่อปลากัด</th>
                  <th className="p-4 text-left">ผู้เลี้ยง</th>
                  <th className="p-4 text-left">คะแนนรวม</th>
                  <th className="p-4 text-left">สถานะ</th>
                  <th className="p-4 text-left">รายละเอียด</th>
                </tr>
              </thead>
              <tbody>
                {filteredEvaluations.map((evaluation) => (
                  <tr key={evaluation.id} className="border-b">
                    <td className="p-4">{evaluation.date}</td>
                    <td className="p-4">{evaluation.fishName}</td>
                    <td className="p-4">{evaluation.owner}</td>
                    <td className="p-4">{evaluation.totalScore}</td>
                    <td className="p-4">
                      <span
                        className={`px-2 py-1 rounded ${statusColors[evaluation.status]}`}
                      >
                        {evaluation.status}
                      </span>
                    </td>
                    <td className="p-4">
                      <button
                        onClick={() => setShowDetails(evaluation.id)}
                        className="text-blue-500 hover:text-blue-700"
                      >
                        ดูรายละเอียด
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Modal รายละเอียดปลากัด */}
          {detailsModal}
        </div>
      </div>
    </div>
  );
};

export default EvaluationHistory;

import React, { useState, useRef } from "react";
import { User, Mail, Lock, Star, Briefcase, Image, Check, Upload } from "lucide-react";

const ExpertProfile = () => {
  const [isEditMode, setIsEditMode] = useState(false);
  const [profile, setProfile] = useState({
    username: "john_doe",
    firstName: "John",
    lastName: "Doe",
    email: "john.doe@example.com",
    password: "",
    specialization: ["Halfmoon"],
    experience: "5 years breeding Betta fish.",
    profilePicture: null,
  });

  const [previewImage, setPreviewImage] = useState(null);
  const fileInputRef = useRef(null);

  const handleSave = (e) => {
    e.preventDefault();
    setIsEditMode(false);
    alert("บันทึกข้อมูลสำเร็จ!");
    // หรือจะเรียกฟังก์ชันอัปเดตข้อมูลจริง ๆ
  };

  const handleInputChange = (field, value) => {
    setProfile((prev) => ({ ...prev, [field]: value }));
  };

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      setProfile((prev) => ({ ...prev, profilePicture: file }));
      const reader = new FileReader();
      reader.onloadend = () => setPreviewImage(reader.result);
      reader.readAsDataURL(file);
    }
  };

  const handleSpecializationChange = (value) => {
    setProfile((prev) => {
      const newSpecialization = prev.specialization.includes(value)
        ? prev.specialization.filter((item) => item !== value)
        : prev.specialization.length < 2
        ? [...prev.specialization, value]
        : [prev.specialization[1], value];
      return { ...prev, specialization: newSpecialization };
    });
  };

  return (
    <div className="bg-gradient-to-br from-blue-50 to-blue-100 min-h-screen">
      {/* ใช้ pt-20 แทน ml-64 เพื่อกันไม่ให้เมนูด้านบนทับ */}
      <div className="pt-20 p-8 w-full">
        <div className="max-w-3xl mx-auto bg-white shadow-2xl rounded-2xl overflow-hidden">
          <div className="bg-blue-500 text-white p-6 flex items-center justify-between">
            <div className="flex items-center">
              <User className="mr-3 text-white" size={32} />
              <h1 className="text-3xl font-bold">โปรไฟล์ผู้เชี่ยวชาญ</h1>
            </div>
            {!isEditMode && (
              <button
                onClick={() => setIsEditMode(true)}
                className="bg-white text-blue-500 px-4 py-2 rounded-lg hover:bg-gray-100 transition"
              >
                แก้ไขข้อมูล
              </button>
            )}
          </div>

          <form onSubmit={handleSave} className="p-8 space-y-6">
            <div className="flex items-center space-x-6">
              <div
                onClick={() => fileInputRef.current.click()}
                className={`relative cursor-pointer ${
                  !isEditMode && "pointer-events-none opacity-50"
                }`}
              >
                {previewImage ? (
                  <img
                    src={previewImage}
                    alt="Profile"
                    className="w-24 h-24 rounded-full object-cover border-4 border-blue-300"
                  />
                ) : (
                  <div className="w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center">
                    <Image className="text-blue-500" size={40} />
                  </div>
                )}
                {isEditMode && (
                  <div className="absolute bottom-0 right-0 bg-blue-500 text-white rounded-full p-1">
                    <Upload size={16} />
                  </div>
                )}
                <input
                  type="file"
                  ref={fileInputRef}
                  className="hidden"
                  onChange={handleFileUpload}
                />
              </div>

              <div className="flex-1 grid grid-cols-2 gap-4">
                <div>
                  <label className="block mb-2 text-gray-700">ชื่อผู้ใช้:</label>
                  <input
                    type="text"
                    className={`w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500 ${
                      !isEditMode && "bg-gray-100"
                    }`}
                    disabled={!isEditMode}
                    value={profile.username}
                    onChange={(e) => handleInputChange("username", e.target.value)}
                  />
                </div>
                <div>
                  <label className="block mb-2 text-gray-700">อีเมล:</label>
                  <input
                    type="email"
                    className={`w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500 ${
                      !isEditMode && "bg-gray-100"
                    }`}
                    disabled={!isEditMode}
                    value={profile.email}
                    onChange={(e) => handleInputChange("email", e.target.value)}
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block mb-2 text-gray-700">ชื่อ:</label>
                <input
                  type="text"
                  className={`w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500 ${
                    !isEditMode && "bg-gray-100"
                  }`}
                  disabled={!isEditMode}
                  value={profile.firstName}
                  onChange={(e) => handleInputChange("firstName", e.target.value)}
                />
              </div>
              <div>
                <label className="block mb-2 text-gray-700">นามสกุล:</label>
                <input
                  type="text"
                  className={`w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500 ${
                    !isEditMode && "bg-gray-100"
                  }`}
                  disabled={!isEditMode}
                  value={profile.lastName}
                  onChange={(e) => handleInputChange("lastName", e.target.value)}
                />
              </div>
            </div>

            <div>
              <label className="block mb-2 text-gray-700">รหัสผ่านใหม่:</label>
              <input
                type="password"
                className={`w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500 ${
                  !isEditMode && "bg-gray-100"
                }`}
                disabled={!isEditMode}
                value={profile.password}
                onChange={(e) => handleInputChange("password", e.target.value)}
              />
            </div>

            <div>
              <label className="block mb-2 text-gray-700">ประเภทปลากัดที่ถนัด:</label>
              <div className="grid grid-cols-3 gap-4">
                {["Halfmoon", "Crowntail", "Plakat"].map((type) => (
                  <div
                    key={type}
                    onClick={() => isEditMode && handleSpecializationChange(type)}
                    className={`p-3 rounded-lg text-center cursor-pointer transition-all ${
                      profile.specialization.includes(type)
                        ? "bg-blue-500 text-white"
                        : "bg-blue-100 text-blue-800 hover:bg-blue-200"
                    } ${!isEditMode && "pointer-events-none opacity-50"}`}
                  >
                    {type}
                    {profile.specialization.includes(type) && (
                      <Check className="inline ml-2" size={16} />
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div>
              <label className="block mb-2 text-gray-700">ประสบการณ์:</label>
              <textarea
                className={`w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500 ${
                  !isEditMode && "bg-gray-100"
                }`}
                disabled={!isEditMode}
                value={profile.experience}
                onChange={(e) => handleInputChange("experience", e.target.value)}
                rows={4}
              />
            </div>

            {isEditMode && (
              <div className="text-center">
                <button
                  type="submit"
                  className="bg-blue-600 text-white px-10 py-3 rounded-lg hover:bg-blue-700 transition duration-300 shadow-lg"
                >
                  บันทึกข้อมูล
                </button>
              </div>
            )}
          </form>
        </div>
      </div>
    </div>
  );
};

export default ExpertProfile;

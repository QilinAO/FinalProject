// src/context/ProtectedRoute.jsx
import React from "react";
import { Navigate } from "react-router-dom";
import { useUserProfile } from "./UserProfileContext";

const ProtectedRoute = ({ children }) => {
  const { profileData, loading } = useUserProfile();

  if (loading) return <div>กำลังโหลด...</div>;

  if (!profileData) return <Navigate to="/login" />;

  return children;
};

export default ProtectedRoute;


// src/context/UserProfileContext.js
import React, { createContext, useContext, useEffect, useState } from "react";
import { auth, db } from "../backend/config/FirebaseSDK"; // นำเข้า Firebase
import { onAuthStateChanged } from "firebase/auth";
import { doc, getDoc } from "firebase/firestore";

// สร้าง context
const UserProfileContext = createContext();

// ตัว hook สำหรับใช้ context
export const useUserProfile = () => useContext(UserProfileContext);

// คอมโพเนนต์ที่ใช้ในการจัดการข้อมูลผู้ใช้
export const UserProfileProvider = ({ children }) => {
  const [profileData, setProfileData] = useState(null); // สถานะเก็บข้อมูลผู้ใช้
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        try {
          // หากผู้ใช้ล็อกอิน ให้ดึงข้อมูล role จาก Firestore
          const userDocRef = doc(db, "users", user.uid); // ระบุ collection และ document ที่เก็บข้อมูลผู้ใช้
          const userDoc = await getDoc(userDocRef);
          
          if (userDoc.exists()) {
            setProfileData({ ...userDoc.data(), uid: user.uid });
          } else {
            console.error("No user data found in Firestore");
            setProfileData(null); // หากไม่มีข้อมูลผู้ใช้
          }
        } catch (error) {
          console.error("Error fetching user data:", error);
          setProfileData(null); // หากเกิดข้อผิดพลาดในการดึงข้อมูล
        }
      } else {
        setProfileData(null); // หากไม่มีผู้ใช้ล็อกอิน
      }
      setLoading(false);
    });

    return () => unsubscribe(); // คืนค่าฟังก์ชันเมื่อมีการเปลี่ยนแปลง
  }, []);

  return (
    <UserProfileContext.Provider value={{ profileData, loading }}>
      {children}
    </UserProfileContext.Provider>
  );
};

import React, { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { GiHamburgerMenu } from "react-icons/gi";
import { IoMdClose } from "react-icons/io";
import { checkUserState, logoutUser } from "../backend/Auth/firebase-auth";

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [userRole, setUserRole] = useState(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);

  const menuRef = useRef(null);
  const navMenuRef = useRef(null);

  useEffect(() => {
    const unsubscribe = checkUserState((user) => {
      if (user) {
        setUserRole("user");
        setIsLoggedIn(true);
      } else {
        setUserRole(null);
        setIsLoggedIn(false);
      }
    });
    return () => unsubscribe();
  }, []);

  // ปิดเมนูเมื่อคลิกข้างนอก
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        isMenuOpen &&
        navMenuRef.current &&
        !navMenuRef.current.contains(event.target)
      ) {
        setIsMenuOpen(false);
      }

      if (
        isProfileMenuOpen &&
        menuRef.current &&
        !menuRef.current.contains(event.target)
      ) {
        setIsProfileMenuOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [isMenuOpen, isProfileMenuOpen]);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const handleLogout = async () => {
    try {
      await logoutUser();
      setIsLoggedIn(false);
      setUserRole(null);
      setIsProfileMenuOpen(false);
      setIsMenuOpen(false);
    } catch (error) {
      console.error("Error logging out:", error);
    }
  };

  // สร้าง NavLink component ย่อย ให้กดแล้วปิดเมนูบนมือถืออัตโนมัติ
  const NavLink = ({ to, children }) => (
    <Link
      to={to}
      className="relative block text-gray-100 px-3 py-2 rounded-md hover:text-white 
        hover:bg-purple-700/30 transition-all duration-200 ease-in-out text-sm md:text-base font-medium"
      onClick={() => setIsMenuOpen(false)}
    >
      {children}
    </Link>
  );

  return (
    <nav className="bg-purple-800 shadow-xl sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          {/* Logo (Responsive text size) */}
          <Link to="/" className="flex items-center space-x-2 group">
            <span className="text-white text-lg sm:text-xl md:text-2xl font-bold tracking-wider">
              BettaFish
            </span>
          </Link>

          {/* Hamburger Menu (แสดงเฉพาะตอนจอเล็กลง) */}
          <button
            onClick={toggleMenu}
            className="md:hidden text-white hover:text-purple-200 transition-colors duration-200
              p-2 rounded-lg hover:bg-purple-700/30"
          >
            <GiHamburgerMenu className="h-6 w-6" />
          </button>

          {/* Desktop Navigation (ซ่อนตอนจอเล็ก) */}
          <div className="hidden md:flex items-center space-x-1">
            <NavLink to="/">แนะนำ</NavLink>
            <NavLink to="/news">ข่าวสาร</NavLink>
            <NavLink to="/evaluate">ประเมินคุณภาพ</NavLink>
            <NavLink to="/contest">การประกวด</NavLink>
            <NavLink to="/history">ประวัติการใช้งาน</NavLink>

            {/* Profile/Login Button (Desktop) */}
            <div className="relative ml-4" ref={menuRef}>
              {isLoggedIn ? (
                <div>
                  <button
                    onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
                    className="px-4 py-2 bg-purple-700 text-white rounded-lg text-sm md:text-base font-medium
                      shadow-lg hover:bg-purple-600 transition-all duration-200"
                  >
                    โปรไฟล์ผู้ใช้
                  </button>
                  {isProfileMenuOpen && (
                    <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-xl py-1">
                      <Link
                        to="/profile"
                        className="block px-4 py-2 text-gray-700 hover:bg-purple-50 hover:text-purple-800"
                        onClick={() => setIsProfileMenuOpen(false)}
                      >
                        ข้อมูลส่วนตัว
                      </Link>
                      <button
                        onClick={handleLogout}
                        className="block w-full text-left px-4 py-2 text-gray-700 hover:bg-purple-50 hover:text-purple-800"
                      >
                        ออกจากระบบ
                      </button>
                    </div>
                  )}
                </div>
              ) : (
                <Link
                  to="/login"
                  className="px-4 py-2 text-white rounded-lg text-sm md:text-base font-medium hover:bg-purple-600 transition-all duration-200"
                  onClick={() => setIsMenuOpen(false)}
                >
                  เข้าสู่ระบบ
                </Link>
              )}
            </div>
          </div>

          {/* Mobile Menu (Slide-in จากขวา) */}
          <div
            ref={navMenuRef}
            className={`fixed inset-y-0 right-0 transform ${
              isMenuOpen ? "translate-x-0" : "translate-x-full"
            } w-72 bg-purple-800 shadow-2xl transition-transform duration-300 ease-in-out md:hidden
            backdrop-blur-lg bg-opacity-95`}
          >
            {/* ปุ่มปิดเมนูบนมือถือ */}
            <div className="flex justify-end p-4">
              <button
                onClick={() => setIsMenuOpen(false)}
                className="text-white hover:text-purple-200 transition-colors duration-200
                  p-2 rounded-lg hover:bg-purple-700/30"
              >
                <IoMdClose className="h-6 w-6" />
              </button>
            </div>

            {/* Mobile Navigation Links */}
            <div className="px-4 py-4 text-center space-y-2">
              <NavLink to="/">แนะนำ</NavLink>
              <NavLink to="/news">ข่าวสาร</NavLink>
              <NavLink to="/evaluate">ประเมินคุณภาพ</NavLink>
              <NavLink to="/contest">การประกวด</NavLink>
              <NavLink to="/history">ประวัติการใช้งาน</NavLink>

              {/* Profile and Logout Links บนมือถือ */}
              {isLoggedIn ? (
                <>
                  <NavLink to="/profile">ข้อมูลส่วนตัว</NavLink>
                  <Link
                    onClick={handleLogout}
                    to="#"
                    className="relative block text-gray-100 px-3 py-2 rounded-md hover:text-white 
                      hover:bg-purple-700/30 transition-all duration-200 ease-in-out text-sm md:text-base font-medium"
                  >
                    ออกจากระบบ
                  </Link>
                </>
              ) : (
                <NavLink to="/login">เข้าสู่ระบบ</NavLink>
              )}
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;

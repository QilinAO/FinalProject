import React, { useState } from "react";
import { Link, Navigate } from "react-router-dom";
import {
  User,
  LogOut,
  Clipboard,
  Users,
  Star,
  FileText,
  Menu as MenuIcon,
  X as CloseIcon,
} from "lucide-react";
import { useUserProfile } from "../context/UserProfileContext";
import { getAuth } from "firebase/auth";
import { toast } from "react-toastify";

const ManagerMenu = () => {
  const { profileData } = useUserProfile();
  const [isOpen, setIsOpen] = useState(false);

  if (!profileData) {
    return <Navigate to="/login" replace />;
  }
  if (profileData.role !== "manager") {
    return <Navigate to="/" replace />;
  }

  const handleLogout = async () => {
    try {
      const auth = getAuth();
      await auth.signOut();
      toast.success("ออกจากระบบสำเร็จ");
      window.location.href = "/";
    } catch (error) {
      console.error("Error during logout:", error);
      toast.error("เกิดข้อผิดพลาดในการออกจากระบบ");
    }
  };

  return (
    <nav className="fixed top-0 w-full z-50 bg-gradient-to-r from-blue-900 to-blue-800 shadow-lg">
      <div className="max-w-8xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo/Brand - ชิดซ้าย */}
          <div className="flex-shrink-0">
            <span className="text-white text-xl font-bold tracking-wide">
              เมนูผู้จัดการประกวด
            </span>
          </div>

          {/* Desktop Menu - ชิดขวา */}
          <div className="hidden md:flex md:items-center md:space-x-1">
            <NavLink to="/manager/dashboard" icon={Clipboard} label="Dashboard" />
            <NavLink to="/manager/profile" icon={User} label="ข้อมูลต่าง ๆ" />
            <NavLink 
              to="/manager/contest-management" 
              icon={Clipboard} 
              label="เพิ่มการประกวด"
            />
            <NavLink 
              to="/manager/contest-list" 
              icon={Users} 
              label="รายการประกวด"
            />
            <NavLink 
              to="/manager/contest-history" 
              icon={FileText} 
              label="ประวัติการประกวด"
            />
            <NavLink 
              to="/manager/competition-results" 
              icon={Star} 
              label="ผลคะแนน"
            />
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 px-3 py-2 text-white rounded-md
                       hover:bg-blue-700 transition duration-200 ml-2"
            >
              <LogOut size={20} />
              <span>ออกจากระบบ</span>
            </button>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-white hover:text-gray-300 p-2 rounded-md"
            >
              {isOpen ? <CloseIcon size={24} /> : <MenuIcon size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile menu dropdown */}
        {isOpen && (
          <div className="md:hidden bg-blue-800 shadow-inner">
            <div className="px-2 pt-2 pb-3 space-y-1">
              <NavLinkMobile 
                to="/manager/dashboard" 
                icon={Clipboard} 
                label="Dashboard" 
              />
              <NavLinkMobile 
                to="/manager/profile" 
                icon={User} 
                label="ข้อมูลต่าง ๆ" 
              />
              <NavLinkMobile 
                to="/manager/contest-management" 
                icon={Clipboard} 
                label="เพิ่มการประกวด" 
              />
              <NavLinkMobile 
                to="/manager/contest-list" 
                icon={Users} 
                label="รายการประกวด" 
              />
              <NavLinkMobile 
                to="/manager/contest-history" 
                icon={FileText} 
                label="ประวัติการประกวด" 
              />
              <NavLinkMobile 
                to="/manager/competition-results" 
                icon={Star} 
                label="ผลคะแนนการแข่งขัน" 
              />
              <button
                onClick={handleLogout}
                className="w-full flex items-center gap-2 px-3 py-2 text-white rounded-md
                         hover:bg-blue-700 transition duration-200"
              >
                <LogOut size={20} />
                <span>ออกจากระบบ</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

const NavLink = ({ to, icon: Icon, label }) => (
  <Link
    to={to}
    className="flex items-center gap-2 px-3 py-2 text-white rounded-md
               hover:bg-blue-700 transition duration-200"
  >
    <Icon size={20} />
    <span>{label}</span>
  </Link>
);

const NavLinkMobile = ({ to, icon: Icon, label }) => (
  <Link
    to={to}
    className="flex items-center gap-2 px-3 py-2 text-white rounded-md
               hover:bg-blue-700 transition duration-200 block"
  >
    <Icon size={20} />
    <span>{label}</span>
  </Link>
);

export default ManagerMenu;
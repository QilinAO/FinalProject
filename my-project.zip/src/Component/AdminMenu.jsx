import React, { useState } from "react";
import { Link, Navigate } from "react-router-dom";
import { useUserProfile } from "../context/UserProfileContext";
import {
  User,
  LogOut,
  FileText,
  BarChart2,
  Database,
  Menu as MenuIcon,
  X as CloseIcon,
} from "lucide-react";
import { getAuth } from "firebase/auth";
import { toast } from "react-toastify";

const AdminMenu = () => {
  const { profileData } = useUserProfile();
  const [isOpen, setIsOpen] = useState(false);

  if (!profileData) {
    return <Navigate to="/login" replace />;
  }
  if (profileData.role !== "admin") {
    return <Navigate to="/" replace />;
  }

  const handleLogout = async () => {
    try {
      const auth = getAuth();
      await auth.signOut();
      toast.success("ออกจากระบบสำเร็จ");
      window.location.href = "/";
    } catch (error) {
      console.error("Error during logout:", error);
      toast.error("เกิดข้อผิดพลาดในการออกจากระบบ");
    }
  };

  return (
    <nav className="fixed top-0 w-full z-50 bg-gradient-to-r from-blue-900 to-blue-800 shadow-lg">
      <div className="max-w-8xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo/Brand - ชิดซ้าย */}
          <div className="flex-shrink-0">
            <span className="text-white text-xl font-bold tracking-wide">
              เมนูแอดมิน
            </span>
          </div>

          {/* Desktop Menu - ชิดขวา */}
          <div className="hidden md:flex md:items-center md:space-x-2">
            <NavLink 
              to="/admin-dashboard" 
              icon={BarChart2} 
              label="สรุปข้อมูล" 
            />
            <NavLink 
              to="/manage-users" 
              icon={User} 
              label="จัดการผู้ใช้" 
            />
            <NavLink 
              to="/reports" 
              icon={FileText} 
              label="รายงาน" 
            />
            <NavLink 
              to="/database" 
              icon={Database} 
              label="ฐานข้อมูล" 
            />
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 px-4 py-2 text-white rounded-md
                       hover:bg-blue-700 transition duration-200 ml-2"
            >
              <LogOut size={20} />
              <span>ออกจากระบบ</span>
            </button>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-white hover:text-gray-300 p-2 rounded-md
                         transition duration-200"
            >
              {isOpen ? <CloseIcon size={24} /> : <MenuIcon size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile menu dropdown */}
        {isOpen && (
          <div className="md:hidden bg-blue-800 shadow-inner">
            <div className="px-2 pt-2 pb-3 space-y-1">
              <NavLinkMobile 
                to="/admin-dashboard" 
                icon={BarChart2} 
                label="สรุปข้อมูล" 
              />
              <NavLinkMobile 
                to="/manage-users" 
                icon={User} 
                label="จัดการผู้ใช้" 
              />
              <NavLinkMobile 
                to="/reports" 
                icon={FileText} 
                label="รายงาน" 
              />
              <NavLinkMobile 
                to="/database" 
                icon={Database} 
                label="ฐานข้อมูล" 
              />
              <button
                onClick={handleLogout}
                className="w-full flex items-center gap-2 px-3 py-2 text-white rounded-md
                         hover:bg-blue-700 transition duration-200"
              >
                <LogOut size={20} />
                <span>ออกจากระบบ</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

const NavLink = ({ to, icon: Icon, label }) => (
  <Link
    to={to}
    className="flex items-center gap-2 px-4 py-2 text-white rounded-md
               hover:bg-blue-700 transition duration-200"
  >
    <Icon size={20} />
    <span>{label}</span>
  </Link>
);

const NavLinkMobile = ({ to, icon: Icon, label }) => (
  <Link
    to={to}
    className="flex items-center gap-2 px-3 py-2 text-white rounded-md
               hover:bg-blue-700 transition duration-200 block"
  >
    <Icon size={20} />
    <span>{label}</span>
  </Link>
);

export default AdminMenu;
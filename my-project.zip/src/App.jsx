// src/App.jsx
import React, { useEffect, useRef } from "react";
import { Routes, Route, useNavigate, useLocation } from "react-router-dom";
import {
  PublicRoutes,
  ProtectedUserRoutes,
  AdminRoutes,
  ManagerRoutes,
  ExpertRoutes,
} from "./Routes";
import { useUserProfile } from "./context/UserProfileContext";
import AdminMenu from "./Component/AdminMenu";
import Navbar from "./Component/Navbar";
import ManagerMenu from "./Component/ManagerMenu";
import ExpertMenu from "./Component/ExpertMenu";


const App = () => {
  const { profileData, loading } = useUserProfile();
  const navigate = useNavigate();
  const location = useLocation(); // เพิ่มการใช้ useLocation
  const profileRef = useRef(profileData);

  useEffect(() => {
    // เช็คว่า profileData พร้อมใช้งานแล้วก่อนดำเนินการ
    if (loading) return; // ยังโหลดข้อมูลอยู่ ไม่ต้องทำอะไร
  
    if (profileData && profileData.role) {
      // เมื่อข้อมูลโปรไฟล์มี role ให้ทำการนำทาง
      if (location.pathname === "/") {
        switch (profileData.role) {
          case "admin":
            navigate("/admin-dashboard");
            break;
          case "manager":
            navigate("/manager/dashboard");
            break;
          case "expert":
            navigate("/expert-dashboard");
            break;
          case "user":
          default:
            navigate("/");
            break;
        }
      }
    }
  }, [profileData, loading, navigate, location.pathname]);
  
  

  if (loading) {
    return <div>กำลังโหลดข้อมูล...</div>;
  }

  return (
    <>
      {profileData ? (
        <>
          {profileData.role === "admin" && <AdminMenu />}
          {profileData.role === "manager" && <ManagerMenu />}
          {profileData.role === "expert" && <ExpertMenu />}
          {profileData.role === "user" && <Navbar />} {/* แสดง Navbar สำหรับ user */}

          <Routes>
            {/* แสดงเส้นทางที่เหมาะสมสำหรับแต่ละบทบาท */}
            {AdminRoutes.map((route) => (
              <Route key={route.path} path={route.path} element={route.element} />
            ))}
            {ExpertRoutes.map((route) => (
              <Route key={route.path} path={route.path} element={route.element} />
            ))}
            {ManagerRoutes.map((route) => (
              <Route key={route.path} path={route.path} element={route.element} />
            ))}
            {/* เส้นทางสำหรับผู้ใช้ */}
            {ProtectedUserRoutes.map((route) => (
              <Route key={route.path} path={route.path} element={route.element} />
            ))}
            {/* แสดงเส้นทาง PublicRoutes สำหรับผู้ใช้ */}
            {PublicRoutes.map((route) => (
              <Route key={route.path} path={route.path} element={route.element} />
            ))}
          </Routes>
        </>
      ) : (
        <>
          <Navbar />
          <Routes>
            {PublicRoutes.map((route) => (
              <Route key={route.path} path={route.path} element={route.element} />
            ))}
          </Routes>
        </>
      )}
    </>
  );
};

export default App;

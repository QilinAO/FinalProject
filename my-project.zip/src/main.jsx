// src/main.jsx
import React, { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter as Router } from "react-router-dom";
import Modal from "react-modal"; // import Modal
import './index.css';
import App from './App';
import { UserProfileProvider } from './context/UserProfileContext';

// ตั้งค่า app element ก่อนการ render
Modal.setAppElement('#root');

const root = createRoot(document.getElementById('root'));

root.render(
  <StrictMode>
    <Router> 
      <UserProfileProvider>
        <App />
      </UserProfileProvider>
    </Router>
  </StrictMode>
);

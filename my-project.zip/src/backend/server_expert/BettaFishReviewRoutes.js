// src/backend/server_expert/BettaFishReviewRoutes.js
import express from 'express';
import { fetchAllBettaFishEvaluationsWithUsername } from './BettaFish_ReviewPage.js'; // ตรวจสอบเส้นทาง

const router = express.Router();

// GET /bettaReviews/all
router.get('/all', async (req, res) => {
  try {
    console.log("GET /bettaReviews/all called");
    const data = await fetchAllBettaFishEvaluationsWithUsername();
    res.json({ success: true, data });
  } catch (error) {
    console.error("Error in /bettaReviews/all:", error);
    res.status(500).json({ success: false, message: "Failed to fetch BettaFish evaluations with username" });
  }
});

// POST /bettaReviews/evaluate
router.post('/evaluate', async (req, res) => {
    const { bettaId, scores, totalScore } = req.body;
  
    if (!bettaId || !scores || typeof totalScore !== 'number') {
      return res.status(400).json({ success: false, message: "Invalid evaluation data" });
    }
  
    try {
      const bettaRef = db.collection("BettaFishEvaluations").doc(bettaId);
      const doc = await bettaRef.get();
  
      if (!doc.exists) {
        return res.status(404).json({ success: false, message: "BettaFish not found" });
      }
  
      // อัปเดตเอกสารด้วยคะแนนการประเมิน
      await bettaRef.update({
        evaluationScores: scores,
        totalScore: totalScore,
        evaluationDate: admin.firestore.FieldValue.serverTimestamp()
      });
  
      res.json({ success: true, message: "Evaluation submitted successfully" });
    } catch (error) {
      console.error("Error submitting evaluation:", error);
      res.status(500).json({ success: false, message: "Failed to submit evaluation" });
    }
  });
  

export { router as BettaFishReviewRoutes };

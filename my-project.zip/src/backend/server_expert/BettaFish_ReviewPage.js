// src/backend/server_expert/BettaFish_ReviewPage.js
import { db } from "../helpers/firebaseAdminSdk.js"; // นำเข้าจาก firebaseAdminSdk.js

/**
 * ดึงข้อมูลปลากัดทั้งหมดจาก collection "BettaFishEvaluations" พร้อมกับชื่อผู้เลี้ยงจาก collection "users"
 * @returns {Promise<Array>} - ข้อมูลปลากัดในรูปแบบ array ของ object พร้อมชื่อผู้เลี้ยง
 */
export const fetchAllBettaFishEvaluationsWithUsername = async () => {
  try {
    console.log("Fetching BettaFishEvaluations from Firestore...");

    // ดึงข้อมูลปลากัดทั้งหมด
    const bettaQuerySnapshot = await db.collection("BettaFishEvaluations").get();
    console.log(`Fetched ${bettaQuerySnapshot.size} BettaFishEvaluations documents`);
    const bettaFishList = [];
    const ownerIdsSet = new Set();

    bettaQuerySnapshot.forEach((doc) => {
      const data = doc.data();
      bettaFishList.push({ id: doc.id, ...data });
      ownerIdsSet.add(data.ownerId);
    });

    console.log(`Unique ownerIds found: ${ownerIdsSet.size}`);

    const ownerIds = Array.from(ownerIdsSet);
    console.log(`OwnerIds: ${ownerIds}`);

    // Firestore 'in' queries มีข้อจำกัดที่ไม่เกิน 10 เงื่อนไขต่อครั้ง
    const usernamesMap = {};

    const batchSize = 10;
    for (let i = 0; i < ownerIds.length; i += batchSize) {
      const batch = ownerIds.slice(i, i + batchSize);
      console.log(`Fetching users with ownerIds: ${batch}`);
      const usersQuerySnapshot = await db.collection("users")
        .where("ownerId", "in", batch)
        .get();
      console.log(`Fetched ${usersQuerySnapshot.size} user documents for batch ${Math.floor(i / batchSize) + 1}`);
      usersQuerySnapshot.forEach((userDoc) => {
        const userData = userDoc.data();
        usernamesMap[userData.ownerId] = userData.username; // สมมติว่ามี field 'username'
      });
    }

    console.log("Usernames Map:", usernamesMap);

    // รวมข้อมูลปลากัดกับชื่อผู้เลี้ยง
    const bettaFishWithUsername = bettaFishList.map((betta) => ({
      ...betta,
      username: usernamesMap[betta.ownerId] || "Unknown", // กำหนดค่าเริ่มต้นถ้าไม่พบ
    }));

    console.log("Successfully fetched BettaFishEvaluations with usernames");
    return bettaFishWithUsername;
  } catch (error) {
    console.error("Error fetching betta fish evaluations with username:", error);
    throw new Error("Failed to fetch betta fish evaluations with username");
  }
};

import { collection, getDocs } from "firebase/firestore";
import { getAuth } from "firebase/auth";
import { db } from "../config/FirebaseSDK";

export const fetchBettaEvaluations = async () => {
    try {
      const auth = getAuth();
      const currentUser = auth.currentUser;
  
      if (!currentUser) {
        throw new Error("User not authenticated");
      }
  
      const bettaEvaluations = [];
      const querySnapshot = await getDocs(collection(db, "BettaFishEvaluations"));
  
      querySnapshot.forEach((doc) => {
        bettaEvaluations.push({ 
          id: doc.id, 
          ...doc.data(),
          expertName: currentUser.displayName || currentUser.email || "Unknown Expert"
        });
      });
  
      return bettaEvaluations;
    } catch (error) {
      console.error("Error fetching betta evaluations:", error);
      throw error; // ให้หน้าที่เรียกใช้ฟังก์ชันนี้จัดการต่อ
    }
  };
  

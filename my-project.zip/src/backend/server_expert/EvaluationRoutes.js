// src/backend/server_expert/EvaluationRoutes.js
import express from 'express';
import { db } from '../helpers/firebaseAdminSdk.js'; 
import admin from 'firebase-admin';

const router = express.Router();

// GET /evaluations/all
router.get('/all', async (req, res) => {
  try {
    const snapshot = await db.collection("Evaluations").get();
    const evaluations = [];
    snapshot.forEach(doc => {
      evaluations.push({ id: doc.id, ...doc.data() });
    });
    res.json({ success: true, data: evaluations });
  } catch (error) {
    console.error("Error fetching evaluations:", error);
    res.status(500).json({ success: false, message: "Failed to fetch evaluations" });
  }
});

// POST /evaluations
router.post('/', async (req, res) => {
    const { bettaId, scores, totalScore, evaluatorId } = req.body;
  
    if (!bettaId || !scores || typeof totalScore !== 'number') {
      return res.status(400).json({ success: false, message: "Invalid evaluation data" });
    }
  
    try {
      // ตรวจสอบว่าปลากัดมีอยู่ใน Collection BettaFish หรือไม่
      const bettaRef = db.collection("BettaFish").doc(bettaId);
      const doc = await bettaRef.get();
  
      if (!doc.exists) {
        return res.status(404).json({ success: false, message: "BettaFish not found" });
      }
  
      // เพิ่มเอกสารใหม่ใน Collection Evaluations
      await db.collection("Evaluations").add({
        bettaId,
        scores,
        totalScore,
        evaluationDate: admin.firestore.FieldValue.serverTimestamp(),
        evaluatorId: evaluatorId || null
      });
  
      res.json({ success: true, message: "Evaluation submitted successfully" });
    } catch (error) {
      console.error("Error submitting evaluation:", error);
      res.status(500).json({ success: false, message: "Failed to submit evaluation" });
    }
  });

export { router as EvaluationRoutes };

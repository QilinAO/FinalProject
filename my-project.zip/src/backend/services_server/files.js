// src/backend/services_server/files.js
import express from 'express';
import { bucket } from '../helpers/firebaseAdminSdk.js';
import logger from '../helpers/logger.js';
import { v4 as uuidv4 } from 'uuid';
import path from 'path';
import archiver from 'archiver'; // เพิ่ม archiver สำหรับ ZIP

const router = express.Router();

// ฟังก์ชันช่วยดึงไฟล์และสร้าง Signed URLs
const getFilesFromFolder = async (folderPath) => {
  try {
    const [fileList] = await bucket.getFiles({ prefix: folderPath });
    console.log(`Found ${fileList.length} files in folder: ${folderPath}`); // เพิ่ม log จำนวนไฟล์
    fileList.forEach(file => {
      console.log(`- ${file.name}`);
    });
    const signedUrlPromises = fileList.map(async (file) => {
      const [url] = await file.getSignedUrl({
        action: 'read',
        expires: '03-01-2491', // ปรับวันที่หมดอายุตามต้องการ
      });
      return {
        name: path.basename(file.name),
        downloadUrl: url,
        size: file.metadata.size,
      };
    });
    const signedUrls = await Promise.all(signedUrlPromises);
    return signedUrls;
  } catch (error) {
    console.error(`Error fetching files from folder ${folderPath}:`, error);
    throw error;
  }
};

// API ดึงไฟล์ทั้งหมดจากโฟลเดอร์หลัก
router.get('/all-files', async (req, res) => {
  try {
    // รายการโฟลเดอร์หลักที่ต้องการดึงไฟล์
    const folderPaths = ['Profile/', 'BettaFish/Image/', 'BettaFish/Video/'];

    // สร้างออบเจ็กต์เก็บผลลัพธ์
    const allFiles = {};

    // ดึงไฟล์จากแต่ละโฟลเดอร์
    for (const folderPath of folderPaths) {
      const files = await getFilesFromFolder(folderPath);
      
      // ลบทุก '/' ออกจากชื่อโฟลเดอร์เพื่อใช้เป็นชื่อใน Frontend
      const folderName = folderPath.replace(/\//g, '');
      allFiles[folderName] = {
        total: files.length,
        files,
      };

      console.log(`Folder: ${folderName}, Total Files: ${files.length}`); // เพิ่ม log รายละเอียด
    }

    console.log("Sending allFiles:", allFiles); // เพิ่ม log เพื่อตรวจสอบ
    res.json(allFiles);
  } catch (error) {
    logger.error('Error fetching all files:', error);
    res.status(500).json({ success: false, message: 'Error fetching all files' });
  }
});

// API สำหรับลบไฟล์
router.delete('/:folder/:filename', async (req, res) => {
  const { folder, filename } = req.params;
  const filePath = `${folder}/${filename}`;

  try {
    await bucket.file(filePath).delete();
    res.json({ success: true, message: 'File deleted successfully' });
  } catch (error) {
    logger.error(`Error deleting file ${filePath}:`, error);
    res.status(500).json({ success: false, message: 'Error deleting file' });
  }
});

// API ดึงไฟล์จากโฟลเดอร์ที่กำหนด
router.get('/:folder/files', async (req, res) => {
  const { folder } = req.params;
  const folderPath = `${folder}/`;

  try {
    const files = await getFilesFromFolder(folderPath);
    res.json({ totalFiles: files.length, files });
  } catch (error) {
    logger.error(`Error fetching files for folder ${folder}`, error);
    res.status(500).json({ success: false, message: `Error fetching files for folder ${folder}` });
  }
});

// API สำหรับดาวน์โหลด ZIP ของโฟลเดอร์ที่กำหนด
router.get('/:folderPath(*)/download-zip', async (req, res) => { // ปรับปรุงเส้นทาง
  const { folderPath } = req.params; // 'BettaFish/Image'

  const normalizedFolderPath = folderPath.endsWith('/') ? folderPath : `${folderPath}/`;

  try {
    const [fileList] = await bucket.getFiles({ prefix: normalizedFolderPath });
    if (fileList.length === 0) {
      return res.status(404).json({ success: false, message: 'No files found in this folder' });
    }

    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', `attachment; filename=${path.basename(folderPath)}.zip`);

    const archive = archiver('zip', {
      zlib: { level: 9 }, // ตั้งค่าการบีบอัด
    });

    archive.on('error', (err) => {
      throw err;
    });

    // Pipe การส่งข้อมูลไปยัง response
    archive.pipe(res);

    // เพิ่มไฟล์ทั้งหมดลงใน ZIP
    fileList.forEach(file => {
      const fileName = path.basename(file.name);
      archive.append(bucket.file(file.name).createReadStream(), { name: fileName });
    });

    // เสร็จสิ้นการสร้าง ZIP
    archive.finalize();
  } catch (error) {
    logger.error(`Error downloading ZIP for folder ${folderPath}:`, error);
    res.status(500).json({ success: false, message: 'Error downloading ZIP' });
  }
});

export { router as fileRoutes };

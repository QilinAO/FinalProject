import express from 'express';
import { db } from '../helpers/firebaseAdminSdk.js';
import logger from '../helpers/logger.js';

const router = express.Router();

// ฟังก์ชันตรวจสอบข้อมูล
const validateUserInput = (role, username, email) => {
  if (!role || !username || !email) {
    throw new Error('Role, username, and email are required');
  }
  if (!['admin', 'user', 'manager', 'expert'].includes(role)) {
    throw new Error('Invalid role specified');
  }
  if (!email.includes('@')) {
    throw new Error('Invalid email format');
  }
  if (username.trim() === '') {
    throw new Error('Username cannot be empty');
  }
};

// API ดึงผู้ใช้ทั้งหมด (รองรับการกรองตามบทบาท)
router.get('/', async (req, res) => {
  const { role } = req.query;
  try {
    let query = db.collection('users');
    if (role) {
      query = query.where('role', '==', role);
    }
    const snapshot = await query.get();
    const users = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    res.json(users);
  } catch (error) {
    logger.error('Error fetching users', error);
    res.status(500).json({ success: false, message: 'Error fetching users' });
  }
});

// API เพิ่มผู้ใช้ใหม่
router.post('/', async (req, res) => {
  const { role, username, email } = req.body;
  try {
    validateUserInput(role, username, email);
    const newUser = { role, username, email };
    const docRef = await db.collection('users').add(newUser);
    res.status(201).json({ success: true, id: docRef.id });
  } catch (error) {
    logger.error('Error creating user', error);
    res.status(500).json({ success: false, message: 'Error creating user' });
  }
});

// API อัปเดตผู้ใช้
router.put('/:id', async (req, res) => {
  const { id } = req.params;
  const { role, username, email } = req.body;
  try {
    validateUserInput(role, username, email);
    const userRef = db.collection('users').doc(id);
    const userDoc = await userRef.get();

    if (!userDoc.exists) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    await userRef.update({ role, username, email });
    res.json({ success: true, message: 'User updated successfully' });
  } catch (error) {
    logger.error('Error updating user', error);
    res.status(500).json({ success: false, message: 'Error updating user' });
  }
});

// API ลบผู้ใช้
router.delete('/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const userRef = db.collection('users').doc(id);
    const userDoc = await userRef.get();

    if (!userDoc.exists) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    await userRef.delete();
    res.json({ success: true, message: 'User deleted successfully' });
  } catch (error) {
    logger.error('Error deleting user', error);
    res.status(500).json({ success: false, message: 'Error deleting user' });
  }
});

export const userRoutes = router;

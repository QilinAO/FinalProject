import express from 'express';

const router = express.Router();

// API รายงานข้อมูล
router.get('/', async (req, res) => {
  const reportData = {
    totalUsers: 100,
    totalAdmins: 5,
    totalManagers: 10,
    totalExperts: 20,
    totalRegularUsers: 65,
  };
  res.json(reportData);
});

export const reportRoutes = router;

// src/backend/helpers/firebaseAdminSdk.js
import admin from "firebase-admin";
import fs from "fs";
import { fileURLToPath } from "url";
import path from "path";
import logger from "./logger.js"; // นำเข้า logger.js

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

try {
  const serviceAccountPath = path.join(__dirname, "../config/FirebaseadminSDK.json");

  if (!fs.existsSync(serviceAccountPath)) {
    logger.error("Service account key file not found at:", serviceAccountPath);
    process.exit(1); // หยุดการทำงานหากไฟล์ไม่มี
  }

  const serviceAccount = JSON.parse(
    fs.readFileSync(serviceAccountPath, "utf-8")
  );

  if (!admin.apps.length) {
    admin.initializeApp({
      credential: admin.credential.cert(serviceAccount),
      storageBucket: "project-7ccdf.firebasestorage.app", // แทนที่ด้วยชื่อ bucket ที่ถูกต้องของคุณ โดยไม่มี 'gs://'
      databaseURL: "https://project-7ccdf-default-rtdb.firebaseio.com",
    });
    logger.info("Firebase Admin SDK initialized successfully.");
  } else {
    logger.info("Firebase Admin SDK already initialized.");
  }
} catch (error) {
  logger.error("Failed to initialize Firebase Admin SDK:", error.message);
  process.exit(1); // หยุดการทำงานในกรณีที่เกิดข้อผิดพลาด
}

const db = admin.firestore();
const bucket = admin.storage().bucket(); // ใช้ bucket ที่ถูกตั้งค่าใน initializeApp

console.log("Firebase Admin SDK and Firestore initialized.");
export { admin, db, bucket }; // ส่งออก bucket ด้วย

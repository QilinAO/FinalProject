// helpers/GoogleDrive.js
import { google } from 'googleapis';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import logger from './logger.js'; // นำเข้า logger.js

// สร้าง __dirname สำหรับ ES Modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ใส่ค่า Credential ของคุณที่นี่
const CLIENT_ID = '619450959422-bgr31q49url47ulf8h6i0spo7o7031dp.apps.googleusercontent.com';
const CLIENT_SECRET = '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';
const REDIRECT_URI = 'https://developers.google.com/oauthplayground';
const REFRESH_TOKEN = '1//04wD2ZxGcj-JoCgYIARAAGAQSNgF-L9IrpYFxO6uceQsRhHGLpard0h7aZ1kddalMXehg58Z1uj5doCEf9R1Zy55wEYIH1zaGog';

// สร้าง OAuth2 client
const oauth2Client = new google.auth.OAuth2(
  CLIENT_ID,
  CLIENT_SECRET,
  REDIRECT_URI
);

// เซ็ต refresh token
oauth2Client.setCredentials({ refresh_token: REFRESH_TOKEN });

// สร้าง instance ของ drive
const drive = google.drive({ version: 'v3', auth: oauth2Client });

// ตัวแปร cache (Map) สำหรับเก็บ folderId ที่หาเจอ/สร้างแล้ว
const folderCache = new Map();

/**
 * ฟังก์ชันตรวจสอบ/ค้นหาโฟลเดอร์จากเส้นทาง
 * ถ้าไม่มีให้สร้างใหม่ และบันทึกลง cache
 * รองรับเส้นทางแบบซ้อนกัน เช่น 'Profile/{userId}'
 */
export async function getOrCreateFolder(folderPath, parentId = null) {
  try {
    const folders = folderPath.split('/');
    let currentParentId = parentId;

    for (const folderName of folders) {
      const cacheKey = currentParentId ? `${currentParentId}_${folderName}` : folderName;

      if (folderCache.has(cacheKey)) {
        currentParentId = folderCache.get(cacheKey);
        continue;
      }

      let q = `mimeType='application/vnd.google-apps.folder' and name='${folderName}' and trashed=false`;
      if (currentParentId) {
        q += ` and '${currentParentId}' in parents`;
      }

      const searchRes = await drive.files.list({
        q,
        fields: 'files(id, name)',
        spaces: 'drive',
      });

      let folder;
      if (searchRes.data.files && searchRes.data.files.length > 0) {
        folder = searchRes.data.files[0];
        logger.info(`Found existing folder: ${folder.name} (id: ${folder.id})`);
      } else {
        const fileMetadata = {
          name: folderName,
          mimeType: 'application/vnd.google-apps.folder',
          parents: currentParentId ? [currentParentId] : [],
        };

        const createRes = await drive.files.create({
          requestBody: fileMetadata,
          fields: 'id',
        });

        folder = { id: createRes.data.id, name: folderName };
        logger.info(`Created folder: ${folderName} (id: ${folder.id})`);
      }

      folderCache.set(cacheKey, folder.id);
      currentParentId = folder.id;
    }

    return currentParentId;
  } catch (error) {
    logger.error(`Error in getOrCreateFolder: ${error.message}`);
    throw new Error(`Error creating or retrieving folder: ${error.message}`);
  }
}

/**
 * กำหนด Permission ไฟล์เป็น Public: Anyone with the link
 */
export async function setFilePublic(fileId) {
  try {
    await drive.permissions.create({
      fileId: fileId,
      requestBody: {
        role: 'reader',
        type: 'anyone',
      },
    });
    logger.info(`File (id: ${fileId}) set to public (anyone with the link).`);
  } catch (error) {
    logger.error('Error setting file permission:', error.message);
    throw error;
  }
}

/**
 * ฟังก์ชันอัปโหลดไฟล์ไปยังโฟลเดอร์ที่กำหนด
 * - จะคืนค่าเป็น Object ที่มี id, name, webViewLink, webContentLink
 */
export async function uploadFile(filePath, folderId, makePublic = false, customFileName) {
  try {
    const fileName = customFileName || path.basename(filePath);

    const response = await drive.files.create({
      requestBody: {
        name: fileName,
        parents: [folderId],
      },
      media: {
        body: fs.createReadStream(filePath), // ไม่ต้องกำหนด mimeType
      },
      fields: 'id, name, webViewLink, webContentLink',
    });

    const { id, name, webViewLink, webContentLink } = response.data;
    logger.info(`Uploaded file: ${name} (id: ${id})`);

    if (makePublic) {
      await setFilePublic(id);
    }

    return {
      id,
      name,
      webViewLink,
      webContentLink: `https://drive.google.com/uc?export=view&id=${id}`, // ใช้ลิงก์นี้สำหรับการแสดงภาพ
    };
  } catch (error) {
    logger.error('Error uploading file:', error.message);
    throw error;
  }
}

/**
 * ฟังก์ชันลบไฟล์จาก Google Drive
 * @param {string} fileId - ID ของไฟล์ที่ต้องการลบ
 * @returns {Promise<void>} - Promise ที่สำเร็จเมื่อไฟล์ถูกลบเรียบร้อย
 */
export async function deleteFile(fileId) {
  try {
    await drive.files.delete({
      fileId: fileId,
    });
    logger.info(`Deleted file with id: ${fileId}`);
  } catch (error) {
    logger.error(`Error deleting file with id ${fileId}:`, error.message);
    throw error;
  }
}

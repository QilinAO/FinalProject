// src/backend/services/CompetitionHistory.js
import { db } from "../config/FirebaseSDK";
import { collection, getDocs, query, where } from "firebase/firestore";

/**
 * ดึงข้อมูลการแข่งขันเฉพาะของผู้ใช้จาก Firestore
 * @param {string} userId - รหัสผู้ใช้
 * @returns {Promise<Array>} - ข้อมูลการแข่งขันของผู้ใช้
 */
export const fetchCompetitionsForUser = async (userId) => {
  if (!userId) throw new Error("User ID is required");

  const competitionsRef = collection(db, "BettaFishCompetitions");
  const q = query(competitionsRef, where("ownerId", "==", userId));
  const querySnapshot = await getDocs(q);

  const fetchedCompetitions = [];
  querySnapshot.forEach((doc) => {
    fetchedCompetitions.push({ id: doc.id, ...doc.data() });
  });

  return fetchedCompetitions;
};

import { db, auth } from "../config/FirebaseSDK";  // ดึง auth มาใช้งานด้วย
import { collection, getDocs, query, where } from "firebase/firestore";

/**
 * ดึงข้อมูลการประเมินเฉพาะของผู้ใช้จาก Firestore
 * และจัดเรียงในฝั่งไคลเอนต์
 * @returns {Promise<Array>} - ข้อมูลการประเมินคุณภาพของผู้ใช้
 */
export const fetchEvaluationsForUser = async () => {
  // ตรวจสอบว่าผู้ใช้ล็อกอินหรือไม่
  const user = auth.currentUser;
  if (!user) {
    throw new Error("User is not logged in");
  }

  const userId = user.uid;  // ดึง userId จาก auth
  const evaluationsRef = collection(db, "BettaFishEvaluations");
  const q = query(evaluationsRef, where("ownerId", "==", userId));  // ดึงข้อมูลที่ตรงกับ ownerId

  const querySnapshot = await getDocs(q);

  const fetchedEvaluations = [];
  querySnapshot.forEach((doc) => {
    const data = doc.data();
    
    // แปลง evaluationDate หากเป็น Timestamp
    const evaluationDate = data.evaluationDate instanceof Date
      ? data.evaluationDate
      : new Date(data.evaluationDate);

    fetchedEvaluations.push({ id: doc.id, ...data, evaluationDate });
  });

  console.log("Fetched Evaluations:", fetchedEvaluations); // ตรวจสอบข้อมูล

  // จัดเรียงข้อมูลในฝั่งไคลเอนต์
  return fetchedEvaluations.sort((a, b) => b.evaluationDate - a.evaluationDate);  // เรียงจากวันที่ใหม่ไปเก่า
};

// src/backend/services/Profile.js

import { db, storage } from "../config/FirebaseSDK";
import { doc, getDoc, updateDoc } from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL, deleteObject } from "firebase/storage";

const defaultProfileImage = "https://dummyimage.com/800x400";

// ฟังก์ชันดึงข้อมูลโปรไฟล์
export const fetchProfile = async (uid) => {
  if (!uid) throw new Error("User ID is required");

  const userDocRef = doc(db, "users", uid);
  const userDoc = await getDoc(userDocRef);

  if (!userDoc.exists()) {
    // กรณีที่ผู้ใช้ยังไม่มีข้อมูลใน Firestore ให้สร้างข้อมูลเริ่มต้น
    const defaultData = {
      username: "New User",
      firstName: "",
      lastName: "",
      email: "",
      profile: defaultProfileImage,
    };
    await updateProfile(uid, defaultData);
    return defaultData;
  }

  const data = userDoc.data();
  return {
    ...data,
    profile: data.profile || defaultProfileImage,
  };
};

// ฟังก์ชันอัปเดตโปรไฟล์
export const updateProfile = async (uid, formData) => {
  if (!uid) throw new Error("User ID is required");

  const userDocRef = doc(db, "users", uid);
  await updateDoc(userDocRef, formData);
};

// ฟังก์ชันอัปโหลดรูปโปรไฟล์
export const uploadProfilePicture = async (uid, file) => {
  if (!uid || !file) throw new Error("User ID and file are required");

  const fileName = `profilePicture_${Date.now()}.jpg`;
  const storageRef = ref(storage, `Profile/${uid}/${fileName}`);

  await uploadBytes(storageRef, file);
  const downloadURL = await getDownloadURL(storageRef);

  return downloadURL;
};

// ฟังก์ชันลบรูปโปรไฟล์
export const deleteProfilePicture = async (filePath) => {
  if (!filePath || filePath === defaultProfileImage) return;

  const fileRef = ref(storage, filePath);
  await deleteObject(fileRef).catch((error) => {
    console.warn("Failed to delete old profile picture:", error);
  });
};

// ฟังก์ชันสำหรับเปลี่ยนรหัสผ่าน
export const resetPassword = async (auth, email) => {
  if (!email) throw new Error("Email is required");

  try {
    await auth.sendPasswordResetEmail(email);
    return { success: true, message: "Password reset link sent successfully." };
  } catch (error) {
    throw new Error("Error sending password reset email: " + error.message);
  }
};

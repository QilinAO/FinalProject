import { storage, db } from "../config/FirebaseSDK";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { doc, setDoc } from "firebase/firestore";
import { auth } from "../config/FirebaseSDK";

/**
 * อัปโหลดไฟล์ไปยัง Firebase Storage
 * @param {string} folder - โฟลเดอร์ที่ต้องการเก็บไฟล์ (เช่น "BettaFish/Image" หรือ "BettaFish/Video")
 * @param {File} file - ไฟล์ที่ต้องการอัปโหลด
 * @returns {Promise<string>} - URL ของไฟล์ที่ถูกอัปโหลด
 */
export const uploadFileToStorage = async (folder, file) => {
  const timestamp = Date.now();
  const fileRef = ref(storage, `${folder}/${timestamp}_${file.name}`);
  await uploadBytes(fileRef, file);
  return getDownloadURL(fileRef);
};

/**
 * บันทึกข้อมูลปลากัดลง Firestore พร้อมวันที่ทำการประเมิน, สถานะเริ่มต้น และ ownerId
 * @param {Object} data - ข้อมูลปลากัดที่ต้องการบันทึก
 * @returns {Promise<void>}
 */
export const saveBettaDataToFirestore = async (data) => {
  const currentUser = auth.currentUser; // ดึงข้อมูลผู้ใช้ปัจจุบัน
  if (!currentUser) {
    throw new Error("User is not logged in");
  }

  const ownerId = currentUser.uid; // ownerId จาก Firebase Authentication
  const timestamp = Date.now();
  const bettaDocRef = doc(db, "BettaFishEvaluations", `${timestamp}`);
  
  const dataWithDateAndStatus = {
    ...data,
    ownerId, // เพิ่ม ownerId
    evaluationDate: new Date(timestamp).toISOString(),
    status: "รอการประเมิน", // สถานะเริ่มต้น
  };

  await setDoc(bettaDocRef, dataWithDateAndStatus);
};

// src/backend/Auth/firebase-auth.js
import { auth, db, storage } from "../config/FirebaseSDK";
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
  onAuthStateChanged,
} from "firebase/auth";
import { doc, setDoc, getDoc, updateDoc } from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { getAuth } from "firebase/auth";


const defaultProfileImage = "https://dummyimage.com/800x400";
/**
 * สมัครสมาชิก
 * @param {string} email - อีเมลของผู้ใช้
 * @param {string} password - รหัสผ่านของผู้ใช้
 * @param {Object} additionalData - ข้อมูลเพิ่มเติม (username, firstName, lastName, role)
 * @returns {Promise<User>} - ผู้ใช้ที่ถูกสร้างขึ้น
 */
export const signupUser = async (email, password, additionalData) => {
  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;

    // บันทึกข้อมูลเพิ่มเติมใน Firestore
    const userDocRef = doc(db, "users", user.uid);
    await setDoc(userDocRef, {
      username: additionalData.username,
      firstName: additionalData.firstName,
      lastName: additionalData.lastName,
      email: user.email,
      profile: defaultProfileImage, // ตั้งค่ารูปเริ่มต้น
      role: additionalData.role || "user",
      ownerId: user.uid // หรือ uid ก็ได้
    });

    // ออกจากระบบทันทีหลังจากสมัครสมาชิก
    await signOut(auth);

    return user;
  } catch (error) {
    console.error("Error signing up:", error.message);
    throw error;
  }
};


/**
 * เข้าสู่ระบบ
 * @param {string} email - อีเมลของผู้ใช้
 * @param {string} password - รหัสผ่านของผู้ใช้
 * @returns {Promise<User>} - ผู้ใช้ที่เข้าสู่ระบบ
 */
export const loginUser = async (email, password) => {
  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    return userCredential.user;
  } catch (error) {
    console.error("Error logging in:", error.message);
    throw error;
  }
};

/**
 * ออกจากระบบ
 * @returns {Promise<void>}
 */
export const logoutUser = async () => {
  try {
    await signOut(auth);
  } catch (error) {
    console.error("Error logging out:", error.message);
    throw error;
  }
};

/**
 * รีเซ็ตรหัสผ่าน
 * @param {string} email - อีเมลของผู้ใช้
 * @returns {Promise<void>}
 */
export const resetPassword = async (email) => {
  try {
    await sendPasswordResetEmail(auth, email);
  } catch (error) {
    console.error("Error resetting password:", error.message);
    throw error;
  }
};

/**
 * ตรวจสอบสถานะผู้ใช้ (callback จะเรียกเมื่อ Auth state เปลี่ยน)
 * @param {Function} callback - ฟังก์ชันที่ต้องการเรียกเมื่อสถานะ Auth เปลี่ยน
 * @returns {Unsubscribe} - ฟังก์ชันสำหรับยกเลิกการฟัง
 */
export const checkUserState = (callback) => {
  return onAuthStateChanged(auth, callback);
};

/**
 * ดึงข้อมูล role ผู้ใช้งาน
 * @param {string} uid - UID ของผู้ใช้
 * @returns {Promise<string|null>} - Role ของผู้ใช้ หรือ null ถ้าไม่มีข้อมูล
 */
export const getUserRole = async (uid) => {
  try {
    const userDocRef = doc(db, "users", uid);
    const userDoc = await getDoc(userDocRef);
    if (userDoc.exists()) {
      return userDoc.data().role;
    } else {
      console.error("No such user document.");
      return null;
    }
  } catch (error) {
    console.error("Error fetching user role:", error.message);
    throw error;
  }
};

/**
 * ดึงข้อมูลโปรไฟล์ผู้ใช้งาน
 * @param {string} uid - UID ของผู้ใช้
 * @returns {Promise<Object|null>} - ข้อมูลโปรไฟล์ของผู้ใช้ หรือ null ถ้าไม่มีข้อมูล
 */
export const getUserProfile = async (uid) => {
  try {
    const userDocRef = doc(db, "users", uid);
    const userDoc = await getDoc(userDocRef);
    if (userDoc.exists()) {
      return userDoc.data();
    } else {
      console.error("No user profile found.");
      return null;
    }
  } catch (error) {
    console.error("Error fetching user profile:", error.message);
    throw error;
  }
};

/**
 * อัปเดตข้อมูลโปรไฟล์ผู้ใช้งาน (ชื่อ, อีเมล, ...)
 * @param {string} uid - UID ของผู้ใช้
 * @param {Object} updatedData - ข้อมูลที่ต้องการอัปเดต
 * @returns {Promise<void>}
 */
export const updateUserProfile = async (uid, updatedData) => {
  try {
    const userDocRef = doc(db, "users", uid);
    await updateDoc(userDocRef, updatedData);
  } catch (error) {
    console.error("Error updating user profile:", error.message);
    throw error;
  }
};

/**
 * รีเซ็ตรหัสผ่าน (ซ้ำกับ resetPassword ข้างบนได้)
 * @param {string} email - อีเมลของผู้ใช้
 * @returns {Promise<void>}
 */
export const resetUserPassword = async (email) => {
  try {
    await sendPasswordResetEmail(auth, email);
  } catch (error) {
    console.error("Error resetting password:", error.message);
    throw error;
  }
};

/**
 * อัปโหลดไฟล์ไปยัง Firebase Storage
 * @param {string} uid - UID ของผู้ใช้
 * @param {File} file - ไฟล์ที่ต้องการอัปโหลด
 * @param {string} folder - โฟลเดอร์ที่ต้องการเก็บไฟล์ (เช่น "Profile", "BettaFish/Image", "BettaFish/Video")
 * @returns {Promise<string>} - URL ของไฟล์ที่ถูกอัปโหลด
 */
export const uploadFileToStorage = async (uid, file, folder) => {
  try {
    const timestamp = Date.now();
    const fileName = `${timestamp}_${file.name}`;
    const filePath = `${folder}/${uid}/${fileName}`;
    const storageRef = ref(storage, filePath);
    await uploadBytes(storageRef, file);
    const downloadURL = await getDownloadURL(storageRef);
    return downloadURL;
  } catch (error) {
    console.error("Error uploading file to storage:", error.message);
    throw error;
  }
};

/**
 * อัปโหลดรูปโปรไฟล์ผู้ใช้งาน
 * @param {string} uid - UID ของผู้ใช้
 * @param {File} file - ไฟล์รูปภาพที่ต้องการอัปโหลด
 * @returns {Promise<string>} - URL ของรูปโปรไฟล์ที่ถูกอัปโหลด
 */
export const uploadProfilePicture = async (uid, file) => {
  try {
    const downloadURL = await uploadFileToStorage(uid, file, "Profile");
    // อัปเดต URL รูปโปรไฟล์ใน Firestore
    await updateUserProfile(uid, { profile: downloadURL });
    return downloadURL;
  } catch (error) {
    console.error("Error uploading profile picture:", error.message);
    throw error;
  }
};

/**
 * อัปโหลดรูปภาพสำหรับการประเมินคุณภาพปลากัด
 * @param {string} uid - UID ของผู้ใช้
 * @param {File[]} files - อาร์เรย์ของไฟล์รูปภาพที่ต้องการอัปโหลด
 * @returns {Promise<string[]>} - อาร์เรย์ของ URL ของรูปภาพที่ถูกอัปโหลด
 */
export const uploadBettaEvaluationImages = async (uid, files) => {
  try {
    const uploadPromises = files.map(file => uploadFileToStorage(uid, file, "BettaFish/Image"));
    const imageUrls = await Promise.all(uploadPromises);
    return imageUrls;
  } catch (error) {
    console.error("Error uploading BettaFish evaluation images:", error.message);
    throw error;
  }
};

/**
 * อัปโหลดวิดีโอสำหรับการประเมินคุณภาพปลากัด
 * @param {string} uid - UID ของผู้ใช้
 * @param {File} file - ไฟล์วิดีโอที่ต้องการอัปโหลด
 * @returns {Promise<string>} - URL ของวิดีโอที่ถูกอัปโหลด
 */
export const uploadBettaEvaluationVideo = async (uid, file) => {
  try {
    const downloadURL = await uploadFileToStorage(uid, file, "BettaFish/Video");
    return downloadURL;
  } catch (error) {
    console.error("Error uploading BettaFish evaluation video:", error.message);
    throw error;
  }
};
// src/backend/server.js
import express from 'express';
import cors from 'cors';
import morgan from 'morgan';
import fileUpload from 'express-fileupload';
import logger from './helpers/logger.js';
import { userRoutes } from './services_server/users.js';
import { fileRoutes } from './services_server/files.js';
import { reportRoutes } from './services_server/reports.js';
import dotenv from 'dotenv';
import { BettaFishReviewRoutes } from './server_expert/BettaFishReviewRoutes.js';
import { EvaluationRoutes } from './server_expert/EvaluationRoutes.js';


dotenv.config();

const app = express();

// Middleware
app.use(cors({
  origin: 'http://localhost:5173', // ปรับให้ตรงกับ Frontend ของคุณ
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(fileUpload());
app.use(morgan('combined')); // ใช้ morgan สำหรับ logging

// Routes
app.use('/users', userRoutes); // จัดการ API เกี่ยวกับผู้ใช้
app.use('/files', fileRoutes); // จัดการ API เกี่ยวกับไฟล์
app.use('/reports', reportRoutes); // จัดการ API รายงาน
app.use('/bettaReviews', BettaFishReviewRoutes); // เพิ่ม Route ใหม่
app.use('/evaluations', EvaluationRoutes); // ใช้ Route สำหรับ Evaluations


// Endpoint ทดสอบ
app.get('/', (req, res) => {
  res.json({
    success: true,
    message: 'Server is running and API is working!',
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  logger.error(err.stack);
  res.status(500).json({ success: false, message: 'Internal Server Error' });
});

// เริ่มต้นเซิร์ฟเวอร์
const PORT = process.env.PORT || 3000;
app.listen(PORT, '0.0.0.0', () => console.log(`Server is running on port ${PORT}`));

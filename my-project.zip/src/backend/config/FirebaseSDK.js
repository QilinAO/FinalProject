// src/firebase-config.js
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: "AIzaSyBsgCLSW3w8O9i0P-iZiiZPbwGT5LfXHRA",
  authDomain: "project-7ccdf.firebaseapp.com",
  projectId: "project-7ccdf",
  storageBucket: "project-7ccdf.firebasestorage.app",
  messagingSenderId: "1062472559923",
  appId: "1:1062472559923:web:cbea2294c8c0650109e246",
  measurementId: "G-QLJE5LDS9K",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);

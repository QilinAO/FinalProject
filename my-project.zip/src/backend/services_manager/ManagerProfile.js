// src\backend\services_manager\ManagerProfile.js
import { collection, onSnapshot, query, where, doc, deleteDoc } from "firebase/firestore";
import { db } from "../config/FirebaseSDK"; // ปรับเส้นทางให้ถูกต้องตามโครงสร้างโปรเจกต์ของคุณ

/**
 * ดึงข้อมูลข่าวสารประชาสัมพันธ์แบบเรียลไทม์จาก Firestore
 * @param {Function} callback - ฟังก์ชันที่เรียกเมื่อข้อมูลเปลี่ยนแปลง
 * @returns {Function} - ฟังก์ชันเพื่อยกเลิกการสมัครรับข้อมูล
 */
export const subscribeToPromotionalNews = (callback) => {
  const promotionalNewsCollection = collection(db, "contests");
  const q = query(promotionalNewsCollection, where("category", "==", "ข่าวสารประชาสัมพันธ์"));
  const unsubscribe = onSnapshot(q, (querySnapshot) => {
    const promotionalNewsData = [];
    querySnapshot.forEach((doc) => {
      promotionalNewsData.push({ id: doc.id, ...doc.data() });
    });
    callback(promotionalNewsData, null);
  }, (error) => {
    console.error("Error fetching promotional news: ", error);
    callback(null, error);
  });
  return unsubscribe;
};

/**
 * ดึงข้อมูลการประกวดแบบเรียลไทม์จาก Firestore
 * @param {Function} callback - ฟังก์ชันที่เรียกเมื่อข้อมูลเปลี่ยนแปลง
 * @returns {Function} - ฟังก์ชันเพื่อยกเลิกการสมัครรับข้อมูล
 */
export const subscribeToContests = (callback) => {
  const contestsCollection = collection(db, "contests");
  const q = query(contestsCollection, where("category", "==", "การประกวด"));
  const unsubscribe = onSnapshot(q, (querySnapshot) => {
    const contestsData = [];
    querySnapshot.forEach((doc) => {
      contestsData.push({ id: doc.id, ...doc.data() });
    });
    callback(contestsData, null);
  }, (error) => {
    console.error("Error fetching contests: ", error);
    callback(null, error);
  });
  return unsubscribe;
};

/**
 * ดึงข้อมูลข่าวสารทั่วไปแบบเรียลไทม์จาก Firestore
 * @param {Function} callback - ฟังก์ชันที่เรียกเมื่อข้อมูลเปลี่ยนแปลง
 * @returns {Function} - ฟังก์ชันเพื่อยกเลิกการสมัครรับข้อมูล
 */
export const subscribeToGeneralNews = (callback) => {
  const generalNewsCollection = collection(db, "contests");
  const q = query(generalNewsCollection, where("category", "==", "ข่าวสารทั่วไป"));
  const unsubscribe = onSnapshot(q, (querySnapshot) => {
    const generalNewsData = [];
    querySnapshot.forEach((doc) => {
      generalNewsData.push({ id: doc.id, ...doc.data() });
    });
    callback(generalNewsData, null);
  }, (error) => {
    console.error("Error fetching general news: ", error);
    callback(null, error);
  });
  return unsubscribe;
};

/**
 * ลบข่าวสารประชาสัมพันธ์จาก Firestore
 * @param {string} id - ID ของข่าวสารประชาสัมพันธ์ที่ต้องการลบ
 * @returns {Promise<void>}
 */
export const deletePromotionalNews = async (id) => {
  try {
    const newsDoc = doc(db, "contests", id);
    await deleteDoc(newsDoc);
  } catch (error) {
    console.error("Error deleting promotional news: ", error);
    throw error;
  }
};

/**
 * ลบการประกวดจาก Firestore
 * @param {string} id - ID ของการประกวดที่ต้องการลบ
 * @returns {Promise<void>}
 */
export const deleteContest = async (id) => {
  try {
    const contestDoc = doc(db, "contests", id);
    await deleteDoc(contestDoc);
  } catch (error) {
    console.error("Error deleting contest: ", error);
    throw error;
  }
};

/**
 * ลบข่าวสารทั่วไปจาก Firestore
 * @param {string} id - ID ของข่าวสารทั่วไปที่ต้องการลบ
 * @returns {Promise<void>}
 */
export const deleteGeneralNews = async (id) => {
  try {
    const newsDoc = doc(db, "contests", id);
    await deleteDoc(newsDoc);
  } catch (error) {
    console.error("Error deleting general news: ", error);
    throw error;
  }
};

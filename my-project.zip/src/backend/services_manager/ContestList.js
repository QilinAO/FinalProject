// src\backend\services_manager\ContestList.js
import { collection, onSnapshot, query, where, doc, deleteDoc, updateDoc } from "firebase/firestore";
import { db } from "../config/FirebaseSDK"; // ปรับเส้นทางให้ถูกต้องตามโครงสร้างโปรเจกต์ของคุณ

/**
 * ดึงข้อมูลการประกวดแบบเรียลไทม์จาก Firestore
 * @param {Function} callback - ฟังก์ชันที่เรียกเมื่อข้อมูลเปลี่ยนแปลง
 * @returns {Function} - ฟังก์ชันเพื่อยกเลิกการสมัครรับข้อมูล
 */
export const subscribeToContests = (callback) => {
  const contestsCollection = collection(db, "contests");
  const q = query(contestsCollection, where("category", "==", "การประกวด")); // เพิ่มการกรอง category
  const unsubscribe = onSnapshot(q, (querySnapshot) => {
    const contestsData = [];
    querySnapshot.forEach((doc) => {
      contestsData.push({ id: doc.id, ...doc.data() });
    });
    callback(contestsData);
  }, (error) => {
    console.error("Error fetching contests: ", error);
    callback(null, error);
  });
  return unsubscribe;
};

/**
 * อัปเดตข้อมูลการประกวดใน Firestore
 * @param {string} contestId - ID ของการประกวดที่ต้องการอัปเดต
 * @param {Object} updatedData - ข้อมูลที่ต้องการอัปเดต
 * @returns {Promise<void>}
 */
export const updateContest = async (contestId, updatedData) => {
  try {
    const contestDoc = doc(db, "contests", contestId);
    await updateDoc(contestDoc, updatedData);
  } catch (error) {
    console.error("Error updating contest: ", error);
    throw error;
  }
};

/**
 * ลบการประกวดจาก Firestore
 * @param {string} contestId - ID ของการประกวดที่ต้องการลบ
 * @returns {Promise<void>}
 */
export const deleteContest = async (contestId) => {
  try {
    const contestDoc = doc(db, "contests", contestId);
    await deleteDoc(contestDoc);
  } catch (error) {
    console.error("Error deleting contest: ", error);
    throw error;
  }
};

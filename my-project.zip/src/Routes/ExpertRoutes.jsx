import React from "react";
import ExpertDashboard from "../Pages/Expert/ExpertDashboard";
import ExpertProfile from "../Pages/Expert/ExpertProfile";
import EvaluationHistory from "../Pages/Expert/EvaluationHistory";
import Activities from "../Pages/Expert/Activities";
import BettaReviewPage from "../Pages/Expert/BettaFish_ReviewPage";

const ExpertRoutes = [
    { path: "/expert-dashboard", element: <ExpertDashboard /> },
    { path: "/expert/profile", element: <ExpertProfile /> },
    { path: "/expert/evaluation-history", element: <EvaluationHistory /> },
    { path: "/expert/activities", element: <Activities /> },
    { path: "/fishreviewpage", element: <BettaReviewPage /> },
];

export default ExpertRoutes;

import React from "react";
import ManagerDashboard from "../Pages/Manager/ManagerDashboard";
import ManagerProfile from "../Pages/Manager/ManagerProfile";
import ContestManagement from "../Pages/Manager/ContestManagement";
import ContestList from "../Pages/Manager/ContestList";
import AnnounceResults from "../Pages/Manager/CompetitionResults";
import ContestHistory from "../Pages/Manager/ContestHistory";


const ManagerRoutes = [
    { path: "/manager/dashboard", element: <ManagerDashboard /> },
    { path: "/manager/profile", element: <ManagerProfile /> },
    { path: "/manager/contest-management", element: <ContestManagement /> },
    { path: "/manager/contest-list", element: <ContestList /> },
    { path: "/manager/competition-results", element: <AnnounceResults /> },
    { path: "/manager/contest-history", element: <ContestHistory /> },

];

export default ManagerRoutes;

// src/Routes/Routes.jsx
import React from "react";

import AllNewsPage from '../Pages/User/AllNewsPage';
import BettaEvaluationForm from '../Pages/User/BettaEvaluationForm';
import ContestPage from '../Pages/User/ContestPage';
import HistoryPage from '../Pages/User/HistoryPage';
import Login from '../Pages/User/Login';
import SignUp from '../Pages/User/SignUp';
import ForgotPassword from '../Pages/User/ForgotPassword';
import SingleNewsPage from '../Pages/User/SingleNewsPage';
import Profile from '../Pages/User/Profile';
import HomePage from "../Pages/User/HomePage";
import AdminDashboard from "../Pages/Admin/AdminDashboard";
import ManageUser from "../Pages/Admin/ManageUser";
import Report from "../Pages/Admin/Report";
import Unauthorized from "../context/Unauthorized";
import DatabaseManagement from "../Pages/Admin/DatabaseManagement";
import ManagerDashboard from "../Pages/Manager/ManagerDashboard";
import ManagerProfile from "../Pages/Manager/ManagerProfile";
import ContestManagement from "../Pages/Manager/ContestManagement";
import ContestList from "../Pages/Manager/ContestList";
import AssignJudges from "../Pages/Manager/AssignJudges";
import AnnounceResults from "../Pages/Manager/AnnounceResults";
import ExpertDashboard from "../Pages/Expert/ExpertDashboard";



// เส้นทางทั่วไป
export const PublicRoutes = [
    { path: "/", element: <HomePage /> },
    { path: "/news/:id", element: <SingleNewsPage /> },
    { path: "/news", element: <AllNewsPage /> },
    { path: "/login", element: <Login /> },
    { path: "/signup", element: <SignUp /> },
    { path: "/forgot-password", element: <ForgotPassword /> },
    { path: "/contest", element: <ContestPage /> },
    { path: "/unauthorized", element: <Unauthorized /> },
];

// เส้นทางที่ต้องล็อกอิน
export const ProtectedUserRoutes = [
    { path: "/evaluate", element: <BettaEvaluationForm /> },
    { path: "/history", element: <HistoryPage /> },
    { path: "/profile", element: <Profile /> },
    { path: "/unauthorized", element: <Unauthorized /> },
];

// เส้นทางสำหรับแอดมิน
export const AdminRoutes = [
    { path: "/admin-dashboard", element: <AdminDashboard /> },
    { path: "/manage-users", element: <ManageUser /> },
    { path: "/reports", element: <Report /> },
    { path: "/database", element: <DatabaseManagement /> },
    { path: "/unauthorized", element: <Unauthorized /> },
  ];

export const ManagerRoutes = [
    { path: "/manager/dashboard", element: <ManagerDashboard /> },
    { path: "/manager/profile", element: <ManagerProfile /> },
    { path: "/manager/contest-management", element: <ContestManagement /> },
    { path: "/manager/contest-list", element: <ContestList /> },
    { path: "/manager/assign-judges", element: <AssignJudges /> },
    { path: "/manager/announce-results", element: <AnnounceResults /> },
    { path: "/manager/competition-results", element: <AnnounceResults /> },
    { path: "/unauthorized", element: <Unauthorized /> },
]

export const ExpertRoutes = [
    { path: "/expert-dashboard", element: <ExpertDashboard /> },
]
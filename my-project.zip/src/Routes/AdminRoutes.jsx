import React from "react";
import AdminDashboard from "../Pages/Admin/AdminDashboard";
import ManageUser from "../Pages/Admin/ManageUser";
import Report from "../Pages/Admin/Report";
import DatabaseManagement from "../Pages/Admin/DatabaseManagement";

const AdminRoutes = [
    { path: "/admin-dashboard", element: <AdminDashboard /> },
    { path: "/manage-users", element: <ManageUser /> },
    { path: "/reports", element: <Report /> },
    { path: "/database", element: <DatabaseManagement /> },
];

export default AdminRoutes;
